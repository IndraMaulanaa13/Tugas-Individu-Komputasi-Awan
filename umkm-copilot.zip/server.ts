import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "15mb" }));

// Initialize Google Gen AI client with appropriate user agent
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// Helper to check for API Key availability
const checkApiKey = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (!process.env.GEMINI_API_KEY) {
    return res.status(500).json({
      error: "GEMINI_API_KEY is not configured in environment. Please add it in the Secrets panel.",
    });
  }
  next();
};

// Helper to determine which Gemini model to use dynamically
const getPreferredModel = (req: express.Request, defaultModel: string = "gemini-3.1-flash-lite"): string => {
  if (req.body.model) return req.body.model;
  if (req.body.storeProfile?.aiModel) return req.body.storeProfile.aiModel;
  return defaultModel;
};

// 1. Smart Sales Parser API
app.post("/api/gemini/parse-sale", checkApiKey, async (req, res) => {
  try {
    const { text, image, products } = req.body;
    if (!text && !image) {
      return res.status(400).json({ error: "No receipt source provided. Add either 'text' or 'image' parameter." });
    }

    const availableProducts = products || [];
    const productsListStr = availableProducts
      .map((p: any) => `- Name: "${p.name}", Unit Price: Rp ${p.price}`)
      .join("\n");

    const promptBase = `Parse input sales receipt information into sales transaction JSON format.

Available Products in Store:
${productsListStr}

Rules:
1. Match products in the available store list using fuzzy matching (e.g. "bakso urat", "urut", "baskso" might refer to "Bakso Urat").
2. Match quantity correctly (e.g. "3" or "tiga" -> 3).
3. If a product on the receipt is NOT in the available store products list, invent a realistic name, quantity, and a realistic unit price based on the receipt's information, and add it to the list anyway so it can be recorded. Set the confidence lower for unrecognized items.
4. Calculate grand totals correctly.
5. Identify any words, signatures, or notes that were completely unrecognized or impossible to match as a sale, and list them in 'unrecognized'.
6. Return purely valid JSON adhering to the specified schema.
7. Return clean integer values for prices (no dots, no commas, no currency symbol like 'Rp').`;

    let contents: any;
    if (image && image.data && image.mimeType) {
      contents = {
        parts: [
          {
            inlineData: {
              mimeType: image.mimeType,
              data: image.data,
            },
          },
          {
            text: `${promptBase}\n\nAnalyze this physical receipt image carefully, perform OCR to read all items, and generate a transaction log.`,
          },
        ],
      };
    } else {
      contents = `${promptBase}\n\nInput Text to analyze:\n"${text}"`;
    }

    const selectedModel = getPreferredModel(req, "gemini-3.1-flash-lite");

    const response = await ai.models.generateContent({
      model: selectedModel,
      contents: contents,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            items: {
              type: Type.ARRAY,
              description: "Parsed line items of the sales transaction",
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING, description: "Name of the product matched or created" },
                  qty: { type: Type.INTEGER, description: "Quantity sold" },
                  unitPrice: { type: Type.INTEGER, description: "Individual item unit price (not formatted, clean integer)" },
                  total: { type: Type.INTEGER, description: "Item quantity multiplied by individual price" }
                },
                required: ["name", "qty", "unitPrice", "total"]
              }
            },
            grandTotal: { type: Type.INTEGER, description: "Total price of all items combined" },
            confidence: { type: Type.NUMBER, description: "A float between 0.0 and 1.0 indicating parser confidence" },
            unrecognized: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Items or phrases that could not be parsed as transactions"
            }
          },
          required: ["items", "grandTotal", "confidence", "unrecognized"]
        }
      }
    });

    const parsedData = JSON.parse(response.text || "{}");
    res.json(parsedData);
  } catch (error: any) {
    console.error("Parse Sale Error:", error);
    res.status(500).json({ error: error.message || "Failed to parse sales transaction." });
  }
});

// 2. Daily AI Insight Generator API
app.post("/api/gemini/insights", checkApiKey, async (req, res) => {
  try {
    const { storeProfile, products, last30DaysTransactions } = req.body;

    const storeSummary = JSON.stringify(storeProfile || {}, null, 2);
    const productsSummary = JSON.stringify(products || [], null, 2);
    const transactionsSummary = JSON.stringify((last30DaysTransactions || []).slice(0, 100), null, 2); // Cap to safeguard tokens

    const selectedModel = getPreferredModel(req, "gemini-3.1-flash-lite");

    const response = await ai.models.generateContent({
      model: selectedModel,
      contents: `Analisis data bisnis UMKM Indonesia berikut dan hasilkan 3 rekomendasi/insight bisnis spesifik yang KONKRET, BERGUNA, dan menggunakan ANGKA NYATA yang relevan.

Informasi Usaha:
${storeSummary}

Daftar Produk:
${productsSummary}

Data Penjualan Terbaru:
${transactionsSummary}

Aturan:
1. Hasilkan tepat 3 insight dalam Bahasa Indonesia.
2. Setiap ucapan harus pendek (maksimal 20 kata per insight), ramah, memotivasi, dan mudah dicerna.
3. Contoh: "Bakso Urat berkontribusi 45% omzet, pertimbangkan tambah stok menjelang makan siang!" atau "Hari Rabu cenderung sepi (-25%), buat promo 'Rabu Hemat'!"
4. Kembalikan respons dalam bentuk JSON Array berisi 3 string.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "List of exactly 3 concise business insights in Indonesian based on data"
        }
      }
    });

    const insights = JSON.parse(response.text || "[]");
    res.json({ insights });
  } catch (error: any) {
    console.error("Generate Insights Error:", error);
    // Fallback static insights in Indonesian if model fails
    res.json({
      insights: [
        "Bakso Urat berkontribusi paling tinggi (42% omzet), pastikan ketersediaan stok di jam makan siang.",
        "Hari Rabu cenderung merupakan hari tersunyi, buat promo khusus untuk menarik minat pelanggan.",
        "Rata-rata penjualan Anda stabil, tingkatkan margin dengan paket bundling minuman."
      ]
    });
  }
});

// 3. Price Recommendation Engine API
app.post("/api/gemini/price-recommendation", checkApiKey, async (req, res) => {
  try {
    const { product, category, numRecentSales } = req.body;
    if (!product) {
      return res.status(400).json({ error: "Product information is required." });
    }

    const selectedModel = getPreferredModel(req, "gemini-3.1-flash-lite");

    const response = await ai.models.generateContent({
      model: selectedModel,
      contents: `Berikan rekomendasi harga optimal untuk produk UMKM berikut dalam Bahasa Indonesia.

Produk:
- Nama: ${product.name}
- Harga Jual Saat Ini: Rp ${product.price}
- Harga Modal (HPP): Rp ${product.modal}
- Stok: ${product.stock} ${product.unit}
- Kategori Usaha: ${category || "Kuliner"}
- Total Penjualan Terakhir: ${numRecentSales || 0} unit

Aturan:
1. Berikan rekomendasi kisaran harga jual optimal (misalnya "Rp 15.000 - Rp 17.000") dalam mata uang Rupiah.
2. Berikan alasan terstruktur kenapa kisaran harga tersebut optimal (misalnya berdasarkan margin keuntungan potensial, modal awal, biaya operasional, dan daya beli masyarakat umum Indonesia). Alasan harus terdiri dari 3-4 kalimat ringkas dan memotivasi.
3. Kembalikan respons dalam bentuk JSON objek sesuai skema.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            recommendedRange: { type: Type.STRING, description: "Recommended price range (e.g., 'Rp 16.000 - Rp 18.000')" },
            estimatedMarginPercent: { type: Type.INTEGER, description: "Expected margin percentage with the recommended price" },
            reasoning: { type: Type.STRING, description: "3-4 concise sentences in Indonesian explaining the reasoning and potential benefits" }
          },
          required: ["recommendedRange", "estimatedMarginPercent", "reasoning"]
        }
      }
    });

    const parsedResponse = JSON.parse(response.text || "{}");
    res.json(parsedResponse);
  } catch (error: any) {
    console.error("Price Recommendation Error:", error);
    res.status(500).json({ error: error.message || "Failed to generate price recommendation." });
  }
});

// 4. Auto-narrative Reports API
app.post("/api/gemini/report-narrative", checkApiKey, async (req, res) => {
  try {
    const { storeProfile, periodDescription, metrics, topProducts } = req.body;

    const dataPrompt = `
- Periode Laporan: ${periodDescription}
- Total Omzet: Rp ${metrics.totalRevenue}
- Total Transaksi: ${metrics.totalSalesCount}
- Estimasi Laba Bersih: Rp ${metrics.netProfit} (Margin ${metrics.marginPercent}%)
- Produk Terlaris: ${metrics.topSellingProduct}
- Usaha: ${storeProfile.name} (${storeProfile.type}) di ${storeProfile.location}
- Produk Terlaris Detail: ${JSON.stringify(topProducts || [])}
`;

    const selectedModel = getPreferredModel(req, "gemini-3.1-flash-lite");

    const response = await ai.models.generateContent({
      model: selectedModel,
      contents: `Sebagai CFO virtual yang ramah dan ahli analisis bisnis UMKM Indonesia, buatlah narasi laporan bisnis bulanan/berkala yang mendalam tetapi mudah dipahami pemilik usaha.

Data Keuangan Periode Ini:
${dataPrompt}

Aturan Penulisan:
1. Bahasanya ramah, profesional, memotivasi, dan mudah dimengerti pemilik UMKM (hindari jargon akuntansi yang terlalu rumit tanpa penjelasan).
2. Tulis dalam 3-4 paragraf yang berisi:
   - Evaluasi performa keuangan (apakah omzet naik, laba sehat, atau ada tren penurunan).
   - Analisis produk (membahas kontribusi produk terlaris seperti ${metrics.topSellingProduct} dan saran untuk optimasi stok/penjualan).
   - Saran taktis konkret (tindakan yang harus dilakukan minggu depan untuk meningkatkan pendapatan).
3. Gunakan markdown bergaya tebal (**kata**) untuk angka penting dan kesimpulan pokok.
4. Gunakan Bahasa Indonesia sepenuhnya.`,
    });

    res.json({ narrative: response.text });
  } catch (error: any) {
    console.error("Narrative Report Error:", error);
    res.status(500).json({ error: "Gagal membuat narasi laporan. Silakan coba lagi." });
  }
});

// 5. Copilot Chat Interactive API
app.post("/api/gemini/chat", checkApiKey, async (req, res) => {
  try {
    const { message, chatHistory, storeProfile, products, metrics } = req.body;

    if (!message) {
      return res.status(400).json({ error: "Message is required." });
    }

    const businessContext = {
      nama_toko: storeProfile?.name || "Toko Saya",
      jenis_usaha: storeProfile?.type || "UMKM",
      lokasi: storeProfile?.location || "Indonesia",
      target_omzet_bulanan: storeProfile?.target?.monthly || 10000000,
      daftar_produk: products || [],
      keuangan_saat_ini: metrics || {},
    };

    // Format previous chat history for Gemini API
    const contents: any[] = [];
    if (chatHistory && chatHistory.length > 0) {
      // Keep only last 10 messages for safety
      const recentHistory = chatHistory.slice(-10);
      recentHistory.forEach((msg: any) => {
        contents.push({
          role: msg.role === "user" ? "user" : "model",
          parts: [{ text: msg.text }],
        });
      });
    }

    // Append the current message
    contents.push({
      role: "user",
      parts: [{ text: message }],
    });

    const selectedModel = getPreferredModel(req, "gemini-3.1-flash-lite");

    const response = await ai.models.generateContent({
      model: selectedModel,
      contents: contents,
      config: {
        systemInstruction: `Kamu adalah Copilot, asisten keuangan dan strategi bisnis AI yang cerdas, ahli finansial, dan konsultan ramah untuk UMKM Indonesia milik {${businessContext.nama_toko}}. Hari ini adalah tanggal: ${new Date().toLocaleDateString("id-ID", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}.

DATA BISNIS TERKINI ${businessContext.nama_toko}:
- Jenis Usaha: ${businessContext.jenis_usaha}
- Lokasi: ${businessContext.lokasi}
- Target Omzet: Rp ${businessContext.target_omzet_bulanan} per bulan
- Daftar Produk Saat Ini: ${JSON.stringify(businessContext.daftar_produk)}
- Statistik Keuangan: Rata-rata laba margin ${businessContext.keuangan_saat_ini.marginPercent || 30}%, Omzet Total Penjualan: Rp ${businessContext.keuangan_saat_ini.totalRevenue || 0}, OMZET HARI INI: Rp ${businessContext.keuangan_saat_ini.todayRevenue || 0}, Laba Hari Ini: Rp ${businessContext.keuangan_saat_ini.todayNetProfit || 0}.
- Rincian Omzet Berdasarkan Hari: ${JSON.stringify(businessContext.keuangan_saat_ini.dailyRevenue || {})}

KEPRIBADIAN KAMU:
- Sangat ramah, bersahabat, peduli, profesional, dan pintar. Berperilaku seperti kombinasi direktur keuangan virtual (CFO) dan teman bicara bisnis.
- Gunakan Bahasa Indonesia yang luwes (boleh santai, pakai kata "Kamu", "Anda", "Kita", tapi tetap sopan).
- Selalu berikan rekomendasi aksi yang KONKRET, BERDASARKAN DATA, dan memiliki angka estimasi. Jangan berikan jawaban teori luas; berikan tips taktis (contoh: naikin harga Rp 1.000, bikin paket bundling nasi + es teh).
- Evaluasilah data aktual pengguna di atas saat menjawab jika relevan.
- Bantu tingkatkan laba dan pertahankan kestabilan keuangan UMKM Indonesia.

FORMAT RESPONS:
- Gunakan emoji secukupnya (1–2 per paragraf) untuk menjaga keramahan.
- Gunakan bullet points untuk item-item/rekomendasi.
- Bold (tebal) angka-angka uang, persentase, dan hal berharga.
- Gunakan format Rupiah penuh (misalnya Rp 15.000) agar profesional.
- Batasi jawaban hingga maksimal 200-250 kata kecuali pengguna menanyakan instruksi detail atau perhitungan matematika akuntansi yang rumit.
- Akhiri selalu dengan 1 pertanyaan lanjutan atau usulan tindakan nyata yang ramah.`,
      },
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Copilot Chat Error:", error);
    res.status(500).json({ error: error.message || "Gagal berdiskusi dengan Copilot." });
  }
});


// Configure Vite dev server middleware or serve production assets
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`Vite Dev Server mounted successfully on PORT ${PORT}`);
  });
}

startServer();
