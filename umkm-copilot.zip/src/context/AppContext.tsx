import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import {
  StoreProfile,
  Product,
  Transaction,
  ChatSession,
  ChatMessage,
  ToastMessage,
  PeriodMetrics,
  Expense
} from "../types";
import { demoStore, demoProducts, generateSalesData } from "../data/dummy";
import { auth, db } from "../firebase";
import { doc, collection, onSnapshot, setDoc, deleteDoc, getDocs } from "firebase/firestore";
import { handleFirestoreError, OperationType } from "../firestoreUtil";
import { onAuthStateChanged } from "firebase/auth";

interface AppContextProps {
  storeProfile: StoreProfile;
  setupComplete: boolean;
  products: Product[];
  transactions: Transaction[];
  expenses: Expense[];
  toasts: ToastMessage[];
  chatSessions: ChatSession[];
  activeChatId: string | null;
  dailyInsights: string[];
  insightsLoading: boolean;
  selectedPeriod: "7d" | "30d" | "all";
  
  completeOnboarding: (profile: StoreProfile, initialProducts: Omit<Product, "id" | "color">[], useDummy?: boolean) => void;
  resetOnboarding: () => void;
  addProduct: (p: Omit<Product, "id" | "color">) => void;
  updateProduct: (p: Product) => void;
  deleteProduct: (id: number) => void;
  addTransaction: (items: { productId: number; qty: number }[]) => void;
  deleteTransaction: (id: string) => void;
  addExpense: (expense: Omit<Expense, "id" | "timestamp" | "ownerId">) => void;
  deleteExpense: (id: string) => void;
  addToast: (message: string, type?: "success" | "error" | "info" | "warning") => void;
  removeToast: (id: string) => void;
  setSelectedPeriod: (period: "7d" | "30d" | "all") => void;
  createNewChat: () => string;
  selectChat: (id: string) => void;
  deleteChat: (id: string) => void;
  sendMessageToCopilot: (text: string) => Promise<void>;
  chatSendLoading: boolean;
  getPeriodMetrics: () => PeriodMetrics;
  getFilteredTransactions: () => Transaction[];
  refreshDailyInsights: () => Promise<void>;
  getPriceRecommendation: (product: Product) => Promise<any>;
  getNarrativeReport: (periodDesc: string, metrics: PeriodMetrics, topProducts: any[]) => Promise<string>;
  updateStoreProfile: (profile: StoreProfile) => Promise<void>;
}

const AppContext = createContext<AppContextProps | undefined>(undefined);

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used inside an AppProvider");
  return context;
};

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [storeProfile, setStoreProfile] = useState<StoreProfile>(demoStore);
  const [setupComplete, setSetupComplete] = useState<boolean>(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [chatSessions, setChatSessions] = useState<ChatSession[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [dailyInsights, setDailyInsights] = useState<string[]>([]);
  const [insightsLoading, setInsightsLoading] = useState<boolean>(false);
  const [chatSendLoading, setChatSendLoading] = useState<boolean>(false);
  const [selectedPeriod, setSelectedPeriod] = useState<"7d" | "30d" | "all">("7d");
  const [userId, setUserId] = useState<string | null>(null);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUserId(u ? u.uid : null);
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!userId) return;

    const unsubState = onSnapshot(doc(db, "users", userId, "config", "state"), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        setSetupComplete(data.setupComplete || false);
        if (data.dailyInsights) setDailyInsights(data.dailyInsights);
      }
    }, (error) => handleFirestoreError(error, OperationType.GET, `users/${userId}/config/state`));

    const unsubProfile = onSnapshot(doc(db, "users", userId, "profile", "store"), (snap) => {
      if (snap.exists()) {
        setStoreProfile(snap.data() as StoreProfile);
      }
    }, (error) => handleFirestoreError(error, OperationType.GET, `users/${userId}/profile/store`));

    const unsubProducts = onSnapshot(collection(db, "users", userId, "products"), (snap) => {
      const items = snap.docs.map(d => d.data() as Product);
      setProducts(items.length > 0 ? items : []);
    }, (error) => handleFirestoreError(error, OperationType.GET, `users/${userId}/products`));

    const unsubTx = onSnapshot(collection(db, "users", userId, "transactions"), (snap) => {
      const items = snap.docs.map(d => d.data() as Transaction);
      setTransactions(items.sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
    }, (error) => handleFirestoreError(error, OperationType.GET, `users/${userId}/transactions`));

    const unsubExp = onSnapshot(collection(db, "users", userId, "expenses"), (snap) => {
      const items = snap.docs.map(d => d.data() as Expense);
      setExpenses(items.sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
    }, (error) => handleFirestoreError(error, OperationType.GET, `users/${userId}/expenses`));

    const unsubChats = onSnapshot(collection(db, "users", userId, "chats"), (snap) => {
      const items = snap.docs.map(d => d.data() as ChatSession);
      const sorted = items.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      setChatSessions(sorted);
      if (sorted.length > 0 && !activeChatId) setActiveChatId(sorted[0].id);
    }, (error) => handleFirestoreError(error, OperationType.GET, `users/${userId}/chats`));

    return () => {
      unsubState(); unsubProfile(); unsubProducts(); unsubTx(); unsubChats(); unsubExp();
    };
  }, [userId]);

  // --- AUTO-CALIBRATOR FOR SANE CHART SCALES (PULUHAN/RATUSAN RIBU) ---
  useEffect(() => {
    if (!userId) return;
    
    // Automatically bring massive chart-breaking expenses down to normal shop scale (ratusan ribu)
    const giantExpenses = expenses.filter(e => e.amount > 3000000);
    giantExpenses.forEach(async (e) => {
      // Scale down by 1000 (e.g. 110,000,000 -> 110,000)
      const adjusted = Math.round(e.amount / 1000);
      try {
        await setDoc(doc(db, "users", userId, "expenses", e.id), {
          ...e,
          amount: adjusted
        });
        addToast(`⚙️ Kalibrasi Grafik: Pengeluaran "${e.description}" disesuaikan menjadi Rp ${adjusted.toLocaleString("id-ID")} agar grafik seimbang.`, "warning");
      } catch (err) {
        console.error("Failed auto-calibrating expense:", err);
      }
    });

    // Automatically scale down old high-volume transaction sums from older configurations
    const giantTransactions = transactions.filter(t => t.totalAmount > 3000000);
    giantTransactions.forEach(async (t) => {
      const factor = t.totalAmount > 100000000 ? 1000 : 10;
      const adjustedAmount = Math.round(t.totalAmount / factor);
      const adjustedModal = Math.round(t.totalModal / factor);
      try {
        await setDoc(doc(db, "users", userId, "transactions", t.id), {
          ...t,
          totalAmount: adjustedAmount,
          totalModal: adjustedModal,
          profit: adjustedAmount - adjustedModal
        });
      } catch (err) {
        console.error("Failed auto-calibrating transaction:", err);
      }
    });
  }, [userId, expenses, transactions]);

  const colors = ["#10B981", "#0284C7", "#7C3AED", "#F59E0B", "#DC2626", "#0891B2", "#DB2777"];

  const addToast = (message: string, type: ToastMessage["type"] = "success") => {
    const id = Math.random().toString();
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => removeToast(id), 4000);
  };

  const removeToast = (id: string) => setToasts((prev) => prev.filter((t) => t.id !== id));

  const completeOnboarding = async (profile: StoreProfile, initialProducts: Omit<Product, "id" | "color">[], useDummy: boolean = true) => {
    if (!userId) return;
    const nextProducts: Product[] = initialProducts.map((item, index) => ({
      ...item,
      id: index + 1,
      color: colors[index % colors.length],
      category: profile.type,
      ownerId: userId
    }));

    const finalProducts = nextProducts.length > 0 ? nextProducts : (useDummy ? demoProducts.map(p => ({...p, ownerId: userId})) : []);
    const finalSales = useDummy ? generateSalesData(finalProducts).map(s => ({...s, ownerId: userId})) : [];

    try {
      await setDoc(doc(db, "users", userId, "profile", "store"), { ...profile, ownerId: userId });
      
      for (const p of finalProducts) {
        await setDoc(doc(db, "users", userId, "products", p.id.toString()), p);
      }
      for (const s of finalSales) {
        await setDoc(doc(db, "users", userId, "transactions", s.id), s);
      }
      
      await setDoc(doc(db, "users", userId, "config", "state"), { setupComplete: true, dailyInsights: [], ownerId: userId });
      setSetupComplete(true);
      addToast("🚀 Onboarding berhasil! Copilot siap membantu usaha Anda.", "success");
    } catch (error: any) {
      addToast(`Gagal: ${error.message || error}`, "error");
      handleFirestoreError(error, OperationType.WRITE, `users/${userId}`);
    }
  };

  const resetOnboarding = async () => {
    if (!userId) return;
    try {
      const collections = ["products", "transactions", "expenses", "chats"];
      for (const col of collections) {
        const querySnapshot = await getDocs(collection(db, "users", userId, col));
        for (const docSnap of querySnapshot.docs) {
          await deleteDoc(docSnap.ref);
        }
      }
      
      // Clear profile and state
      await deleteDoc(doc(db, "users", userId, "profile", "store"));
      await setDoc(doc(db, "users", userId, "config", "state"), { setupComplete: false, dailyInsights: [], ownerId: userId });
      
      // Explicitly clear local states to avoid UI glitches
      setSetupComplete(false);
      setDailyInsights([]);
      setProducts([]);
      setTransactions([]);
      setExpenses([]);
      setStoreProfile({} as StoreProfile); // Need to import or let snapshot handle it if it clears gracefully
      setChatSessions([]);
      setActiveChatId(null);
      
      addToast("🔄 Semua data berhasil dihapus dan disetel ulang.", "info");
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, `users/${userId}`);
    }
  };

  const addProduct = async (p: Omit<Product, "id" | "color">) => {
    if (!userId) return;
    const newId = products.length > 0 ? Math.max(...products.map((item) => item.id)) + 1 : 1;
    const newColor = colors[products.length % colors.length];
    const newProd: Product = { ...p, id: newId, color: newColor, ownerId: userId };
    
    try {
      await setDoc(doc(db, "users", userId, "products", newId.toString()), newProd);
      addToast(`📦 "${p.name}" sukses ditambahkan.`, "success");
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `users/${userId}/products`);
    }
  };

  const updateProduct = async (p: Product) => {
    if (!userId) return;
    try {
      await setDoc(doc(db, "users", userId, "products", p.id.toString()), { ...p, ownerId: userId });
      addToast(`📦 "${p.name}" berhasil diubah.`, "success");
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `users/${userId}/products`);
    }
  };

  const deleteProduct = async (id: number) => {
    if (!userId) return;
    try {
      await deleteDoc(doc(db, "users", userId, "products", id.toString()));
      addToast(`📦 Produk telah dihapus.`, "warning");
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `users/${userId}/products`);
    }
  };

  const addTransaction = async (itemsInput: { productId: number; qty: number }[]) => {
    if (!userId) return;
    const items: any[] = [];
    let totalAmount = 0, totalModal = 0;

    itemsInput.forEach((input) => {
      const prod = products.find((p) => p.id === input.productId);
      if (prod) {
        items.push({
          productId: prod.id, name: prod.name, qty: input.qty,
          price: prod.price, modal: prod.modal,
        });
        totalAmount += prod.price * input.qty;
        totalModal += prod.modal * input.qty;
      }
    });

    if (items.length === 0) {
      addToast("Gagal menyimpan transaksi. Tidak ada item produk.", "error"); return;
    }

    const nowIso = new Date().toISOString();
    const cleanDate = new Date();
    const txId = `TX-${cleanDate.getFullYear()}${(cleanDate.getMonth() + 1).toString().padStart(2, "0")}${cleanDate.getDate().toString().padStart(2, "0")}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newTx: Transaction = {
      id: txId, timestamp: nowIso, items, totalAmount, totalModal, profit: totalAmount - totalModal, ownerId: userId
    };

    try {
      await setDoc(doc(db, "users", userId, "transactions", txId), newTx);
      itemsInput.forEach(async (input) => {
        const prod = products.find(p => p.id === input.productId);
        if (prod) await setDoc(doc(db, "users", userId, "products", prod.id.toString()), { ...prod, stock: Math.max(0, prod.stock - input.qty), ownerId: userId });
      });
      addToast(`✅ Transaksi ${txId} berhasil disimpan!`, "success");
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `users/${userId}/transactions`);
    }
  };

  const deleteTransaction = async (id: string) => {
    if (!userId) return;
    try {
      const toDelete = transactions.find((t) => t.id === id);
      if (toDelete) {
        for (const item of toDelete.items) {
          const prod = products.find(p => p.id === item.productId);
          if (prod) await setDoc(doc(db, "users", userId, "products", prod.id.toString()), { ...prod, stock: prod.stock + item.qty, ownerId: userId });
        }
      }
      await deleteDoc(doc(db, "users", userId, "transactions", id));
      addToast(`🗑️ Transaksi ${id} dibatalkan dan pasokan stok dipulihkan.`, "warning");
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `users/${userId}/transactions`);
    }
  };

  const addExpense = async (expInput: Omit<Expense, "id" | "timestamp" | "ownerId">) => {
    if (!userId) return;

    const expId = `EXP-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
    const newExp: Expense = {
      ...expInput,
      id: expId,
      timestamp: new Date().toISOString(),
      ownerId: userId
    };

    try {
      await setDoc(doc(db, "users", userId, "expenses", expId), newExp);
      addToast(`✅ Pengeluaran ${expInput.category} berhasil dicatat!`, "success");
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `users/${userId}/expenses`);
    }
  };

  const deleteExpense = async (id: string) => {
    if (!userId) return;
    try {
      await deleteDoc(doc(db, "users", userId, "expenses", id));
      addToast(`🗑️ Pengeluaran dibatalkan.`, "warning");
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `users/${userId}/expenses`);
    }
  };

  const updateStoreProfile = async (profile: StoreProfile) => {
    if (!userId) return;
    try {
      await setDoc(doc(db, "users", userId, "profile", "store"), { ...profile, ownerId: userId });
      addToast("⚙️ Profil toko berhasil diperbarui!", "success");
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `users/${userId}/profile/store`);
    }
  };

  const getFilteredTransactions = (): Transaction[] => {
    const now = new Date();
    let limitDate = new Date();
    limitDate.setHours(0, 0, 0, 0);
    if (selectedPeriod === "7d") limitDate.setDate(now.getDate() - 6);
    else if (selectedPeriod === "30d") limitDate.setDate(now.getDate() - 29);
    else return transactions;
    return transactions.filter((t) => new Date(t.timestamp) >= limitDate);
  };

  const getFilteredExpenses = (): Expense[] => {
    const now = new Date();
    let limitDate = new Date();
    limitDate.setHours(0, 0, 0, 0);
    if (selectedPeriod === "7d") limitDate.setDate(now.getDate() - 6);
    else if (selectedPeriod === "30d") limitDate.setDate(now.getDate() - 29);
    else return expenses;
    return expenses.filter((e) => new Date(e.timestamp) >= limitDate);
  };

  const getPeriodMetrics = (): PeriodMetrics => {
    const list = getFilteredTransactions();
    const expList = getFilteredExpenses();
    let totalRevenue = 0, totalModal = 0, totalExp = 0;
    const prodCounts: { [name: string]: number } = {};
    const dailyRev: Record<string, number> = {};

    let todayRevenue = 0;
    let todayModal = 0;
    let todayExp = 0;
    const todayStr = new Date().toDateString();

    list.forEach((t) => {
      totalRevenue += t.totalAmount;
      totalModal += t.totalModal;
      t.items.forEach((it) => prodCounts[it.name] = (prodCounts[it.name] || 0) + it.qty);
      
      const date = new Date(t.timestamp);
      if (date.toDateString() === todayStr) {
        todayRevenue += t.totalAmount;
        todayModal += t.totalModal;
      }
      
      // Group by exact date string to avoid summing multiple same-days across weeks
      const dateString = date.toLocaleDateString("id-ID", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
      dailyRev[dateString] = (dailyRev[dateString] || 0) + t.totalAmount;
    });

    expList.forEach((e) => {
      totalExp += e.amount;
      const date = new Date(e.timestamp);
      if (date.toDateString() === todayStr) {
        todayExp += e.amount;
      }
    });

    const netProfit = totalRevenue - totalModal - totalExp;
    const marginPercent = totalRevenue > 0 ? Math.round((netProfit / totalRevenue) * 100) : 0;

    let topSellingProduct = "Belum Ada", topSellingProductCount = 0;
    Object.entries(prodCounts).forEach(([name, count]) => {
      if (count > topSellingProductCount) { topSellingProduct = name; topSellingProductCount = count; }
    });

    return { 
      totalRevenue, 
      totalSalesCount: list.length, 
      netProfit, 
      marginPercent, 
      topSellingProduct, 
      topSellingProductCount, 
      dailyRevenue: dailyRev,
      todayRevenue,
      todayNetProfit: todayRevenue - todayModal - todayExp
    };
  };

  const refreshDailyInsights = async () => {
    if (insightsLoading || !userId) return;
    setInsightsLoading(true);
    try {
      const response = await fetch("/api/gemini/insights", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ storeProfile, products, last30DaysTransactions: transactions.slice(0, 100) }),
      });
      const data = await response.json();
      if (data.insights && Array.isArray(data.insights)) {
        await setDoc(doc(db, "users", userId, "config", "state"), { setupComplete, dailyInsights: data.insights, ownerId: userId });
        addToast("💡 Insight harian Copilot diperbarui!", "success");
      }
    } catch (error) {
      const fallback = ["Bakso Urat berkontribusi paling tinggi (42% omzet), pastikan ketersediaan stok di jam makan siang.", "Hari Rabu cenderung merupakan hari tersunyi, buat promo khusus untuk menarik minat pelanggan.", "Rata-rata penjualan Anda stabil, tingkatkan margin dengan paket bundling minuman."];
      await setDoc(doc(db, "users", userId, "config", "state"), { setupComplete, dailyInsights: fallback, ownerId: userId });
    } finally {
      setInsightsLoading(false);
    }
  };

  useEffect(() => {
    if (setupComplete && dailyInsights.length === 0 && userId) refreshDailyInsights();
  }, [setupComplete, dailyInsights, userId]);

  const getPriceRecommendation = async (product: Product) => {
    const list = transactions.filter((t) => t.items.some((it) => it.productId === product.id));
    const count = list.reduce((acc, t) => acc + (t.items.find((item) => item.productId === product.id)?.qty || 0), 0);
    try {
      const response = await fetch("/api/gemini/price-recommendation", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ product, category: storeProfile.type, numRecentSales: count }),
      });
      return await response.json();
    } catch (error) {
      const optimalPrice = Math.round(product.modal * 1.8), estPrice = optimalPrice + (5000 - (optimalPrice % 1000));
      return { recommendedRange: `Rp ${product.modal * 1.5} - Rp ${estPrice}`, estimatedMarginPercent: Math.round(((estPrice - product.modal) / estPrice) * 100), reasoning: "Rekomendasi dihitung berdasarkan modal." };
    }
  };

  const getNarrativeReport = async (periodDesc: string, metrics: PeriodMetrics, topProducts: any[]) => {
    try {
      const response = await fetch("/api/gemini/report-narrative", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ storeProfile, periodDescription: periodDesc, metrics, topProducts }),
      });
      return (await response.json()).narrative;
    } catch (error) {
      return `### Laporan - ${storeProfile.name}\nOmzet: Rp ${metrics.totalRevenue}`;
    }
  };

  const createNewChat = (): string => {
    if (!userId) return "";
    const cleanId = `CHAT-${Date.now()}`;
    const newSession: ChatSession = {
      id: cleanId, title: `Diskusi Bisnis #${chatSessions.length + 1}`, date: new Date().toLocaleDateString("id-ID"), ownerId: userId,
      messages: [{ id: "MSG-INIT", role: "model", text: `Halo! Saya Copilot, asisten ${storeProfile.name}.`, timestamp: new Date().toISOString() }],
    };
    setDoc(doc(db, "users", userId, "chats", cleanId), newSession).catch(e => handleFirestoreError(e, OperationType.CREATE, `users/${userId}/chats`));
    setActiveChatId(cleanId);
    addToast("＋ Diskusi Copilot baru dimulai.", "info");
    return cleanId;
  };

  const selectChat = (id: string) => setActiveChatId(id);

  const deleteChat = async (id: string) => {
    if (!userId) return;
    await deleteDoc(doc(db, "users", userId, "chats", id)).catch(e => handleFirestoreError(e, OperationType.DELETE, `users/${userId}/chats`));
    addToast("🗑️ Sesi diskusi dihapus.", "warning");
  };

  const sendMessageToCopilot = async (text: string) => {
    if (!text.trim() || !activeChatId || !userId) return;
    setChatSendLoading(true);
    const userMsg: ChatMessage = { id: `USER-${Date.now()}`, role: "user", text, timestamp: new Date().toISOString() };
    const currentSession = chatSessions.find(s => s.id === activeChatId);
    if (!currentSession) return;

    const newTitle = currentSession.messages.length === 1 ? text.substring(0, 30) + "..." : currentSession.title;
    const updatedUserSession = { ...currentSession, title: newTitle, messages: [...currentSession.messages, userMsg], ownerId: userId };
    await setDoc(doc(db, "users", userId, "chats", activeChatId), updatedUserSession);

    try {
      const response = await fetch("/api/gemini/chat", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, chatHistory: currentSession.messages.slice(0, -1), storeProfile, products, metrics: getPeriodMetrics() }),
      });
      const data = await response.json();
      const replyMsg: ChatMessage = { id: `MODEL-${Date.now()}`, role: "model", text: data.text || "...", timestamp: new Date().toISOString() };
      await setDoc(doc(db, "users", userId, "chats", activeChatId), { ...updatedUserSession, messages: [...updatedUserSession.messages, replyMsg] });
    } catch (e) {
      await setDoc(doc(db, "users", userId, "chats", activeChatId), { ...updatedUserSession, messages: [...updatedUserSession.messages, { id: `MODEL-ERR-${Date.now()}`, role: "model", text: "Maaf, jaringan saya terganggu.", timestamp: new Date().toISOString() }] });
    } finally {
      setChatSendLoading(false);
    }
  };

  return (
    <AppContext.Provider value={{ storeProfile, setupComplete, products, transactions, expenses, toasts, chatSessions, activeChatId, dailyInsights, insightsLoading, selectedPeriod, completeOnboarding, resetOnboarding, addProduct, updateProduct, deleteProduct, addTransaction, deleteTransaction, addExpense, deleteExpense, addToast, removeToast, setSelectedPeriod, createNewChat, selectChat, deleteChat, sendMessageToCopilot, chatSendLoading, getPeriodMetrics, getFilteredTransactions, refreshDailyInsights, getPriceRecommendation, getNarrativeReport, updateStoreProfile }}>
      {children}
    </AppContext.Provider>
  );
};
