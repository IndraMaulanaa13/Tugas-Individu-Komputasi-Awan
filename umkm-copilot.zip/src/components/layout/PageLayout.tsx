import React from "react";
import { CheckCircle2, AlertCircle, Info, AlertTriangle, X } from "lucide-react";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import BottomNav from "./BottomNav";
import { useApp } from "../../context/AppContext";

interface PageLayoutProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  children: React.ReactNode;
}

export default function PageLayout({ activeTab, setActiveTab, children }: PageLayoutProps) {
  const { toasts, removeToast } = useApp();

  return (
    <div className="flex w-screen h-screen bg-[var(--bg-page)] overflow-hidden font-sans text-stone-700 antialiased">
      {/* Sidebar for Desktop */}
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Panel Content */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        <Topbar activeTab={activeTab} />
        
        {/* Main scrollable body area */}
        <main className="flex-1 overflow-y-auto px-4 md:px-8 py-6 pb-24 md:pb-8">
          <div className="max-w-7xl mx-auto space-y-6">
            {children}
          </div>
        </main>

        {/* Bottom Nav for Mobile */}
        <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
      </div>

      {/* GLOBAL BANNER TOAST NOTIFICATIONS */}
      <div className="fixed bottom-20 md:bottom-6 right-6 left-6 md:left-auto z-50 flex flex-col gap-3 max-w-sm" id="toast-wrapper">
        {toasts.map((toast) => {
          return (
            <div
              key={toast.id}
              className="flex items-center justify-between gap-3 bg-stone-900 text-stone-100 px-4 py-3 rounded-2xl shadow-xl border border-stone-800 animate-slide-up transform duration-150"
            >
              <div className="flex items-center gap-2.5">
                {toast.type === "success" && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />}
                {toast.type === "error" && <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />}
                {toast.type === "warning" && <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />}
                {toast.type === "info" && <Info className="w-5 h-5 text-sky-400 shrink-0" />}
                <span className="text-xs font-semibold font-body leading-relaxed">{toast.message}</span>
              </div>
              <button
                onClick={() => removeToast(toast.id)}
                className="text-stone-400 hover:text-white p-0.5 rounded-full hover:bg-stone-800 transition duration-150"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
