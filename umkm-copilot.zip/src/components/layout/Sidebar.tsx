import React from "react";
import {
  LayoutDashboard,
  ClipboardList,
  Wallet,
  BarChart3,
  Sparkles,
  Package,
  LogOut
} from "lucide-react";
import { useApp } from "../../context/AppContext";
import { signOut } from "firebase/auth";
import { auth } from "../../firebase";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  const { storeProfile } = useApp();

  const menuItems = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "catat", label: "Catat Penjualan", icon: ClipboardList },
    { id: "pengeluaran", label: "Catat Pengeluaran", icon: Wallet },
    { id: "analitik", label: "Analitik", icon: BarChart3 },
    { id: "copilot", label: "Copilot AI", icon: Sparkles },
    { id: "produk", label: "Produk Saya", icon: Package },
  ];

  return (
    <aside className="hidden md:flex flex-col w-64 h-screen text-stone-100 bg-[var(--bg-sidebar)] shrink-0 z-20 border-r border-[#085a44] relative shadow-xl">
      {/* Decorative gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/20 pointer-events-none" />
      
      {/* Logo Area */}
      <div className="flex items-center gap-3 h-[72px] px-6 border-b border-white/10 shrink-0 z-10">
        <div className="flex items-center justify-center w-11 h-11 rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 text-white font-black text-xl shadow-lg ring-2 ring-emerald-500/20">
          UC
        </div>
        <div className="flex flex-col">
          <span className="font-heading font-extrabold text-lg tracking-tight text-white leading-none">
            UMKM Copilot
          </span>
          <span className="text-[10px] text-emerald-200 font-bold mt-1 uppercase tracking-widest leading-none">
            CFO Virtual Anda
          </span>
        </div>
      </div>

      {/* Nav Link Items */}
      <nav className="flex-1 py-6 px-4 space-y-1.5 overflow-y-auto z-10 scrollbar-hide">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center w-full h-[46px] px-4 text-[13.5px] font-semibold rounded-xl transition-all duration-200 ${
                isActive
                  ? "bg-white/10 text-white shadow-inner backdrop-blur-md ring-1 ring-white/10 pl-5"
                  : "text-emerald-50/70 hover:bg-white/5 hover:text-white"
              }`}
            >
              <Icon className={`w-[20px] h-[20px] mr-3 ${isActive ? "text-emerald-300 drop-shadow-[0_0_8px_rgba(52,211,153,0.5)]" : "text-emerald-100/50"}`} />
              {item.label}
            </button>
          );
        })}
        
        {/* Divider */}
        <div className="my-4 border-t border-white/10" />
      </nav>

      {/* Profile Bar */}
      <div className="p-4 border-t border-[#053d2e] bg-[#032f22]/50 shrink-0 flex items-center justify-between z-10 w-full">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="flex items-center justify-center w-10 h-10 rounded-full bg-emerald-600 font-black text-sm text-white uppercase shadow-md border-2 border-emerald-400/30 flex-shrink-0">
            {storeProfile?.owner?.avatar || "BS"}
          </div>
          <div className="flex flex-col truncate">
            <span className="text-[13px] font-bold leading-none text-white truncate">
              {storeProfile?.owner?.name || "Budi Santoso"}
            </span>
            <span className="text-[10.5px] text-emerald-200/80 font-medium truncate mt-1">
              {storeProfile?.name || "Warung Bakso Pak Budi"}
            </span>
          </div>
        </div>
        
        <button 
          onClick={async () => await signOut(auth)}
          title="Keluar / Logout"
          className="p-2 ml-1 text-emerald-100/50 hover:text-rose-400 hover:bg-rose-950/30 rounded-xl transition-all"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </aside>
  );
}
