import React from "react";
import {
  LayoutDashboard,
  ClipboardList,
  BarChart3,
  Wallet,
  Sparkles,
  Package
} from "lucide-react";

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function BottomNav({ activeTab, setActiveTab }: BottomNavProps) {
  const navItems = [
    { id: "dashboard", label: "Utama", icon: LayoutDashboard },
    { id: "catat", label: "Catat", icon: ClipboardList },
    { id: "pengeluaran", label: "Pengeluaran", icon: Wallet },
    { id: "analitik", label: "Grafik", icon: BarChart3 },
    { id: "copilot", label: "Copilot", icon: Sparkles },
    { id: "produk", label: "Produk", icon: Package },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-white border-t border-stone-200 flex items-center justify-around px-2 pb-safe z-40 shadow-2xl">
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = activeTab === item.id;

        return (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`flex flex-col items-center justify-center w-14 h-14 font-semibold text-[10px] transition duration-150 font-sans cursor-pointer ${
              isActive ? "text-emerald-600 scale-105" : "text-stone-400"
            }`}
          >
            <Icon className={`w-5 h-5 mb-1 ${isActive ? "text-emerald-600" : "text-stone-400"}`} />
            <span>{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
