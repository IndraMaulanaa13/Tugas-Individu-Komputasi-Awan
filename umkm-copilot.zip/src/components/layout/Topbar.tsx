import React, { useState } from "react";
import { createPortal } from "react-dom";
import { Bell, Menu, Sparkles, AlertTriangle, Calendar, LogOut, Settings, User, Building2, MapPin, Target, X } from "lucide-react";
import { useApp } from "../../context/AppContext";
import { formatFullDate } from "../../utils/date";
import { signOut } from "firebase/auth";
import { auth } from "../../firebase";

interface TopbarProps {
  activeTab: string;
  onMenuClick?: () => void;
}

export default function Topbar({ activeTab }: TopbarProps) {
  const { storeProfile, products, getPeriodMetrics, resetOnboarding, addToast, updateStoreProfile } = useApp();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  
  // Settings edit states
  const [showSettings, setShowSettings] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [inputOwnerName, setInputOwnerName] = useState("");
  const [inputStoreName, setInputStoreName] = useState("");
  const [inputStoreType, setInputStoreType] = useState("");
  const [inputLocation, setInputLocation] = useState("");
  const [inputMonthlyTarget, setInputMonthlyTarget] = useState(5000000);
  const [inputAiModel, setInputAiModel] = useState("gemini-3.1-flash-lite");

  // Derive notifications from stock levels and performance metrics
  const lowStockProds = products.filter((p) => p.stock <= 5);
  const metrics = getPeriodMetrics();
  const isBelowTarget = metrics.totalRevenue < storeProfile.target.monthly * 0.42;

  const notificationsList: { id: string; text: string; type: "alert" | "info" }[] = [];

  if (lowStockProds.length > 0) {
    lowStockProds.forEach((p) => {
      notificationsList.push({
        id: `STK-${p.id}`,
        text: `Pemasokan "${p.name}" kritis (Tinggal ${p.stock} ${p.unit})! Hari ini segera ambil stok baru.`,
        type: "alert",
      });
    });
  }

  if (isBelowTarget) {
    notificationsList.push({
      id: "TARGET-ALERT",
      text: "Target omzet bulanan masih di bawah 42% pertengahan jalan. Diskusikan promo bareng Copilot!",
      type: "info",
    });
  }

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    const ownerNameTrimmed = inputOwnerName.trim();
    const storeNameTrimmed = inputStoreName.trim();
    if (!ownerNameTrimmed || !storeNameTrimmed) {
      addToast("Nama pemilik dan nama toko tidak boleh kosong!", "error");
      return;
    }
    const initials = ownerNameTrimmed
      ? ownerNameTrimmed.split(" ").slice(0, 2).map((w) => w[0]).join("").toUpperCase()
      : "US";
      
    const updatedProfile = {
      ...storeProfile,
      name: storeNameTrimmed,
      type: inputStoreType,
      location: inputLocation.trim(),
      owner: { name: ownerNameTrimmed, avatar: initials },
      target: { monthly: Number(inputMonthlyTarget) },
      aiModel: inputAiModel
    };
    
    setIsSaving(true);
    try {
      await updateStoreProfile(updatedProfile);
      setShowSettings(false);
    } catch (err) {
      console.error(err);
      addToast("Gagal menyimpan pengaturan profil", "error");
    } finally {
      setIsSaving(false);
    }
  };

  const tabTitles: { [key: string]: string } = {
    dashboard: "Dashboard Usaha",
    catat: "Catat Penjualan Baru",
    pengeluaran: "Pencatatan Pengeluaran",
    analitik: "Analisis & Laba Keuangan",
    copilot: "Diskusi AI Copilot",
    produk: "Kelola Produk Saya",
  };

  return (
    <header className="sticky top-0 right-0 left-0 h-[72px] bg-white/80 backdrop-blur-md border-b border-stone-200/60 flex items-center justify-between px-8 z-30 shadow-sm shrink-0">
      {/* Title */}
      <div className="flex items-center gap-3">
        <h1 className="font-heading font-extrabold text-xl text-stone-900 tracking-tight">
          {tabTitles[activeTab] || "UMKM Copilot"}
        </h1>
      </div>

      {/* Greeting and date (desktop) */}
      <div className="hidden lg:flex items-center gap-2 text-stone-500 font-medium text-xs">
        <Calendar className="w-4 h-4 text-emerald-600" />
        <span>{formatFullDate(new Date())}</span>
      </div>

      {/* Right activities */}
      <div className="flex items-center gap-4 relative">
        {/* Notification Bell */}
        <button
          onClick={() => setShowNotifications(!showNotifications)}
          className="relative w-10 h-10 rounded-full hover:bg-stone-100 flex items-center justify-center text-stone-600 transition duration-150 border border-stone-100 focus:outline-none"
        >
          <Bell className="w-[18px] h-[18px]" />
          {notificationsList.length > 0 && (
            <span className="absolute top-2.5 right-2 w-2.5 h-2.5 bg-red-500 text-white font-black rounded-full ring-2 ring-white animate-bounce" />
          )}
        </button>

        {/* Notification Panel Modal-dropdown */}
        {showNotifications && (
          <div className="absolute right-0 top-12 w-[340px] max-h-[420px] bg-white border border-stone-200 rounded-2xl shadow-xl z-50 overflow-y-auto overflow-x-hidden p-4">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100 mb-2">
              <span className="font-heading font-extrabold text-stone-800 text-sm">Notifikasi Usaha</span>
              <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                {notificationsList.length} Baru
              </span>
            </div>

            <div className="space-y-2 py-2">
              {notificationsList.length === 0 ? (
                <div className="flex flex-col items-center justify-center text-center py-8 text-stone-400">
                  <Sparkles className="w-10 h-10 text-emerald-500/30 mb-2 animate-bounce" />
                  <p className="text-xs font-semibold">Toko Aman! Tidak ada peringatan stok atau keuangan harian.</p>
                </div>
              ) : (
                notificationsList.map((n) => (
                  <div
                    key={n.id}
                    className={`flex gap-3 p-3 rounded-xl border text-xs leading-relaxed ${
                      n.type === "alert"
                        ? "bg-rose-50 border-rose-100 text-rose-800"
                        : "bg-amber-50 border-amber-100 text-amber-800"
                    }`}
                  >
                    {n.type === "alert" ? (
                      <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0" />
                    ) : (
                      <Sparkles className="w-4 h-4 text-amber-500 shrink-0" />
                    )}
                    <p className="font-semibold">{n.text}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Quick visual store owner status indicator */}
        <div className="flex items-center gap-2 border-l border-stone-200 pl-4 relative">
          {showResetConfirm ? (
            <div className="absolute right-12 top-0 bg-white border border-rose-200 shadow-lg rounded-xl p-3 w-48 text-right flex flex-col items-end gap-2 z-50">
              <span className="text-[10px] font-bold text-rose-600">Yakin hapus SEMUA data?</span>
              <div className="flex gap-2">
                <button
                  onClick={() => setShowResetConfirm(false)}
                  className="bg-stone-100 text-stone-600 text-[10px] px-2 py-1 rounded-md font-bold"
                >Batal</button>
                <button
                  onClick={() => {
                    addToast("Menghapus data mohon tunggu...", "info");
                    resetOnboarding();
                    setShowResetConfirm(false);
                  }}
                  className="bg-rose-500 text-white text-[10px] px-2 py-1 rounded-md font-bold"
                >Ya, Hapus</button>
              </div>
            </div>
          ) : null}
          
          <div 
            onClick={() => {
              setInputOwnerName(storeProfile?.owner?.name || "Budi Santoso");
              setInputStoreName(storeProfile?.name || "Toko Anda");
              setInputStoreType(storeProfile?.type || "Kuliner");
              setInputLocation(storeProfile?.location || "Surabaya");
              setInputMonthlyTarget(storeProfile?.target?.monthly || 5000000);
              setInputAiModel(storeProfile?.aiModel || "gemini-3.1-flash-lite");
              setShowSettings(true);
            }}
            className="flex items-center gap-2 cursor-pointer hover:opacity-85 transition-all duration-150 pl-1"
          >
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-emerald-600 font-black text-xs text-white uppercase leading-none shadow-sm shadow-emerald-700/20">
              {storeProfile?.owner?.avatar || "BS"}
            </div>
            <div className="hidden sm:flex flex-col pr-1">
              <span className="text-[11px] font-extrabold text-stone-800 leading-tight truncate max-w-[100px]">
                {storeProfile?.owner?.name || "Budi Santoso"}
              </span>
              <span className="text-[9px] text-stone-400 font-bold leading-none">Pemilik</span>
            </div>
          </div>
          
          <div className="border-l border-stone-200 pl-2 h-6 flex items-center gap-1">
            <button 
              onClick={() => {
                setInputOwnerName(storeProfile?.owner?.name || "Budi Santoso");
                setInputStoreName(storeProfile?.name || "Toko Anda");
                setInputStoreType(storeProfile?.type || "Kuliner");
                setInputLocation(storeProfile?.location || "Surabaya");
                setInputMonthlyTarget(storeProfile?.target?.monthly || 5000000);
                setInputAiModel(storeProfile?.aiModel || "gemini-3.1-flash-lite");
                setShowSettings(true);
              }}
              title="Pengaturan Profil"
              className="p-1.5 text-stone-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition cursor-pointer"
            >
              <Settings className="w-4 h-4" />
            </button>
            <button 
              onClick={() => setShowResetConfirm(!showResetConfirm)}
              title="Hapus & Reset Data"
              className="p-1.5 text-stone-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition cursor-pointer"
            >
              <AlertTriangle className="w-4 h-4" />
            </button>
            <button 
              onClick={async () => await signOut(auth)}
              title="Keluar / Logout"
              className="p-1.5 text-stone-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Profile/User Settings Modal */}
      {showSettings && createPortal(
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-sm flex items-center justify-center z-[9999] p-4 text-left">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-stone-200/80 overflow-hidden text-stone-700 animate-in fade-in zoom-in-95 duration-200 flex flex-col max-h-[85vh] relative z-[10000]">
            {/* Sticky Header */}
            <div className="px-5 py-4 border-b border-stone-100 flex items-center justify-between bg-stone-50 shrink-0">
              <div className="text-left">
                <h2 className="font-heading font-extrabold text-stone-900 text-base">Pengaturan Profil</h2>
                <p className="text-[10px] font-extrabold text-stone-400 uppercase tracking-wider">Perbarui Data & Nama User</p>
              </div>
              <button
                type="button"
                onClick={() => setShowSettings(false)}
                className="text-stone-400 hover:text-stone-600 p-1.5 hover:bg-stone-100 rounded-xl transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form wrapping body and footer for proper validation submission */}
            <form onSubmit={handleSaveSettings} className="flex flex-col flex-1 min-h-0 text-left">
              {/* Scrollable Form body */}
              <div className="p-5 space-y-3.5 overflow-y-auto flex-1 min-h-0">
                {/* Nama Pemilik / User */}
                <div>
                  <label className="block text-xs font-bold uppercase text-stone-500 mb-1">
                    Nama Pemilik / User <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 w-4 h-4 text-stone-400" />
                    <input
                      type="text"
                      required
                      value={inputOwnerName}
                      onChange={(e) => setInputOwnerName(e.target.value)}
                      placeholder="contoh: Budi Santoso"
                      className="w-full h-10 pl-9 pr-3 rounded-xl border border-stone-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition outline-none font-sans font-semibold text-stone-850 text-xs"
                    />
                  </div>
                </div>

                {/* Nama Toko */}
                <div>
                  <label className="block text-xs font-bold uppercase text-stone-500 mb-1">
                    Nama Toko / Usaha <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <Building2 className="absolute left-3 top-3 w-4 h-4 text-stone-400" />
                    <input
                      type="text"
                      required
                      value={inputStoreName}
                      onChange={(e) => setInputStoreName(e.target.value)}
                      placeholder="contoh: Bakso Sapi Nikmat"
                      className="w-full h-10 pl-9 pr-3 rounded-xl border border-stone-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition outline-none font-sans font-semibold text-stone-850 text-xs"
                    />
                  </div>
                </div>

                {/* Kota */}
                <div>
                  <label className="block text-xs font-bold uppercase text-stone-500 mb-1">
                    Kota Toko Berdiri <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 w-4 h-4 text-stone-400" />
                    <input
                      type="text"
                      required
                      value={inputLocation}
                      onChange={(e) => setInputLocation(e.target.value)}
                      placeholder="contoh: Jakarta"
                      className="w-full h-10 pl-9 pr-3 rounded-xl border border-stone-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition outline-none font-sans font-semibold text-stone-850 text-xs"
                    />
                  </div>
                </div>

                {/* Kategori */}
                <div>
                  <label className="block text-xs font-bold uppercase text-stone-500 mb-1">
                    Kategori Bisnis
                  </label>
                  <select
                    value={inputStoreType}
                    onChange={(e) => setInputStoreType(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl border border-stone-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition outline-none font-sans font-semibold text-stone-850 text-xs bg-stone-50"
                  >
                    <option value="Kuliner">Kuliner (Makanan & Minuman)</option>
                    <option value="Sembako / Kelontong">Sembako / Kelontong</option>
                    <option value="Fashion / Retail">Fashion / Retail</option>
                    <option value="Jasa / Service">Jasa / Service</option>
                    <option value="Lainnya">Lainnya</option>
                  </select>
                </div>

                {/* Target Bulanan */}
                <div>
                  <label className="block text-xs font-bold uppercase text-stone-500 mb-1">
                    Target Omzet Bulanan (Rp) <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <Target className="absolute left-3 top-3 w-4 h-4 text-stone-400" />
                    <input
                      type="number"
                      required
                      min={1}
                      value={inputMonthlyTarget}
                      onChange={(e) => setInputMonthlyTarget(Number(e.target.value))}
                      placeholder="contoh: 5000000"
                      className="w-full h-10 pl-9 pr-3 rounded-xl border border-stone-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition outline-none font-sans font-semibold text-stone-850 text-xs"
                    />
                  </div>
                </div>

                {/* Model AI Pilihan */}
                <div>
                  <label className="block text-xs font-bold uppercase text-stone-500 mb-1">
                    Model AI Copilot <span className="text-amber-500 font-extrabold">(Sangat Penting!)</span>
                  </label>
                  <select
                    value={inputAiModel}
                    onChange={(e) => setInputAiModel(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl border border-stone-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition outline-none font-sans font-semibold text-stone-850 text-xs bg-stone-50"
                  >
                    <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash Lite (Cepat & Hemat Limit 15 RPM)</option>
                    <option value="gemini-3.5-flash">Gemini 3.5 Flash (Smarter - Limit 5 RPM)</option>
                    <option value="gemini-3.1-pro-preview">Gemini 3.1 Pro (Preview - Kompleks, butuh Paid Key)</option>
                  </select>
                  <p className="text-[10px] text-stone-400 mt-1 font-semibold leading-relaxed">
                    *Gunakan <strong className="text-emerald-600">3.1 Flash Lite</strong> jika Anda sering terkena rate limit kuota harian. Model ini 3x lebih hemat limit dibanding 3.5 Flash!
                  </p>
                </div>
              </div>

              {/* Sticky Footer Actions */}
              <div className="p-5 border-t border-stone-100 bg-stone-50 shrink-0 flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowSettings(false)}
                  className="flex-1 h-10 bg-stone-100 hover:bg-stone-200 text-stone-600 font-extrabold text-[11px] uppercase tracking-wider rounded-xl transition cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="flex-1 h-10 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-extrabold text-[11px] uppercase tracking-wider rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/10"
                >
                  {isSaving ? "Menyimpan..." : "Simpan Perubahan"}
                </button>
              </div>
            </form>
          </div>
        </div>,
        document.body
      )}
    </header>
  );
}
