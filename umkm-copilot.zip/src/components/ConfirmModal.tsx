import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { AlertTriangle, Trash2, HelpCircle, X } from "lucide-react";

interface ConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  variant?: "danger" | "warning" | "info";
}

export default function ConfirmModal({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  confirmText = "Ya, Hapus",
  cancelText = "Batal",
  variant = "danger",
}: ConfirmModalProps) {
  // Determine color theme based on variant
  const getColors = () => {
    switch (variant) {
      case "danger":
        return {
          iconBg: "bg-rose-50 text-rose-600 border-rose-100",
          icon: Trash2,
          confirmBtn: "bg-rose-600 hover:bg-rose-700 text-white focus:ring-rose-500 shadow-rose-100",
          glow: "shadow-rose-100/30",
        };
      case "warning":
        return {
          iconBg: "bg-amber-50 text-amber-600 border-amber-100",
          icon: AlertTriangle,
          confirmBtn: "bg-amber-500 hover:bg-amber-600 text-white focus:ring-amber-500 shadow-amber-100",
          glow: "shadow-amber-100/30",
        };
      case "info":
      default:
        return {
          iconBg: "bg-emerald-50 text-emerald-600 border-emerald-100",
          icon: HelpCircle,
          confirmBtn: "bg-emerald-600 hover:bg-emerald-700 text-white focus:ring-emerald-500 shadow-emerald-100",
          glow: "shadow-emerald-100/30",
        };
    }
  };

  const colors = getColors();
  const IconComponent = colors.icon;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-stone-900/60 backdrop-blur-sm"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ type: "spring", duration: 0.35, bounce: 0.15 }}
            id="confirmation-modal-dialog"
            className={`relative bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl border border-stone-100 p-6 md:p-8 flex flex-col items-center text-center ${colors.glow}`}
          >
            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-1.5 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-50 transition duration-150 cursor-pointer"
              aria-label="Tutup"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Icon Banner */}
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center border ${colors.iconBg} mb-5 mt-2`}>
              <IconComponent className="w-6 h-6" />
            </div>

            {/* Title & Body message */}
            <h3 className="font-sans font-extrabold text-lg text-stone-800 tracking-tight leading-tight mb-2">
              {title}
            </h3>
            <p className="font-sans text-xs text-stone-500 font-medium leading-relaxed px-2 mb-6">
              {message}
            </p>

            {/* Action Buttons */}
            <div className="flex gap-3 w-full mt-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-3 text-xs font-extrabold text-stone-600 border border-stone-200 hover:border-stone-300 hover:bg-stone-50 rounded-2xl cursor-pointer duration-150 active:scale-98 transition text-center"
              >
                {cancelText}
              </button>
              <button
                type="button"
                onClick={() => {
                  onConfirm();
                  onClose();
                }}
                className={`flex-1 py-3 text-xs font-extrabold rounded-2xl cursor-pointer duration-150 active:scale-98 transition text-center shadow-md ${colors.confirmBtn}`}
              >
                {confirmText}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
