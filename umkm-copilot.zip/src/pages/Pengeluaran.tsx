import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { Wallet, Trash2, CalendarDays, Search, ListFilter, ClipboardList } from "lucide-react";
import { formatRupiah } from "../utils/currency";
import { formatFullDate, formatTimeOnly } from "../utils/date";

export default function Pengeluaran() {
  const { expenses, addExpense, deleteExpense, addToast } = useApp();
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState<number | "">("");
  const [category, setCategory] = useState<"Bahan Baku" | "Operasional" | "Lainnya">("Operasional");

  // Filter States
  const [viewHistory, setViewHistory] = useState<"today" | "all">("today");
  const [expenseSearch, setExpenseSearch] = useState("");
  const [expenseCategoryFilter, setExpenseCategoryFilter] = useState<"Semua" | "Bahan Baku" | "Operasional" | "Lainnya">("Semua");

  const todayExpenses = expenses.filter(e => {
    const d = new Date(e.timestamp);
    const today = new Date();
    return d.getDate() === today.getDate() &&
           d.getMonth() === today.getMonth() &&
           d.getFullYear() === today.getFullYear();
  });

  const getFilteredExpenses = () => {
    let list = viewHistory === "today" ? todayExpenses : expenses;
    
    if (expenseSearch.trim()) {
      const q = expenseSearch.toLowerCase();
      list = list.filter(e => e.description.toLowerCase().includes(q));
    }
    
    if (expenseCategoryFilter !== "Semua") {
      list = list.filter(e => e.category === expenseCategoryFilter);
    }
    
    return list;
  };

  const filteredExpensesList = getFilteredExpenses();
  const filteredTotalValue = filteredExpensesList.reduce((acc, e) => acc + e.amount, 0);

  const handleSave = () => {
    if (!description.trim()) {
      addToast("Deskripsi pengeluaran wajib diisi!", "error");
      return;
    }
    if (!amount || Number(amount) <= 0) {
      addToast("Jumlah nominal pengeluaran harus lebih besar dari Rp 0!", "error");
      return;
    }
    addExpense({ description: description.trim(), amount: Number(amount), category });
    addToast(`Pengeluaran "${description.trim()}" berhasil dicatat!`, "success");
    setDescription("");
    setAmount("");
  };

  const handleDelete = (id: string, desc: string) => {
    deleteExpense(id);
    addToast(`Catatan pengeluaran "${desc}" berhasil dihapus!`, "success");
  };

  return (
    <div className="max-w-4xl pt-6 pb-20 md:pb-6 space-y-6 animate-in slide-in-from-bottom-2 duration-300 relative z-10 px-4 md:px-0">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-200 pb-5">
        <div>
          <h2 className="font-heading text-xl md:text-2xl font-black text-stone-900 tracking-tight flex items-center gap-2">
            Catat Pengeluaran Baru
          </h2>
          <p className="text-stone-500 font-medium text-xs mt-1 md:mt-0 flex items-center gap-1.5 line-clamp-1">
            <CalendarDays className="w-3.5 h-3.5 text-stone-400" />
            {formatFullDate(new Date())}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 py-6">
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white border text-stone-600 border-[#e5e5e5] rounded-3xl p-6 shadow-sm">
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase text-stone-400 tracking-wider mb-2">Deskripsi</label>
                <input
                  type="text"
                  placeholder="Contoh: Beli Ayam 2kg, Token Listrik, dsb..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full h-12 bg-stone-50/50 border border-stone-200 text-stone-900 font-bold px-4 rounded-xl focus:border-rose-400 focus:ring-4 focus:ring-rose-400/20 transition outline-none text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-stone-400 tracking-wider mb-2">Jumlah Nominal (Rp)</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 font-extrabold text-stone-400 text-sm">Rp</span>
                  <input
                    type="number"
                    min="0"
                    placeholder="25000"
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="w-full h-12 bg-stone-50/50 border border-stone-200 text-stone-900 font-bold px-4 pl-10 rounded-xl focus:border-rose-400 focus:ring-4 focus:ring-rose-400/20 transition outline-none text-sm font-sans"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-stone-400 tracking-wider mb-2">Pilih Kategori</label>
                <div className="grid grid-cols-3 gap-3">
                  {(["Bahan Baku", "Operasional", "Lainnya"] as const).map(cat => (
                    <button
                      key={cat}
                      onClick={() => setCategory(cat)}
                      className={`px-3 py-3 rounded-xl text-[11px] font-extrabold transition-all border cursor-pointer ${
                        category === cat ? "bg-rose-50 text-rose-700 border-rose-300 ring-4 ring-rose-50" : "bg-white text-stone-500 border-stone-200 hover:bg-stone-50 hover:border-stone-300"
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-8 pt-4 border-t border-stone-100">
              <button
                onClick={handleSave}
                disabled={!description || !amount}
                className="w-full h-14 bg-stone-900 hover:bg-stone-800 disabled:opacity-50 disabled:bg-stone-200 disabled:text-stone-450 disabled:cursor-not-allowed text-white font-extrabold text-sm rounded-2xl transition duration-200 shadow-md hover:shadow-lg disabled:shadow-none flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98]"
              >
                <Wallet className="w-5 h-5 text-stone-300" />
                Catat Pengeluaran
              </button>
            </div>
          </div>
        </div>

        {/* --- RECEIPT PREVIEW PANEL --- */}
        <div className="lg:col-span-5 relative">
          <div className="sticky top-6 space-y-4">
            
            {/* Toggle Segmented Control (Short-term UI Win) */}
            <div className="flex justify-between items-center bg-stone-100 p-1 rounded-2xl border border-stone-200/50 shadow-sm">
              <button
                onClick={() => {
                  setViewHistory("today");
                  setExpenseSearch("");
                  setExpenseCategoryFilter("Semua");
                }}
                className={`flex-1 py-1.5 text-xs font-black uppercase text-center rounded-xl cursor-pointer duration-150-out transition ${
                  viewHistory === "today" ? "bg-white text-rose-700 shadow-sm" : "text-stone-500 hover:text-stone-800"
                }`}
              >
                Hari Ini
              </button>
              <button
                onClick={() => setViewHistory("all")}
                className={`flex-1 py-1.5 text-xs font-black uppercase text-center rounded-xl cursor-pointer duration-150-out transition ${
                  viewHistory === "all" ? "bg-white text-rose-700 shadow-sm" : "text-stone-500 hover:text-stone-800"
                }`}
              >
                Semua Riwayat
              </button>
            </div>

            <div className="bg-[#fcfaf8] border border-[#e7e5e4] rounded-[24px] p-5 md:p-6 shadow-[0px_8px_32px_-12px_rgba(0,0,0,0.1)] relative space-y-4">
              
              <div className="flex justify-between items-center bg-rose-50 p-3.5 rounded-2xl border border-rose-100 shrink-0">
                 <span className="text-xs font-black text-rose-800 uppercase tracking-wide">
                   Total {viewHistory === "today" ? "Hari Ini" : "Saringan"}
                 </span>
                 <span className="font-heading font-black text-rose-900 text-lg font-mono">
                   {formatRupiah(filteredTotalValue)}
                 </span>
              </div>

              {/* Advanced Filters inside Receipt Card */}
              <div className="space-y-2.5">
                {/* Search Bar Input */}
                <div className="relative">
                  <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-stone-400" />
                  <input
                    type="text"
                    value={expenseSearch}
                    onChange={(e) => setExpenseSearch(e.target.value)}
                    placeholder="Cari deskripsi pengeluaran..."
                    className="w-full h-9 pl-9 pr-3 bg-white border border-stone-200 focus:border-rose-400 focus:ring-1 focus:ring-rose-400/20 text-xs font-bold rounded-xl transition outline-none"
                  />
                </div>

                {/* Category Pills inside box */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {(["Semua", "Bahan Baku", "Operasional", "Lainnya"] as const).map(cat => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setExpenseCategoryFilter(cat)}
                      className={`px-2.5 py-1 rounded-lg text-[9px] font-extrabold uppercase transition border cursor-pointer ${
                        expenseCategoryFilter === cat 
                          ? "bg-rose-100 text-rose-800 border-rose-200" 
                          : "bg-white text-stone-500 border-stone-200 hover:bg-stone-50"
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Expense List listing */}
              <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
                {filteredExpensesList.length === 0 ? (
                  <div className="text-center py-10">
                    <p className="text-xs font-bold text-stone-400">Tidak ada pengeluaran yang cocok.</p>
                  </div>
                ) : (
                  filteredExpensesList.map((exp) => (
                    <div key={exp.id} className="group hover:bg-white bg-stone-50 border border-stone-200 hover:border-rose-200 p-3.5 rounded-2xl transition duration-200 shadow-sm hover:shadow relative overflow-hidden flex flex-col gap-1.5">
                       <div className="flex justify-between items-start gap-4">
                          <div>
                            <p className="font-bold text-stone-800 text-xs">{exp.description}</p>
                            <span className="text-[9px] font-extrabold px-2 py-0.5 rounded bg-stone-200 text-stone-600 mt-1 inline-block uppercase tracking-wider">{exp.category}</span>
                          </div>
                          <div className="shrink-0 text-right">
                            <p className="font-extrabold font-sans text-rose-600 text-xs tracking-tight">- {formatRupiah(exp.amount)}</p>
                            <p className="text-[9px] font-semibold text-stone-400 mt-1">
                              {viewHistory === "all" ? formatFullDate(new Date(exp.timestamp)) : formatTimeOnly(new Date(exp.timestamp))}
                            </p>
                          </div>
                       </div>
                       
                       <div className="absolute right-0 top-0 bottom-0 bg-gradient-to-l from-rose-100 via-rose-50/80 to-transparent w-16 opacity-0 group-hover:opacity-100 flex items-center justify-end px-3 transition-all duration-300 translate-x-4 group-hover:translate-x-0">
                          <button
                            onClick={() => handleDelete(exp.id, exp.description)}
                            className="bg-white text-rose-600 hover:bg-rose-600 hover:text-white p-1.5 rounded-lg shadow-sm transition duration-200 cursor-pointer hover:shadow-md"
                            title="Hapus Pengeluaran"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                       </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
