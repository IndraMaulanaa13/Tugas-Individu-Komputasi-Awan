import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { Product } from "../types";
import { formatRupiah } from "../utils/currency";
import ConfirmModal from "../components/ConfirmModal";
import {
  Package,
  Plus,
  Search,
  Edit2,
  Trash2,
  Sparkles,
  AlertTriangle,
  X,
  RefreshCw,
  TrendingUp,
  Percent,
  Warehouse
} from "lucide-react";

export default function Produk() {
  const {
    products,
    addProduct,
    updateProduct,
    deleteProduct,
    getPriceRecommendation,
    addToast
  } = useApp();

  const [searchQuery, setSearchQuery] = useState("");
  const [filterMode, setFilterMode] = useState<"all" | "low" | "high">("all");

  // modal editing/creating states
  const [modalOpen, setModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);

  // form fields states
  const [formName, setFormName] = useState("");
  const [formPrice, setFormPrice] = useState(15000);
  const [formModal, setFormModal] = useState(8000);
  const [formStock, setFormStock] = useState(50);
  const [formUnit, setFormUnit] = useState("porsi");
  const [formDesc, setFormDesc] = useState("");

  // AI Price recommender pane
  const [aiRecommenderOpen, setAiRecommenderOpen] = useState(false);
  const [aiRecProduct, setAiRecProduct] = useState<Product | null>(null);
  const [aiRecData, setAiRecData] = useState<any>(null);
  const [aiRecLoading, setAiRecLoading] = useState(false);

  // Confirmation states
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);

  // --- FILTERS LOGIC ---
  const filteredProducts = products.filter((p) => {
    // Search
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Pills
    if (filterMode === "low") {
      return matchesSearch && p.stock <= 5;
    } else if (filterMode === "high") {
      const margin = Math.round(((p.price - p.modal) / p.price) * 100);
      return matchesSearch && margin >= 50;
    }
    return matchesSearch;
  });

  // --- MODAL TRIGGER CREATING/EDITING HANDLERS ---
  const handleOpenCreateModal = () => {
    setIsEditing(false);
    setEditId(null);
    setFormName("");
    setFormPrice(15000);
    setFormModal(8000);
    setFormStock(50);
    setFormUnit("porsi");
    setFormDesc("");
    setModalOpen(true);
  };

  const handleOpenEditModal = (p: Product) => {
    setIsEditing(true);
    setEditId(p.id);
    setFormName(p.name);
    setFormPrice(p.price);
    setFormModal(p.modal);
    setFormStock(p.stock);
    setFormUnit(p.unit || "unit");
    setFormDesc(p.description || "");
    setModalOpen(true);
  };

  const handleSaveForm = () => {
    if (!formName.trim()) {
      addToast("Nama produk wajib diisi!", "error");
      return;
    }
    if (formPrice <= formModal) {
      addToast("Harga jual produk harus lebih besar dibandingkan harga modal (HPP)!", "error");
      return;
    }

    const itemPayload = {
      name: formName,
      price: formPrice,
      modal: formModal,
      stock: formStock,
      unit: formUnit,
      description: formDesc,
    };

    if (isEditing && editId !== null) {
      const existing = products.find((p) => p.id === editId);
      if (existing) {
        updateProduct({
          ...existing,
          ...itemPayload,
        });
      }
    } else {
      addProduct(itemPayload);
    }

    setModalOpen(false);
  };

  // Live margin computations helper
  const getModalMarginCalculations = () => {
    if (formPrice <= 0) return { margin: 0, nominal: 0, scale: "red" };
    const nominal = formPrice - formModal;
    const margin = Math.round((nominal / formPrice) * 100); // Correct margin calculation (use standard percentage out of 100)
    
    let scale = "red";
    if (margin > 40) scale = "green";
    else if (margin > 20) scale = "yellow";

    return { margin, nominal, scale };
  };

  const formMarginStats = getModalMarginCalculations();

  // --- TRIGGER COPILOT PRICE RECOMMENDATIONS VIA SERVER API ---
  const handleTriggerAIPriceRecommendation = async (p: Product) => {
    setAiRecProduct(p);
    setAiRecData(null);
    setAiRecLoading(true);
    setAiRecommenderOpen(true);

    try {
      const response = await getPriceRecommendation(p);
      setAiRecData(response);
      addToast(`Saran harga optimal AI untuk ${p.name} siap!`, "success");
    } catch (e: any) {
      addToast("Modul AI gagal merekomendasi harga.", "error");
      setAiRecommenderOpen(false);
    } finally {
      setAiRecLoading(false);
    }
  };

  return (
    <div className="space-y-8 max-w-[1400px] mx-auto">
      {/* Upper select query bar */}
      <div className="bg-white rounded-2xl md:rounded-3xl p-4 md:p-6 flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm border border-stone-100">
        <div className="flex flex-col md:flex-row items-center gap-4 w-full md:w-auto">
          {/* Search bar query input */}
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3.5 top-3 w-4 h-4 text-stone-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari menu produk..."
              className="w-full h-11 pl-10 pr-4 bg-stone-50 border border-stone-200 focus:border-stone-400 focus:bg-white rounded-xl text-xs font-bold outline-none transition-all duration-200"
            />
          </div>

          {/* Filter Pills */}
          <div className="flex bg-stone-100 p-1 rounded-2xl w-full md:w-auto border border-stone-200/40">
            <button
              onClick={() => setFilterMode("all")}
              className={`flex-1 md:flex-none px-4 py-2 rounded-xl text-xs font-bold cursor-pointer transition ${
                filterMode === "all" ? "bg-white text-stone-900 shadow-sm font-extrabold" : "text-stone-500 hover:text-stone-800"
              }`}
            >
              Semua
            </button>
            <button
              onClick={() => setFilterMode("low")}
              className={`flex-1 md:flex-none px-4 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition ${
                filterMode === "low" ? "bg-white text-red-600 shadow-sm font-extrabold" : "text-stone-500 hover:text-stone-800"
              }`}
            >
              Stok Kritis ⚠
            </button>
            <button
              onClick={() => setFilterMode("high")}
              className={`flex-1 md:flex-none px-4 py-2 rounded-xl text-xs font-bold cursor-pointer transition ${
                filterMode === "high" ? "bg-white text-emerald-700 shadow-sm font-extrabold" : "text-stone-500 hover:text-stone-800"
              }`}
            >
              Margin Tinggi
            </button>
          </div>
        </div>

        {/* Create button trigger */}
        <button
          onClick={handleOpenCreateModal}
          className="h-11 px-6 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-[0_4px_12px_rgba(5,150,105,0.18)] hover:shadow-[0_8px_20px_rgba(5,150,105,0.25)] transition transform active:scale-[0.98] flex items-center gap-2 w-full md:w-auto justify-center cursor-pointer"
        >
          <Plus className="w-4 h-4 text-white" />
          Tambah Produk Baru
        </button>
      </div>

      {/* MATRIX LISTS OF PRODUCTS CARDS IN COLS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6" id="products-grid">
        {filteredProducts.map((p) => {
          const initials = p.name.substring(0, 2).toUpperCase();
          const margin = Math.round(((p.price - p.modal) / p.price) * 100);

          // stock colors
          let stockPillColor = "bg-emerald-50 text-emerald-800 border border-emerald-100/40";
          let stockPillText = "Stok Sehat";
          if (p.stock === 0) {
            stockPillColor = "bg-red-500 text-white font-black shadow-sm";
            stockPillText = "Habis";
          } else if (p.stock <= 5) {
            stockPillColor = "bg-rose-50 text-rose-700 font-extrabold animate-pulse border border-rose-100";
            stockPillText = `Kritis: Sisa ${p.stock}`;
          } else if (p.stock <= 20) {
            stockPillColor = "bg-amber-50 text-amber-700 font-extrabold border border-amber-100";
            stockPillText = `Sisa ${p.stock}`;
          }

          return (
            <div
              key={p.id}
              className="bg-white border border-stone-100 rounded-3xl flex flex-col justify-between hover:shadow-xl hover:-translate-y-0.5 transition-all duration-300 select-none group relative overflow-hidden"
            >
              {/* Card top banner header */}
              <div className="p-6 space-y-5">
                <div className="flex items-start justify-between gap-2">
                  {/* avatar */}
                  <div
                    className="w-12 h-12 rounded-2xl text-white font-black text-sm flex items-center justify-center uppercase shadow-md shrink-0 ring-4 ring-stone-50"
                    style={{ backgroundColor: p.color || "#10B981" }}
                  >
                    {initials}
                  </div>
                  {/* stock status */}
                  <span className={`px-3 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider leading-none shrink-0 ${stockPillColor}`}>
                    {stockPillText}
                  </span>
                </div>

                <div className="space-y-1">
                  <h4 className="font-heading font-black text-stone-900 text-base truncate leading-none">
                    {p.name}
                  </h4>
                  <p className="font-heading font-black text-emerald-700 text-xl leading-none pt-2.5 font-mono">
                    {formatRupiah(p.price)}
                  </p>
                </div>

                {/* brief stats modal vs margin */}
                <div className="grid grid-cols-2 gap-2 bg-stone-50/50 p-3.5 rounded-2xl text-[10px] leading-relaxed select-none font-semibold border border-stone-200/40">
                  <div>
                    <span className="text-stone-400 font-extrabold uppercase tracking-wider block leading-none">Modal HPP</span>
                    <span className="text-stone-700 font-extrabold mt-1.5 block font-mono leading-none">{formatRupiah(p.modal)}</span>
                  </div>
                  <div className="border-l border-stone-200/60 pl-3.5">
                    <span className="text-stone-400 font-extrabold uppercase tracking-wider block leading-none">Margin Laba</span>
                    <span className={`font-black mt-1.5 block font-mono leading-none ${margin > 35 ? "text-emerald-700" : margin > 20 ? "text-amber-600" : "text-rose-600"}`}>
                      {margin}% Laba
                    </span>
                  </div>
                </div>

                {/* Progress stock bar */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-[9px] text-stone-400 font-extrabold uppercase tracking-wider leading-none">
                    <span>Persediaan Stok</span>
                    <span>{p.stock} {p.unit || "unit"}</span>
                  </div>
                  <div className="h-2 w-full bg-stone-100 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-300"
                      style={{
                        width: `${Math.min(100, (p.stock / 100) * 100)}%`,
                        backgroundColor: p.color || "#10B981"
                      }}
                    />
                  </div>
                </div>
              </div>

              {/* Card Footer overlays edits / removes triggers */}
              <div className="border-t border-stone-100 p-4 bg-stone-50/40 flex items-center justify-between gap-2">
                {/* Asah AI button trigger */}
                <button
                  onClick={() => handleTriggerAIPriceRecommendation(p)}
                  className="flex items-center justify-center gap-1.5 text-[10px] font-extrabold text-stone-800 border border-stone-200 hover:border-emerald-500 bg-white hover:bg-emerald-50 hover:text-emerald-800 px-3.5 py-2 rounded-xl shadow-xs cursor-pointer transition"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  Asah Harga AI
                </button>

                <div className="flex gap-1 shrink-0">
                  <button
                    onClick={() => handleOpenEditModal(p)}
                    className="p-2 text-stone-400 hover:text-emerald-700 hover:bg-white rounded-xl cursor-pointer transition border border-transparent hover:border-stone-200"
                    title="Ubah Detail"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      setProductToDelete(p);
                      setConfirmOpen(true);
                    }}
                    className="p-2 text-stone-400 hover:text-rose-600 hover:bg-white rounded-xl cursor-pointer transition border border-transparent hover:border-stone-200"
                    title="Hapus Produk"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* PRODUCTS CREATE / EDIT POPUP MODAL DIALOG */}
      {modalOpen && (
        <div className="fixed inset-0 bg-stone-900/50 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl border border-stone-100 animate-slide-up duration-200 p-6 md:p-8 flex flex-col max-h-[90vh]">
            {/* Header */}
            <div className="flex justify-between items-center pb-5 border-b border-stone-100 shrink-0">
              <h3 className="font-heading font-black text-stone-900 text-base flex items-center gap-2 select-none">
                <Warehouse className="w-5 h-5 text-emerald-600" />
                {isEditing ? "Ubah Detail Menu Produk" : "Tambahkan Menu Kuliner Baru"}
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="p-1.5 text-stone-400 hover:text-stone-800 rounded-xl hover:bg-stone-100 cursor-pointer transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form scroll inputs */}
            <div className="flex-1 py-5 overflow-y-auto space-y-5 pr-1">
              <div>
                <label className="block text-[10px] font-bold uppercase text-stone-400 tracking-wider mb-2">Nama Menu Kuliner</label>
                <input
                  type="text"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="contoh: Bakso Sapi Jumbo"
                  className="w-full h-11 px-4 border border-stone-200 font-bold text-xs text-stone-800 bg-stone-50/50 hover:bg-white focus:bg-white focus:border-stone-400 transition rounded-xl outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold uppercase text-stone-400 tracking-wider mb-2">Harga Modal (HPP)</label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-3.5 text-xs text-stone-400 font-bold leading-none select-none">Rp</span>
                    <input
                      type="number"
                      value={formModal === 0 ? "" : formModal}
                      onChange={(e) => setFormModal(parseInt(e.target.value, 10) || 0)}
                      placeholder="8000"
                      className="w-full h-11 pl-9 pr-3 border border-stone-200 font-bold text-xs text-stone-800 bg-stone-50/50 hover:bg-white focus:bg-white focus:border-stone-400 transition rounded-xl outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase text-stone-400 tracking-wider mb-2">Harga Jual Konsumen</label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-3.5 text-xs text-emerald-600 font-bold leading-none select-none">Rp</span>
                    <input
                      type="number"
                      value={formPrice === 0 ? "" : formPrice}
                      onChange={(e) => setFormPrice(parseInt(e.target.value, 10) || 0)}
                      placeholder="15000"
                      className="w-full h-11 pl-9 pr-3 border border-emerald-200 font-black text-xs text-emerald-800 bg-emerald-50/10 hover:bg-white focus:bg-white focus:border-emerald-500 transition rounded-xl outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Dynamic Live Margin statistics */}
              <div className={`p-4 rounded-xl border flex items-center justify-between text-xs font-bold leading-none shrink-0 transition-colors duration-200 ${
                formMarginStats.scale === "green"
                  ? "bg-emerald-50/50 border-emerald-100 text-emerald-800"
                  : formMarginStats.scale === "yellow"
                  ? "bg-amber-50 border-amber-100 text-amber-800"
                  : "bg-rose-50 border-rose-100 text-rose-800"
              }`}>
                <span className="uppercase text-[9px] text-stone-400 font-extrabold tracking-wider leading-none">Keuntungan Margin</span>
                <span>Margin Anda: {formMarginStats.margin}% ({formatRupiah(formMarginStats.nominal)} per item)</span>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold uppercase text-stone-400 tracking-wider mb-2">Persediaan Stok Awal</label>
                  <input
                    type="number"
                    value={formStock === 0 ? "" : formStock}
                    onChange={(e) => setFormStock(parseInt(e.target.value, 10) || 0)}
                    placeholder="50"
                    className="w-full h-11 px-4 border border-stone-200 font-bold text-xs text-stone-800 bg-stone-50/50 hover:bg-white focus:bg-white focus:border-stone-400 transition rounded-xl outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase text-stone-400 tracking-wider mb-2">Satuan Ukuran</label>
                  <select
                    value={formUnit}
                    onChange={(e) => setFormUnit(e.target.value)}
                    className="w-full h-11 px-4 border border-stone-200 font-bold text-xs text-stone-800 bg-stone-50/50 hover:bg-white focus:bg-white focus:border-stone-400 transition rounded-xl outline-none cursor-pointer"
                  >
                    <option value="porsi">Porsi</option>
                    <option value="gelas">Gelas</option>
                    <option value="pcs">Pcs</option>
                    <option value="buah">Buah</option>
                    <option value="bungkus">Bungkus</option>
                    <option value="botol">Botol</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-stone-400 tracking-wider mb-2">Catatan/Deskripsi</label>
                <textarea
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  placeholder="Opsional: masukkan bumbu/racikan rahasia resep..."
                  rows={2}
                  className="w-full p-4 border border-stone-200 font-bold text-xs text-stone-800 bg-stone-50/50 hover:bg-white focus:bg-white focus:border-stone-400 transition rounded-xl outline-none resize-none leading-relaxed"
                />
              </div>
            </div>

            {/* Actions */}
            <div className="grid grid-cols-2 gap-4 shrink-0 border-t border-stone-100 pt-5 mt-2">
              <button
                onClick={() => setModalOpen(false)}
                className="h-11 border border-stone-200 hover:bg-stone-50 rounded-xl text-stone-500 text-xs font-bold cursor-pointer transition"
              >
                Batal
              </button>
              <button
                onClick={handleSaveForm}
                className="h-11 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black cursor-pointer shadow-md transition duration-150 transform active:scale-97"
              >
                Simpan Produk
              </button>
            </div>
          </div>
        </div>
      )}

      {/* AI PRICE RECOMMENDER SIDE PANE MODAL DIALOG */}
      {aiRecommenderOpen && (
        <div className="fixed inset-0 bg-stone-900/50 backdrop-blur-md flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl border border-stone-100 animate-slide-up duration-200 p-6 md:p-8 flex flex-col max-h-[85vh]">
            
            <div className="flex justify-between items-center pb-5 border-b border-stone-100 shrink-0">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-505 text-amber-500 animate-pulse" />
                <h3 className="font-heading font-black text-stone-900 text-base">Rekomendasi Harga AI</h3>
              </div>
              <button
                onClick={() => setAiRecommenderOpen(false)}
                className="p-1.5 text-stone-400 hover:text-stone-800 rounded-xl hover:bg-stone-50 cursor-pointer transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Loading */}
            {aiRecLoading && (
              <div className="flex-1 py-16 flex flex-col items-center justify-center text-center space-y-4">
                <RefreshCw className="w-10 h-10 text-emerald-600 animate-spin" />
                <p className="text-xs font-medium italic text-stone-400 leading-relaxed px-4">Copilot sedang menganalisis modal produk, daya beli wilayah, dan margins kompetitif harian...</p>
              </div>
            )}

            {/* Completed */}
            {!aiRecLoading && aiRecData && (
              <div className="flex-1 py-5 overflow-y-auto space-y-5 text-xs font-bold leading-relaxed pr-1">
                <div className="bg-stone-50 border border-stone-200/50 p-4 rounded-2xl">
                  <span className="text-[9px] text-stone-400 uppercase font-black tracking-wider block">Menu Kuliner</span>
                  <span className="text-sm font-black text-stone-800 mt-1.5 block leading-none">{aiRecProduct?.name}</span>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-emerald-50/50 p-4 rounded-2xl border border-emerald-100/55">
                    <span className="text-[9px] text-emerald-700 font-extrabold uppercase tracking-wider block leading-none font-sans">Harga Optimal</span>
                    <span className="text-xs font-black text-emerald-800 mt-2 block leading-none font-mono">{aiRecData.recommendedRange}</span>
                  </div>
                  <div className="bg-amber-50/50 p-4 rounded-2xl border border-amber-100/55">
                    <span className="text-[9px] text-amber-700 font-extrabold uppercase tracking-wider block leading-none font-sans">Estimasi Margin</span>
                    <span className="text-xs font-black text-amber-800 mt-2 block leading-none font-mono">{aiRecData.estimatedMarginPercent}% Laba</span>
                  </div>
                </div>

                <div className="p-5 bg-stone-900 border border-stone-800 rounded-2xl text-stone-100 shadow-inner">
                  <span className="text-[9px] text-emerald-400 uppercase font-black tracking-widest block leading-none">Penalaran Strategis AI Gemini</span>
                  <p className="mt-3 text-[11px] leading-relaxed font-medium text-stone-300 font-sans">
                    {aiRecData.reasoning}
                  </p>
                </div>
              </div>
            )}

            <button
              onClick={() => setAiRecommenderOpen(false)}
              className="w-full h-11 bg-stone-900 hover:bg-black text-white shrink-0 mt-4 rounded-xl font-extrabold text-xs cursor-pointer shadow transition"
            >
              Mengerti, Terima Kasih AI!
            </button>
          </div>
        </div>
      )}

      {/* CUSTOM CONFIRMATION DIALOG MODAL */}
      <ConfirmModal
        isOpen={confirmOpen}
        onClose={() => {
          setConfirmOpen(false);
          setProductToDelete(null);
        }}
        onConfirm={() => {
          if (productToDelete) {
            deleteProduct(productToDelete.id);
            addToast(`Produk "${productToDelete.name}" berhasil dihapus!`, "success");
          }
        }}
        title="Hapus Produk?"
        message={`Tindakan ini akan menghapus produk "${productToDelete?.name}" secara permanen dari daftar dagangan Anda.`}
        confirmText="Ya, Hapus"
        cancelText="Batal"
        variant="danger"
      />
    </div>
  );
}
