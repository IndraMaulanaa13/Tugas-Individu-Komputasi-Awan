import React, { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { formatRupiah, formatShortRupiah } from "../utils/currency";
import { formatCompactDate, formatFullDate } from "../utils/date";
import {
  TrendingUp,
  BarChart3,
  Calendar,
  Sparkles,
  ArrowDown,
  ArrowUp,
  ChevronDown,
  Download,
  CheckSquare,
  FileSpreadsheet,
  Activity,
  Heart,
  HelpCircle,
  FileText,
  RefreshCw
} from "lucide-react";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from "recharts";

export default function Analitik() {
  const {
    storeProfile,
    products,
    transactions,
    selectedPeriod,
    setSelectedPeriod,
    getPeriodMetrics,
    getFilteredTransactions,
    getNarrativeReport,
    addToast
  } = useApp();

  const [viewMode, setViewMode] = useState<"chart" | "table">("chart");
  const [productSortField, setProductSortField] = useState<"qty" | "revenue" | "margin">("qty");
  const [productSortAsc, setProductSortAsc] = useState(false);

  // --- AI Report narrative generation ---
  const [narrativeText, setNarrativeText] = useState("");
  const [narrativeLoading, setNarrativeLoading] = useState(false);

  // Checkboxes for recommendations
  const [checklist, setChecklist] = useState<boolean[]>([false, false, false]);

  const metrics = getPeriodMetrics();
  const list = getFilteredTransactions();

  // --- DERIVE WEEKDAY DAILY TOTALS & STATS ---
  const weekdayNamesIndonesian = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"];
  const weekdayNamesShort = ["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"];

  // Find average per day rate
  const numDaysMap = new Set(list.map(t => new Date(t.timestamp).toDateString())).size;
  const averagePerDay = numDaysMap > 0 ? Math.round(metrics.totalRevenue / numDaysMap) : 0;

  // Best selling day
  const bestDayStats = () => {
    const map: { [date: string]: number } = {};
    list.forEach(t => {
      const dStr = new Date(t.timestamp).toDateString();
      map[dStr] = (map[dStr] || 0) + t.totalAmount;
    });

    let bestDate = "Belum Ada";
    let maxRev = 0;
    Object.entries(map).forEach(([dStr, val]) => {
      if (val > maxRev) {
        bestDate = formatCompactDate(new Date(dStr));
        maxRev = val;
      }
    });

    return { bestDate, maxRev };
  };

  const { bestDate, maxRev } = bestDayStats();

  // --- RECHARTS AREA CHART DATA MODULE ---
  const assembleBarChartData = () => {
    const list = getFilteredTransactions();
    const daysMap: { [dateKey: string]: { label: string; dateObj: Date; Omzet: number } } = {};

    const now = new Date();
    const daysToPad = selectedPeriod === "7d" ? 7 : (selectedPeriod === "30d" ? 30 : 0);
    
    if (daysToPad > 0) {
      for (let i = daysToPad - 1; i >= 0; i--) {
        const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
        const dateKey = d.toDateString();
        daysMap[dateKey] = {
          label: formatCompactDate(d),
          dateObj: d,
          Omzet: 0
        };
      }
    }

    list.forEach(t => {
      const d = new Date(t.timestamp);
      const dateKey = d.toDateString();
      if (!daysMap[dateKey]) {
        daysMap[dateKey] = {
          label: formatCompactDate(d),
          dateObj: d,
          Omzet: 0
        };
      }
      daysMap[dateKey].Omzet += t.totalAmount;
    });

    return Object.values(daysMap)
      .sort((a, b) => a.dateObj.getTime() - b.dateObj.getTime())
      .map(item => ({
        Tanggal: item.label,
        Omzet: item.Omzet
      }));
  };

  const barChartData = assembleBarChartData();

  // --- RECHARTS PIE CHART DATA MODULE ---
  const assemblePieChartData = () => {
    const counts: { [name: string]: { value: number; color: string } } = {};
    list.forEach(tx => {
      tx.items.forEach(it => {
        const prod = products.find(p => p.id === it.productId);
        const name = it.name;
        if (!counts[name]) {
          counts[name] = { value: 0, color: prod?.color || "#10B981" };
        }
        counts[name].value += (it.price * it.qty);
      });
    });

    return Object.entries(counts).map(([name, item]) => ({
      name,
      value: item.value,
      color: item.color
    }));
  };

  const pieChartData = assemblePieChartData();

  // --- SORT INTERACTIVES PRODUCT MATRIX MODULE ---
  const assembleFullProductsInfo = () => {
    const map: { [id: number]: { id: number; name: string; qty: number; revenue: number; margin: number; color: string } } = {};

    // Initial fill from store
    products.forEach(p => {
      map[p.id] = {
        id: p.id,
        name: p.name,
        qty: 0,
        revenue: 0,
        margin: Math.round(((p.price - p.modal) / p.price) * 100),
        color: p.color
      };
    });

    // Populate actuals
    list.forEach(tx => {
      tx.items.forEach(it => {
        if (map[it.productId]) {
          map[it.productId].qty += it.qty;
          map[it.productId].revenue += (it.price * it.qty);
        }
      });
    });

    const result = Object.values(map);

    // Sort
    return result.sort((a, b) => {
      let multiplier = productSortAsc ? 1 : -1;
      if (productSortField === "qty") {
        return (a.qty - b.qty) * multiplier;
      } else if (productSortField === "revenue") {
        return (a.revenue - b.revenue) * multiplier;
      } else {
        return (a.margin - b.margin) * multiplier;
      }
    });
  };

  const productSortedList = assembleFullProductsInfo();

  // --- INTERACTIVE HORARY 2-HOURLY HEATMAP GEN MODULE ---
  const assembleHeatmapStats = () => {
    // Row 0-6: Monday to Sunday (mon=0, sun=6)
    // Col 0-5: 08-10, 10-12, 12-14, 14-16, 16-18, 18-20
    const heatData: { cellKey: string; count: number; value: number }[][] = Array.from({ length: 7 }, () =>
      Array.from({ length: 6 }, () => ({ cellKey: "", count: 0, value: 0 }))
    );

    // Fill cell keys
    const timeSlots = ["08:00 - 10:00", "10:00 - 12:00", "12:00 - 14:00", "14:00 - 16:00", "16:00 - 18:00", "18:00 - 20:00"];
    
    for (let r = 0; r < 7; r++) {
      for (let c = 0; c < 6; c++) {
        heatData[r][c].cellKey = `${weekdayNamesIndonesian[r]} jam ${timeSlots[c]}`;
      }
    }

    list.forEach(tx => {
      const date = new Date(tx.timestamp);
      // Day of week mon=0, sun=6 (mon=1 in js, sun=0 in js)
      let dayIdx = date.getDay() - 1;
      if (dayIdx < 0) dayIdx = 6; // Sunday index adjust

      const hour = date.getHours();
      // group to 2 hr slots
      let slotIdx = -1;
      if (hour >= 8 && hour < 10) slotIdx = 0;
      else if (hour >= 10 && hour < 12) slotIdx = 1;
      else if (hour >= 12 && hour < 14) slotIdx = 2;
      else if (hour >= 14 && hour < 16) slotIdx = 3;
      else if (hour >= 16 && hour < 18) slotIdx = 4;
      else if (hour >= 18 && hour < 20) slotIdx = 5;

      if (dayIdx >= 0 && dayIdx < 7 && slotIdx >= 0 && slotIdx < 6) {
        heatData[dayIdx][slotIdx].count += 1;
        heatData[dayIdx][slotIdx].value += tx.totalAmount;
      }
    });

    return heatData;
  };

  const heatmapGrid = assembleHeatmapStats();

  const getHeatmapColorThreshold = (orders: number) => {
    if (orders === 0) return "bg-stone-50 hover:bg-stone-100 duration-100 text-stone-300";
    if (orders <= 5) return "bg-emerald-100 hover:bg-emerald-200 duration-100 text-emerald-800 ring-1 ring-emerald-200";
    if (orders <= 15) return "bg-emerald-400 hover:bg-emerald-500 duration-100 text-emerald-950 ring-1 ring-emerald-300";
    return "bg-emerald-700 hover:bg-emerald-800 duration-100 text-white shadow-inner";
  };

  // --- GEMINI: REFRESH COPILOT CFO NARRATIVE API ---
  const triggerGenerateNarrativeReport = async () => {
    setNarrativeLoading(true);
    try {
      const topProds = topProductRankings().map(p => ({
        name: p.name,
        revenue: p.revenue,
        qty: p.qty,
      }));

      const rangeDesc = selectedPeriod === "7d" ? "7 Hari Terakhir" : selectedPeriod === "30d" ? "30 Hari Terakhir" : "Menyeluruh";
      const nar = await getNarrativeReport(rangeDesc, metrics, topProds);
      setNarrativeText(nar);
      addToast("📊 Laporan narasi AI Copilot siap!", "success");
    } catch (e: any) {
      addToast("Gagal memanggil modul AI Gemini.", "error");
    } finally {
      setNarrativeLoading(false);
    }
  };

  const topProductRankings = () => {
    const counts: { [name: string]: { name: string; qty: number; revenue: number } } = {};
    list.forEach(tx => {
      tx.items.forEach(it => {
        if (!counts[it.name]) {
          counts[it.name] = { name: it.name, qty: 0, revenue: 0 };
        }
        counts[it.name].qty += it.qty;
        counts[it.name].revenue += (it.price * it.qty);
      });
    });
    return Object.values(counts).sort((a, b) => b.qty - a.qty).slice(0, 3);
  };

  useEffect(() => {
    if (list.length > 0) {
      triggerGenerateNarrativeReport();
    }
  }, [selectedPeriod]);

  const handleExportExcel = () => {
    addToast("Menyiapkan dokumen Excel...", "info");
    try {
      const activeRangeDesc = selectedPeriod === "7d" ? "7 Hari Terakhir" : selectedPeriod === "30d" ? "30 Hari Terakhir" : "Menyeluruh";
      const nowStr = formatFullDate(new Date());

      // Built with standard UTF-8 Byte Order Mark + sep=, directive for native universal Excel support
      let csvContent = "sep=,\n";
      
      // Document Metadata Headers
      csvContent += `LAPORAN ANALISIS & LABA KEUANGAN\n`;
      csvContent += `Nama Toko,${storeProfile?.name || "Toko"}\n`;
      csvContent += `Pemilik,${storeProfile?.owner?.name || "Budi Santoso"}\n`;
      csvContent += `Periode Laporan,${activeRangeDesc}\n`;
      csvContent += `Tanggal Diunduh,${nowStr}\n\n`;

      // Section 1: Financial Highlights metrics
      csvContent += `RINGKASAN METRIK UTAMA\n`;
      csvContent += `Nama Metrik,Nilai,Keterangan\n`;
      csvContent += `Total Omzet Penjualan,Rp ${metrics.totalRevenue.toLocaleString("id-ID")},Penerimaan kotor dari penjualan lunas\n`;
      csvContent += `Total Nota Lunas,${metrics.totalSalesCount} Nota,Jumlah nota penjualan selesai transaksi\n`;
      csvContent += `Rata-rata Omzet / Hari,Rp ${averagePerDay.toLocaleString("id-ID")},Rata-rata penjualan harian dalam periode\n`;
      csvContent += `Hari Penjualan Tertinggi,${bestDate},Puncak omzet harian sebesar Rp ${maxRev.toLocaleString("id-ID")}\n\n`;

      // Section 2: Product performance grids
      csvContent += `PERINGKAT & MARGIN MENU KULINER\n`;
      csvContent += `Peringkat,Nama Menu Kuliner,Jumlah Porsi Terjual,Total Omzet Menu,Margin Laba Estimasi\n`;
      productSortedList.forEach((p, idx) => {
        csvContent += `${idx + 1},"${p.name}",${p.qty},Rp ${p.revenue.toLocaleString("id-ID")},${p.margin}%\n`;
      });
      csvContent += `\n`;

      // Section 3: Daily Omzet totals
      csvContent += `RIWAYAT PENJUALAN HARIAN (GRAFIK DATA)\n`;
      csvContent += `Tanggal,Total Omzet Harian\n`;
      barChartData.forEach((day) => {
        csvContent += `${day.Tanggal},Rp ${day.Omzet.toLocaleString("id-ID")}\n`;
      });
      csvContent += `\n`;

      // Section 4: Granular raw transaction logs
      csvContent += `RIWAYAT TRANSAKSI PENJUALAN DETAIL\n`;
      csvContent += `No. Transaksi,Waktu Penjualan,Kuantitas Item,Total Pembayaran,Total Modal Pokok,Margin Laba Bersih\n`;
      const sortedTxs = [...list].sort((a, b) => b.timestamp.localeCompare(a.timestamp));
      sortedTxs.forEach((tx) => {
        const dStr = formatFullDate(new Date(tx.timestamp));
        const totalItems = tx.items.reduce((s, it) => s + it.qty, 0);
        csvContent += `${tx.id},${dStr},${totalItems},Rp ${tx.totalAmount.toLocaleString("id-ID")},Rp ${tx.totalModal.toLocaleString("id-ID")},Rp ${tx.profit.toLocaleString("id-ID")}\n`;
      });

      // Save file dynamically
      const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", `Laporan_Keuangan_Analitik_${storeProfile?.name?.replace(/\s+/g, "_") || "Toko"}_${selectedPeriod}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      addToast("📊 Laporan Excel (CSV) diunduh dengan sukses!", "success");
    } catch (err: any) {
      console.error(err);
      addToast("Gagal mengunduh dokumen Excel.", "error");
    }
  };

  const handleDownloadPDF = () => {
    addToast("Menyiapkan dokumen cetak PDF...", "info");
    try {
      const printWindow = window.open("", "_blank");
      if (!printWindow) {
        addToast("Popup cetak diblokir! Silakan aktifkan izin popup browser Anda.", "warning");
        return;
      }

      const activeRangeDesc = selectedPeriod === "7d" ? "7 Hari Terakhir" : selectedPeriod === "30d" ? "30 Hari Terakhir" : "Menyeluruh";
      const nowStr = formatFullDate(new Date());

      // Pull parent styles
      let parentStyles = "";
      document.querySelectorAll("link[rel='stylesheet'], style").forEach((el) => {
        parentStyles += el.outerHTML;
      });

      // Convert menu tables to HTML
      const productsTableRows = productSortedList.map((p, idx) => `
        <tr class="border-b border-stone-100 hover:bg-stone-50/50">
          <td class="py-2 px-2 font-bold text-stone-800" style="display: flex; align-items: center; gap: 8px;">
            <span class="w-2.5 h-2.5 rounded-full ring-2 ring-white shrink-0" style="background-color: ${p.color};"></span>
            <span>${p.name}</span>
          </td>
          <td class="py-2 px-2 text-center font-mono font-bold text-stone-900">${p.qty} porsi</td>
          <td class="py-2 px-2 text-right font-mono font-black text-stone-900">Rp ${p.revenue.toLocaleString("id-ID")}</td>
          <td class="py-2 px-2 text-center">
            <span class="inline-block px-2.5 py-0.5 rounded-xl text-[10px] font-extrabold font-mono ${
              p.margin > 35 ? "bg-emerald-50 text-emerald-800" : p.margin > 20 ? "bg-purple-50 text-purple-700" : "bg-amber-50 text-amber-700"
            }">
              ${p.margin}%
            </span>
          </td>
        </tr>
      `).join("");

      // Daily stats log table rows
      const dailyTrendRows = barChartData.map((d) => `
        <tr class="border-b border-stone-100/60 hover:bg-stone-50/30">
          <td class="py-2 text-stone-600 font-bold">${d.Tanggal}</td>
          <td class="py-2 text-right font-mono font-black text-stone-900">Rp ${d.Omzet.toLocaleString("id-ID")}</td>
        </tr>
      `).join("");

      // Checked and unchecked checkboxes in strategic CFO
      const checklistItemsHtml = [
        "Lakukan penghematan atau negosiasi ulang kulakan es teh manis agar modal dapat dipangkas ke Rp 1.200 per gelas.",
        "Buat promosi paket bundling 'Rabu Murah' untuk menarik pelanggan di hari tersenyap harian.",
        "Siapkan cadangan adonan masak Bakso Urat lebih awal karena jam makan siang terhitung sangat kritis puncaknya."
      ].map((rec, idx) => {
        const isChecked = checklist[idx];
        return `
          <div class="flex gap-2.5 items-start py-0.5" style="display: flex; gap: 10px; margin-bottom: 6px;">
            <span class="text-emerald-600 font-black" style="color: #10b981; font-weight: 900; font-size: 15px;">${isChecked ? "✓" : "☐"}</span>
            <span class="text-stone-700" style="font-size: 12px; ${isChecked ? "text-decoration: line-through; color: #a8a29e;" : "color: #44403c;"}">${rec}</span>
          </div>
        `;
      }).join("");

      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Laporan Analisis & Laba Keuangan - ${storeProfile?.name || "Toko"}</title>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            ${parentStyles}
            <style>
              body {
                background: white !important;
                color: #1c1917 !important;
                padding: 40px !important;
                font-family: 'Inter', system-ui, -apple-system, sans-serif !important;
              }
              tr, div, section {
                page-break-inside: avoid !important;
              }
              @media print {
                body {
                  padding: 0 !important;
                  margin: 0 !important;
                  background: white !important;
                }
                .no-print {
                  display: none !important;
                }
                * {
                  -webkit-print-color-adjust: exact !important;
                  print-color-adjust: exact !important;
                }
              }
            </style>
          </head>
          <body>
            <div class="w-full max-w-4xl mx-auto space-y-8 bg-white p-2">
              
              <!-- Letterhead -->
              <div class="flex justify-between items-start pb-6 border-b-2 border-stone-800" style="display: flex; justify-content: space-between; border-bottom: 2px solid #292524; padding-bottom: 24px;">
                <div>
                  <div class="flex items-center gap-2 mb-1" style="display: flex; align-items: center; gap: 8px;">
                    <span class="text-2xl font-black text-stone-900 tracking-tight" style="font-size: 20px; font-weight: 900;">KASIR WARUNG</span>
                    <span class="px-2 py-0.5 bg-emerald-600 text-white font-extrabold text-[9px] rounded uppercase tracking-wider" style="background-color: #059669; padding: 2px 6px; font-weight: 800; font-size: 9px; color: white;">PRO</span>
                  </div>
                  <h1 class="text-xl font-black text-stone-800 uppercase tracking-tight" style="font-size: 18px; font-weight: 900; color: #1c1917; margin-top: 4px;">Laporan Analisis & Laba Keuangan</h1>
                  <p class="text-xs text-stone-500 mt-1" style="font-size: 12px; color: #78716c; margin-top: 4px;">Nama Toko: <span class="font-bold text-stone-700">${storeProfile?.name || "Toko Anda"}</span> | Pemilik: <span class="font-bold text-stone-700">${storeProfile?.owner?.name || "Budi Santoso"}</span></p>
                </div>
                <div class="text-right" style="text-align: right;">
                  <div class="text-xs font-bold text-stone-400 uppercase tracking-wider" style="color: #a8a29e; font-size: 11px; font-weight: 700; text-transform: uppercase;">Tanggal Cetak</div>
                  <div class="text-sm font-black text-stone-950 mt-0.5 font-mono" style="font-weight: 900; font-size: 13px; font-family: monospace;">${nowStr}</div>
                  <div class="text-[10px] font-black bg-stone-100 text-stone-700 px-3 py-1 rounded-full w-fit ml-auto mt-2" style="background-color: #f5f5f4; color: #44403c; padding: 4px 10px; border-radius: 9999px; font-size: 10px; font-weight: 800; width: fit-content; margin-left: auto; margin-top: 8px;">
                    Periode: ${activeRangeDesc}
                  </div>
                </div>
              </div>

              <!-- High Metrics Grid Cards -->
              <div class="grid grid-cols-2 gap-4" style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; margin-top: 24px;">
                <div class="border border-stone-200 rounded-xl p-4 bg-stone-50/50" style="border: 1px solid #e7e5e4; border-radius: 12px; padding: 16px; bg-color: rgba(245,245,244,0.5);">
                  <span class="text-[10px] text-stone-400 font-extrabold uppercase tracking-wide" style="font-size: 10px; color: #a8a29e; font-weight: 800; text-transform: uppercase;">Total Omzet Penjualan</span>
                  <div class="text-2xl font-black text-stone-900 tracking-tight font-mono mt-1" style="font-size: 22px; font-weight: 900; font-family: monospace; color: #1c1917; margin-top: 4px;">Rp ${metrics.totalRevenue.toLocaleString("id-ID")}</div>
                  <span class="text-[9px] text-stone-500 font-semibold block mt-1" style="font-size: 9px; color: #78716c; margin-top: 4px;">Estimasi kotor omzet terekam</span>
                </div>
                <div class="border border-stone-200 rounded-xl p-4 bg-stone-50/50" style="border: 1px solid #e7e5e4; border-radius: 12px; padding: 16px; bg-color: rgba(245,245,244,0.5);">
                  <span class="text-[10px] text-stone-400 font-extrabold uppercase tracking-wide" style="font-size: 10px; color: #a8a29e; font-weight: 800; text-transform: uppercase;">Total Nota Lunas</span>
                  <div class="text-2xl font-black text-stone-900 tracking-tight font-mono mt-1" style="font-size: 22px; font-weight: 900; font-family: monospace; color: #1c1917; margin-top: 4px;">${metrics.totalSalesCount} Nota</div>
                  <span class="text-[9px] text-stone-500 font-semibold block mt-1" style="font-size: 9px; color: #78716c; margin-top: 4px;">Lunas selesai terbayar</span>
                </div>
                <div class="border border-stone-200 rounded-xl p-4 bg-stone-50/50" style="border: 1px solid #e7e5e4; border-radius: 12px; padding: 16px; bg-color: rgba(245,245,244,0.5);">
                  <span class="text-[10px] text-stone-400 font-extrabold uppercase tracking-wide" style="font-size: 10px; color: #a8a29e; font-weight: 800; text-transform: uppercase;">Rata-rata Omzet / Hari</span>
                  <div class="text-2xl font-black text-stone-900 tracking-tight font-mono mt-1" style="font-size: 22px; font-weight: 900; font-family: monospace; color: #1c1917; margin-top: 4px;">Rp ${averagePerDay.toLocaleString("id-ID")}</div>
                  <span class="text-[9px] text-stone-500 font-semibold block mt-1" style="font-size: 9px; color: #78716c; margin-top: 4px;">Rata-rata saku harian warung</span>
                </div>
                <div class="border border-stone-200 rounded-xl p-4 bg-stone-50/50" style="border: 1px solid #e7e5e4; border-radius: 12px; padding: 16px; bg-color: rgba(245,245,244,0.5);">
                  <span class="text-[10px] text-stone-400 font-extrabold uppercase tracking-wide" style="font-size: 10px; color: #a8a29e; font-weight: 800; text-transform: uppercase;">Puncak Penjualan Terbesar</span>
                  <div class="text-xl font-black text-emerald-700 tracking-tight mt-1" style="font-size: 18px; font-weight: 900; color: #047857; margin-top: 4px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis;">${bestDate}</div>
                  <span class="text-[9px] text-emerald-800 font-black block mt-1" style="font-size: 9px; color: #065f46; font-weight: 900; margin-top: 4px;">Omzet: Rp ${maxRev.toLocaleString("id-ID")}</span>
                </div>
              </div>

              <!-- Menu Performances -->
              <div class="space-y-3" style="margin-top: 32px;">
                <h3 class="text-xs font-black tracking-widest text-stone-400 uppercase pb-1 border-b border-stone-200" style="font-size: 11px; text-transform: uppercase; font-weight: 900; color: #a8a29e; border-bottom: 1px solid #e7e5e4; padding-bottom: 4px; letter-spacing: 0.1em;">Peringkat & Margin Item Terjual</h3>
                <table class="w-full text-left text-xs font-semibold text-stone-700" style="width: 100%; text-align: left; font-size: 12px; color: #44403c;">
                  <thead>
                    <tr class="border-b border-stone-200 text-[10px] uppercase text-stone-400 font-black h-8" style="border-bottom: 1px solid #e7e5e4; font-size: 10px; text-transform: uppercase; color: #a8a29e; font-weight: 800; height: 32px;">
                      <th class="py-1">Nama Menu Kuliner</th>
                      <th class="py-1 text-center w-24" style="text-align: center; width: 96px;">Porsi Terjual</th>
                      <th class="py-1 text-right w-32" style="text-align: right; width: 128px;">Total Omzet</th>
                      <th class="py-1 text-center w-24" style="text-align: center; width: 96px;">Margin Laba</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-stone-50" style="color: #57534e;">
                    ${productsTableRows}
                  </tbody>
                </table>
              </div>

              <!-- Double columns: daily stats & tasks checklist -->
              <div class="grid grid-cols-2 gap-8" style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 32px; margin-top: 32px;">
                <div class="space-y-3">
                  <h3 class="text-xs font-black tracking-widest text-stone-400 uppercase pb-1 border-b border-stone-200" style="font-size: 11px; text-transform: uppercase; font-weight: 900; color: #a8a29e; border-bottom: 1px solid #e7e5e4; padding-bottom: 4px; letter-spacing: 0.1em;">Grafik Omzet Harian</h3>
                  <table class="w-full text-left text-xs" style="width: 100%; text-align: left; font-size: 11px;">
                    <thead>
                      <tr class="border-b border-stone-100 text-[10px] uppercase text-stone-400 font-black h-8" style="border-bottom: 1px solid #f5f5f4; font-size: 9px; text-transform: uppercase; color: #a8a29e; font-weight: 800; height: 32px;">
                        <th class="py-1">Tanggal</th>
                        <th class="py-1 text-right" style="text-align: right;">Total Omzet</th>
                      </tr>
                    </thead>
                    <tbody class="divide-y divide-stone-50">
                      ${dailyTrendRows}
                    </tbody>
                  </table>
                </div>

                <div class="space-y-3">
                  <h3 class="text-xs font-black tracking-widest text-stone-400 uppercase pb-1 border-b border-stone-200" style="font-size: 11px; text-transform: uppercase; font-weight: 900; color: #a8a29e; border-bottom: 1px solid #e7e5e4; padding-bottom: 4px; letter-spacing: 0.1em;">Tugas Rekomendasi Mingguan</h3>
                  <div class="border border-stone-200 rounded-xl p-4 bg-stone-50/50" style="border: 1px solid #e7e5e4; border-radius: 12px; padding: 16px; background-color: rgba(250,250,249,0.5);">
                    ${checklistItemsHtml}
                  </div>
                </div>
              </div>

              <!-- CFO Virtual analysis -->
              <div class="space-y-3" style="margin-top: 32px;">
                <h3 class="text-xs font-black tracking-widest text-stone-400 uppercase pb-1 border-b border-stone-200" style="font-size: 11px; text-transform: uppercase; font-weight: 900; color: #a8a29e; border-bottom: 1px solid #e7e5e4; padding-bottom: 4px; letter-spacing: 0.1em;">Analisis Strategis virtual CFO Copilot</h3>
                <div class="p-4 border border-stone-200 bg-stone-50 rounded-xl whitespace-pre-line text-xs leading-relaxed text-stone-700" style="border: 1px solid #e7e5e4; border-radius: 12px; padding: 16px; background-color: #f5f5f4; font-size: 12px; line-height: 1.6; color: #44403c; white-space: pre-line; font-family: system-ui, sans-serif;">
                  ${narrativeText || "Laporan narasi belum dibuat. Silakan pencet tombol 'Buat Narasi AI' terlebih dahulu pada halaman web utama."}
                </div>
              </div>

              <!-- Footer logo -->
              <div class="pt-8 border-t border-stone-200 text-center text-[10px] font-bold text-stone-400 uppercase tracking-widest" style="border-top: 1px solid #e7e5e4; text-align: center; font-size: 10px; color: #a8a29e; font-weight: 700; margin-top: 48px; padding-top: 24px; letter-spacing: 0.2em;">
                KASIR WARUNG • CETAKAN DOKUMEN LAPORAN RESMI SECARA OTOMATIS
              </div>

            </div>
            
            <script>
              window.focus();
              setTimeout(() => {
                window.print();
              }, 600);
            </script>
          </body>
        </html>
      `);
      printWindow.document.close();
      addToast("Menyiapkan lembaran cetakan PDF resmi...", "success");
    } catch (e: any) {
      console.error(e);
      addToast("Gagal menyajikan dokumen PDF cetak.", "error");
    }
  };

  const CustomPieTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-stone-900 border border-stone-800 p-3 rounded-2xl shadow-[0_10px_40px_-5px_rgba(0,0,0,0.5)] z-[100] relative pointer-events-none min-w-[140px]">
          <div className="flex items-center gap-2 mb-1.5 pb-1.5 border-b border-stone-800/80">
            <div className="w-2.5 h-2.5 rounded-full ring-2 ring-white/10 shadow-sm" style={{ backgroundColor: data.color }} />
            <span className="text-stone-300 text-xs font-bold leading-none">{data.name}</span>
          </div>
          <div className="text-emerald-400 font-mono font-black text-sm tracking-wide">
            {formatRupiah(data.value)}
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-8 max-w-[1400px] mx-auto">
      {/* Upper Filter top panel */}
      <div className="bg-white rounded-2xl md:rounded-3xl p-4 md:p-5 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 shadow-sm border border-stone-100">
        {/* Period selects */}
        <div className="flex bg-stone-100/80 p-1 rounded-2xl w-full md:w-auto border border-stone-200/50">
          <button
            onClick={() => setSelectedPeriod("7d")}
            className={`flex-1 md:flex-none px-4 py-2 rounded-xl text-xs font-bold cursor-pointer transition-all duration-200 ${
              selectedPeriod === "7d" ? "bg-white text-stone-900 shadow-[0_2px_8px_rgba(0,0,0,0.06)] font-extrabold" : "text-stone-500 hover:text-stone-700 hover:bg-stone-200/50"
            }`}
          >
            7 Hari Terakhir
          </button>
          <button
            onClick={() => setSelectedPeriod("30d")}
            className={`flex-1 md:flex-none px-4 py-2 rounded-xl text-xs font-bold cursor-pointer transition-all duration-200 ${
              selectedPeriod === "30d" ? "bg-white text-stone-900 shadow-[0_2px_8px_rgba(0,0,0,0.06)] font-extrabold" : "text-stone-500 hover:text-stone-700 hover:bg-stone-200/50"
            }`}
          >
            30 Hari Terakhir
          </button>
          <button
            onClick={() => setSelectedPeriod("all")}
            className={`flex-1 md:flex-none px-4 py-2 rounded-xl text-xs font-bold cursor-pointer transition-all duration-200 ${
              selectedPeriod === "all" ? "bg-white text-stone-900 shadow-[0_2px_8px_rgba(0,0,0,0.06)] font-extrabold" : "text-stone-500 hover:text-stone-700 hover:bg-stone-200/50"
            }`}
          >
            Menyeluruh
          </button>
        </div>

        {/* Action icons block */}
        <div className="flex gap-2.5 items-center w-full md:w-auto shrink-0 justify-end">
          <button
            onClick={handleDownloadPDF}
            className="flex-1 md:flex-none h-11 px-5 border border-stone-200 bg-white hover:bg-stone-50 font-bold text-xs rounded-xl flex items-center justify-center gap-2 cursor-pointer text-stone-700 shadow-sm hover:border-stone-300 transition"
          >
            <Download className="w-4 h-4 text-stone-400" />
            Download PDF
          </button>
          <button
            onClick={handleExportExcel}
            className="flex-1 md:flex-none h-11 px-5 border border-stone-200 bg-white hover:bg-stone-50 font-bold text-xs rounded-xl flex items-center justify-center gap-2 cursor-pointer text-stone-700 shadow-sm hover:border-stone-300 transition"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            Export Excel
          </button>
        </div>
      </div>

      {/* 4-GRID ANALYTIC FINANCIAL OVERVIEWS CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" id="overview-analytics-grid">
        {/* Total revenue */}
        <div className="bg-white border-t-[3px] border-t-emerald-500 border-l border-r border-b border-stone-100 p-5 rounded-2xl shadow-[0_1px_3px_rgba(0,0,0,0.05),_0_6px_20px_rgba(0,0,0,0.04)] hover:shadow-lg transition-all duration-300 group relative">
          <div className="flex justify-between items-start">
            <span className="text-[10px] text-stone-400 font-extrabold uppercase tracking-wider block">Total Omzet Penjualan</span>
            <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600">
              <Activity className="w-4 h-4" />
            </div>
          </div>
          <h3 className="font-heading font-black text-3xl text-stone-900 tracking-tight mt-1 mb-1 font-mono">{formatRupiah(metrics.totalRevenue)}</h3>
          <span className="text-[10px] text-emerald-600 font-extrabold tracking-wide flex items-center gap-1 mt-3 bg-emerald-50/50 px-2.5 py-1 rounded-lg w-fit transition group-hover:bg-emerald-50">
            <TrendingUp className="w-3 h-3 shrink-0" />
            +14% dari minggu lalu
          </span>
        </div>

        {/* Total transactions */}
        <div className="bg-white border-t-[3px] border-t-sky-500 border-l border-r border-b border-stone-100 p-5 rounded-2xl shadow-[0_1px_3px_rgba(0,0,0,0.05),_0_6px_20px_rgba(0,0,0,0.04)] hover:shadow-lg transition-all duration-300 group relative">
          <div className="flex justify-between items-start">
            <span className="text-[10px] text-stone-400 font-extrabold uppercase tracking-wider block">Total Nota Lunas</span>
            <div className="w-8 h-8 rounded-full bg-sky-50 flex items-center justify-center text-sky-600">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <h3 className="font-heading font-black text-3xl text-stone-900 tracking-tight mt-1 mb-1 font-mono">{metrics.totalSalesCount} <span className="text-xl text-stone-400 font-sans tracking-normal">Nota</span></h3>
          <span className="text-[10px] text-sky-700 font-bold tracking-wide flex items-center mt-3 bg-sky-50 px-2.5 py-1 rounded-lg w-fit">
            Selesai bayar lunas koper
          </span>
        </div>

        {/* Daily average */}
        <div className="bg-white border-t-[3px] border-t-purple-500 border-l border-r border-b border-stone-100 p-5 rounded-2xl shadow-[0_1px_3px_rgba(0,0,0,0.05),_0_6px_20px_rgba(0,0,0,0.04)] hover:shadow-lg transition-all duration-300 group relative">
          <div className="flex justify-between items-start">
            <span className="text-[10px] text-stone-400 font-extrabold uppercase tracking-wider block">Rata-rata Omzet / Hari</span>
            <div className="w-8 h-8 rounded-full bg-purple-50 flex items-center justify-center text-purple-600">
              <BarChart3 className="w-4 h-4" />
            </div>
          </div>
          <h3 className="font-heading font-black text-3xl text-stone-900 tracking-tight mt-1 mb-1 font-mono">{formatRupiah(averagePerDay)}</h3>
          <span className="text-[10px] text-purple-700 font-extrabold block mt-3 bg-purple-50 px-2.5 py-1 rounded-lg w-fit tracking-wider uppercase">
            Estimasi saku harian
          </span>
        </div>

        {/* Best peak day */}
        <div className="bg-white border-t-[3px] border-t-amber-500 border-l border-r border-b border-stone-100 p-5 rounded-2xl shadow-[0_1px_3px_rgba(0,0,0,0.05),_0_6px_20px_rgba(0,0,0,0.04)] hover:shadow-lg transition-all duration-300 group relative">
          <div className="flex justify-between items-start">
            <span className="text-[10px] text-stone-400 font-extrabold uppercase tracking-wider block">Hari Penjualan Tertinggi</span>
            <div className="w-8 h-8 rounded-full bg-amber-50 flex items-center justify-center text-amber-600">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <h3 className="font-heading font-black text-2xl text-stone-900 tracking-tight mt-2 mb-1">{bestDate}</h3>
          <span className="text-[10px] text-amber-700 font-black tracking-wide block mt-3 bg-amber-50 px-2.5 py-1 rounded-lg w-fit font-mono uppercase">
            Omzet: {formatRupiah(maxRev)}
          </span>
        </div>
      </div>

      {/* SECTION 2: BAR CHART OF REVENUE HIGHLIGHT */}
      <div className="bg-white border border-stone-100 p-6 md:p-8 rounded-2xl shadow-[0_1px_3px_rgba(0,0,0,0.05),_0_6px_20px_rgba(0,0,0,0.04)]">
        <div className="flex justify-between items-center pb-4 border-b border-stone-100 mb-6">
          <div className="space-y-1">
            <h4 className="font-heading font-black text-stone-900 text-sm md:text-base">Aktivitas Omzet Penjualan Kotor</h4>
            <p className="text-xs text-stone-400">Menampilkan omzet per tanggal transaksi lunas koper</p>
          </div>
        </div>

        <div className="h-76 w-full select-none">
          {barChartData.length === 0 ? (
            <div className="text-center py-20 text-stone-400 font-extrabold uppercase text-xs">Belum ada transaksi terkumpul.</div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={barChartData} margin={{ top: 10, right: 15, left: 10, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorO" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#059669" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#059669" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                <XAxis dataKey="Tanggal" tick={{ fill: "#9CA3AF", fontSize: 11, fontWeight: "600" }} axisLine={false} tickLine={false} tickMargin={12} />
                <YAxis tickFormatter={formatShortRupiah} tick={{ fill: "#9CA3AF", fontSize: 11, fontWeight: "600" }} axisLine={false} tickLine={false} tickMargin={8} />
                <Tooltip cursor={{ fill: "rgba(245, 245, 244, 0.4)" }} formatter={(value) => [formatRupiah(Number(value)), "Omzet"]} contentStyle={{ fontSize: 12, fontWeight: "700", background: "#1c1917", color: "#f5f5f4", borderRadius: 12, border: "none", padding: "12px 16px", boxShadow: "0 10px 25px -5px rgba(0,0,0,0.2)" }} itemStyle={{ color: "#10B981", marginTop: "4px" }} />
                <Area type="monotone" dataKey="Omzet" stroke="#059669" strokeWidth={3} fillOpacity={1} fill="url(#colorO)" dot={{ strokeWidth: 2, r: 4, stroke: "#059669", fill: "#fff" }} activeDot={{ r: 6, stroke: "#059669", strokeWidth: 2, fill: "#fff" }} name="Omzet" />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* SECTION 3: PRODUCT COMPARISONS & SORT TABLES */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Pie (40%) */}
        <div className="lg:col-span-5 bg-white border border-stone-100 p-6 md:p-8 rounded-2xl shadow-[0_1px_3px_rgba(0,0,0,0.05),_0_6px_20px_rgba(0,0,0,0.04)] flex flex-col justify-between">
          <div>
            <h4 className="font-heading font-black text-stone-900 text-sm md:text-base border-b border-stone-100 pb-4 mb-5">Kontribusi Kuliner Menu (%)</h4>
            
            <div className="h-60 w-full flex items-center justify-center relative select-none">
              {pieChartData.length === 0 ? (
                <div className="text-center py-12 text-stone-400 text-xs font-bold select-none">Kosong</div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieChartData}
                      cx="50%"
                      cy="50%"
                      innerRadius={65}
                      outerRadius={85}
                      paddingAngle={4}
                      dataKey="value"
                    >
                      {pieChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomPieTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              )}
              {/* Inner ring text labels */}
              <div className="absolute flex flex-col items-center justify-center text-center pointer-events-none z-0">
                <span className="text-[10px] text-stone-400 font-extrabold uppercase tracking-wider leading-none">Total Omzet</span>
                <span className="text-base font-black text-stone-900 mt-2 leading-none font-mono">{formatRupiah(metrics.totalRevenue)}</span>
              </div>
            </div>
          </div>
          
          <div className="flex flex-wrap justify-between gap-x-2 gap-y-3 py-2.5 border-t border-stone-100 mt-5 max-h-32 overflow-y-auto pr-1">
            {pieChartData.sort((a,b) => b.value - a.value).map((item, idx) => {
              const perc = metrics.totalRevenue > 0 ? (item.value / metrics.totalRevenue) * 100 : 0;
              return (
              <div key={idx} className="w-[48%]">
                <div className="flex justify-between items-center mb-1 text-[10px] font-bold text-stone-600">
                  <span className="flex items-center gap-1.5 truncate">
                    <span className="w-2.5 h-2.5 rounded-full shrink-0 ring-2 ring-white" style={{ backgroundColor: item.color }} />
                    <span className="truncate">{item.name}</span>
                  </span>
                  <span className="font-mono text-stone-900">{perc.toFixed(0)}%</span>
                </div>
                <div className="w-full h-1.5 bg-stone-100 rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${perc}%`, backgroundColor: item.color }} />
                </div>
              </div>
            )})}
          </div>
        </div>

        {/* Right table (70%) */}
        <div className="lg:col-span-7 bg-white border border-stone-100 p-6 md:p-8 rounded-2xl shadow-[0_1px_3px_rgba(0,0,0,0.05),_0_6px_20px_rgba(0,0,0,0.04)] flex flex-col justify-between">
          <div>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-stone-100 pb-4 mb-5 gap-3">
              <div className="space-y-1">
                <h4 className="font-heading font-black text-stone-900 text-sm md:text-base">Peringkat & Margin Menu Usaha</h4>
                <p className="text-xs text-stone-400">Pantau margin laba per item kuliner dan total kuantitas porsi terjual</p>
              </div>
              
              {/* Sorter triggers */}
              <div className="flex items-center bg-stone-100 border border-stone-200/50 p-1 rounded-xl shrink-0 self-start sm:self-center">
                <button
                  onClick={() => { setProductSortField("qty"); setProductSortAsc(!productSortAsc); }}
                  className={`px-3 py-1.5 rounded-lg text-[10px] font-black cursor-pointer uppercase transition ${productSortField === "qty" ? "bg-white text-stone-900 shadow-xs" : "text-stone-400 hover:text-stone-700"}`}
                >
                  Qty
                </button>
                <button
                  onClick={() => { setProductSortField("revenue"); setProductSortAsc(!productSortAsc); }}
                  className={`px-3 py-1.5 rounded-lg text-[10px] font-black cursor-pointer uppercase transition ${productSortField === "revenue" ? "bg-white text-stone-900 shadow-xs" : "text-stone-400 hover:text-stone-700"}`}
                >
                  Omzet
                </button>
              </div>
            </div>

            <div className="overflow-x-auto select-none p-0.5">
              <table className="w-full text-left text-xs font-semibold text-stone-700">
                <thead>
                  <tr className="border-b border-stone-100 text-[10px] uppercase text-stone-400 h-9 font-black">
                    <th className="py-1">Nama Menu</th>
                    <th className="py-1 text-center w-24">Terjual</th>
                    <th className="py-1 text-right w-32">Total Omzet</th>
                    <th className="py-1 text-center w-24">Margin Laba</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-50 text-stone-600">
                  {productSortedList.map((p, idx) => (
                    <tr key={idx} className="hover:bg-stone-50/50 transition duration-150">
                      <td className="py-3 font-bold text-stone-800 flex items-center gap-2.5">
                        <span className="w-2.5 h-2.5 rounded-full shrink-0 ring-2 ring-white" style={{ backgroundColor: p.color }} />
                        {p.name}
                      </td>
                      <td className="py-3 text-center font-bold text-stone-900 font-mono">{p.qty}<span className="text-[10px] font-sans text-stone-400 ml-0.5">x</span></td>
                      <td className="py-3 text-right font-black text-stone-900 font-mono">{formatRupiah(p.revenue)}</td>
                      <td className="py-3 text-center font-bold">
                        <span className={`inline-block px-2.5 py-1 rounded-xl text-[10px] font-extrabold font-mono ${p.margin > 35 ? "bg-emerald-50 text-emerald-800" : p.margin > 20 ? "bg-purple-50 text-purple-700" : "bg-amber-50 text-amber-700"}`}>
                          {p.margin}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 4: HORARY HEATMAP WAKTU TERBAIK */}
      <div className="bg-white border border-stone-100 p-6 md:p-8 rounded-2xl shadow-[0_1px_3px_rgba(0,0,0,0.05),_0_6px_20px_rgba(0,0,0,0.04)]">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between pb-4 border-b border-stone-100 mb-6 gap-4">
          <div className="space-y-1">
            <h4 className="font-heading font-black text-stone-900 text-sm md:text-base">Peta Panas (Heatmap) Jam Pelanggan Ramai Beli</h4>
            <p className="text-xs text-stone-400">Analisis horari 2 harian untuk mengatur pergantian giliran stok bahan masak dan buka warung</p>
          </div>
          
          {/* Legend scale */}
          <div className="flex flex-wrap items-center gap-3 text-[9px] font-extrabold text-stone-400 uppercase tracking-wider">
            <span>Sepi (0)</span>
            <span className="w-4 h-4 bg-stone-50 border border-stone-200/50 rounded-md" />
            <span className="w-4 h-4 bg-emerald-100 rounded-md ring-1 ring-emerald-200" />
            <span className="w-4 h-4 bg-emerald-400 rounded-md ring-1 ring-emerald-300" />
            <span className="w-4 h-4 bg-emerald-700 rounded-md shadow-inner" />
            <span>Sangat Ramai (&gt;15)</span>
          </div>
        </div>

        <div className="overflow-x-auto p-1 font-sans font-bold">
          <div className="min-w-[720px] grid grid-cols-12 gap-3.5 text-center items-center">
            {/* Headers row */}
            <span className="col-span-2 text-[10px] text-stone-400 text-left uppercase tracking-wider">Hari / Jam</span>
            <span className="col-span-10 grid grid-cols-6 gap-3 text-[10px] text-stone-400 uppercase font-black tracking-wider text-center">
              <span>08:00 - 10:00</span>
              <span>10:00 - 12:00</span>
              <span>12:00 - 14:00</span>
              <span>14:00 - 16:00</span>
              <span>16:00 - 18:00</span>
              <span>18:00 - 20:00</span>
            </span>

            {/* Grid items */}
            {heatmapGrid.map((rowArr, rowIdx) => (
              <React.Fragment key={rowIdx}>
                {/* Weekday tag label */}
                <span className="col-span-2 text-stone-900 text-xs text-left font-black">{weekdayNamesIndonesian[rowIdx]}</span>
                
                {/* cells */}
                <div className="col-span-10 grid grid-cols-6 gap-3">
                  {rowArr.map((cell, colIdx) => (
                    <div
                      key={colIdx}
                      className={`h-11 rounded-lg flex flex-col items-center justify-center cursor-pointer transition-all hover:scale-105 shadow-xs ${getHeatmapColorThreshold(cell.count)}`}
                      title={`${cell.cellKey}: ${cell.count} transaksi lunas, total kumpul ${formatRupiah(cell.value)}`}
                    >
                      <span className="text-xs font-mono font-bold">{cell.count}</span>
                    </div>
                  ))}
                </div>
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>

      {/* SECTION 5: DEEP EMERALD AI ANALYSIS CFO NARRATIVE */}
      <div className="bg-[#064E3B] rounded-2xl p-6 md:p-8 text-stone-100 shadow-[0_1px_3px_rgba(0,0,0,0.05),_0_6px_20px_rgba(0,0,0,0.04)] space-y-6 relative overflow-hidden group">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-900/10 via-transparent to-transparent pointer-events-none" />
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-white/10 pb-5 gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 bg-white/10 text-emerald-300 rounded-2xl flex items-center justify-center shrink-0 border border-white/5 shadow-inner">
              <Sparkles className="w-5.5 h-5.5 animate-pulse text-amber-300" />
            </div>
            <div>
              <h3 className="font-heading font-black text-sm md:text-base text-white">Analisis Strategis virtual CFO Copilot</h3>
              <p className="text-xs text-emerald-200/80 italic">Disusun otomatis berdasarkan riwayat laporan keuangan Anda</p>
            </div>
          </div>

          <button
            onClick={triggerGenerateNarrativeReport}
            disabled={narrativeLoading}
            className="h-11 px-5 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-extrabold text-xs rounded-xl flex items-center gap-2 transition disabled:opacity-40 shrink-0 cursor-pointer shadow-lg shadow-emerald-950/40 border border-emerald-400/20 hover:scale-101 active:scale-[0.98]"
          >
            <RefreshCw className={`w-4 h-4 ${narrativeLoading ? "animate-spin" : ""}`} />
            Buat Narasi AI
          </button>
        </div>

        {/* Narrative output */}
        <div className="prose prose-sm prose-invert max-w-none text-xs leading-relaxed font-semibold text-stone-100/90">
          {narrativeLoading ? (
            <div className="flex flex-col items-center justify-center py-16 text-center animate-pulse space-y-4">
              <RefreshCw className="w-10 h-10 text-emerald-400 animate-spin" />
              <p className="text-xs italic text-emerald-200">Copilot sedang merajut narasi akuntansi dan saran taktis khusus warung Anda...</p>
            </div>
          ) : (
            <div className="whitespace-pre-line leading-relaxed space-y-4 font-sans text-stone-200 text-[13px]">
              {narrativeText}
            </div>
          )}
        </div>

        <div className="border-t border-white/10 pt-6 space-y-4">
          <h4 className="text-[10px] font-black tracking-widest text-[#A7F3D0] uppercase mb-4">Tugas Rekomendasi Mingguan Usaha</h4>
          
          <div className="space-y-3.5 select-none" id="weekly-checklist-box">
            {[
              "Lakukan penghematan atau negosiasi ulang kulakan es teh manis agar modal dapat dipangkas ke Rp 1.200 per gelas.",
              "Buat promosi paket bundling 'Rabu Murah' untuk menarik pelanggan di hari tersenyap harian.",
              "Siapkan cadangan adonan masak Bakso Urat lebih awal karena jam makan siang terhitung sangat kritis puncaknya."
            ].map((rec, idx) => (
              <label key={idx} className="flex gap-3 leading-relaxed items-start cursor-pointer group">
                <input
                  type="checkbox"
                  checked={checklist[idx]}
                  onChange={() => {
                    const updated = [...checklist];
                    updated[idx] = !updated[idx];
                    setChecklist(updated);
                    addToast(updated[idx] ? `Rekomendasi #${idx+1} sukses dicentang!` : `Batal menyelesaikan #${idx+1}`, "info");
                  }}
                  className="rounded border-white/20 text-emerald-600 focus:ring-emerald-500/20 focus:ring-2 w-4 h-4 bg-white/10 text-xs cursor-pointer mt-0.5 shrink-0"
                />
                <span className={`text-[12px] ${checklist[idx] ? "line-through text-stone-400/80 font-bold" : "text-stone-200 group-hover:text-white transition"}`}>
                  {rec}
                </span>
              </label>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
