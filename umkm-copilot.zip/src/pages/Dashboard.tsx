import React, { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { formatRupiah, formatShortRupiah } from "../utils/currency";
import { formatFullDate, getShortDayName, formatTimeOnly, formatCompactDate } from "../utils/date";
import {
  TrendingUp,
  ShoppingBag,
  Star,
  Wallet,
  Sparkles,
  ChevronRight,
  Plus,
  RefreshCw,
  X,
  PlusSquare,
  AlertTriangle,
  MinusCircle,
  PlusCircle,
  Percent,
  Check,
  Package,
  AlertCircle,
  Download,
  Printer,
  FileSpreadsheet,
  FileText,
  Copy
} from "lucide-react";
import {
  AreaChart,
  Area,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";

interface DashboardProps {
  setActiveTab: (tab: string) => void;
}

export default function Dashboard({ setActiveTab }: DashboardProps) {
  const {
    storeProfile,
    products,
    transactions,
    addTransaction,
    updateProduct,
    dailyInsights,
    insightsLoading,
    refreshDailyInsights,
    selectedPeriod,
    setSelectedPeriod,
    getPeriodMetrics,
    getFilteredTransactions,
    expenses,
    addToast
  } = useApp();

  const [quickAddOpen, setQuickAddOpen] = useState(false);
  const [quickItems, setQuickItems] = useState<{ productId: number; qty: number }[]>([
    { productId: products[0]?.id || 1, qty: 1 }
  ]);

  const [restockProductId, setRestockProductId] = useState<number | null>(null);
  const [restockQtyInput, setRestockQtyInput] = useState<string>("10");

  // State elements for export PDF/Excel
  const [exportDropdownOpen, setExportDropdownOpen] = useState(false);
  const [reportPreviewOpen, setReportPreviewOpen] = useState(false);
  const [isIframe, setIsIframe] = useState(false);

  useEffect(() => {
    try {
      setIsIframe(window.self !== window.top);
    } catch (e) {
      setIsIframe(true);
    }

    // Auto-trigger print if URL contains ?report=true
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get("report") === "true") {
      setReportPreviewOpen(true);
      const period = urlParams.get("period");
      if (period === "7d" || period === "30d" || period === "all") {
        setSelectedPeriod(period);
      }
      
      const timer = setTimeout(() => {
        window.print();
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [setSelectedPeriod]);

  // --- DERIVE TODAY STATS FROM MAIN DATABASE IN REAL TIME ---
  const todayStr = new Date().toDateString();
  const todayTx = transactions.filter(t => new Date(t.timestamp).toDateString() === todayStr);

  const todayRevenue = todayTx.reduce((acc, t) => acc + t.totalAmount, 0);
  const todayTransactionsCount = todayTx.length;
  const todayModal = todayTx.reduce((acc, t) => acc + t.totalModal, 0);
  const todayLaba = todayRevenue - todayModal;

  // Let's compute today's top product
  const todayProdCounts: { [name: string]: number } = {};
  todayTx.forEach(tx => {
    tx.items.forEach(it => {
      todayProdCounts[it.name] = (todayProdCounts[it.name] || 0) + it.qty;
    });
  });
  let todayTopProduct = "Tidak ada";
  let todayTopQty = 0;
  Object.entries(todayProdCounts).forEach(([name, count]) => {
    if (count > todayTopQty) {
      todayTopProduct = name;
      todayTopQty = count;
    }
  });

  // Calculate under target percentage alert
  const periodMetrics = getPeriodMetrics();
  const monthlyTarget = storeProfile?.target?.monthly || 15000000;
  const targetCompletedPercent = Math.min(100, Math.round((periodMetrics.totalRevenue / monthlyTarget) * 100));

  // --- RECHARTS CHART DATA ASSEMBLY ---
  // Create last 7 or 30 chronological days summary depending on selectedPeriod
  const assembleChartData = () => {
    const list = getFilteredTransactions();
    const daysMap: { [dateKey: string]: { label: string; fullDate: string; dateObj: Date; omzet: number; laba: number } } = {};

    // Initialize with 0 for the selected period up to today
    const now = new Date();
    const daysToPad = selectedPeriod === "7d" ? 7 : (selectedPeriod === "30d" ? 30 : 0);
    
    if (daysToPad > 0) {
      for (let i = daysToPad - 1; i >= 0; i--) {
        const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
        const dateKey = d.toDateString();
        daysMap[dateKey] = {
          label: getShortDayName(d),
          fullDate: `${getShortDayName(d)}, ${formatCompactDate(d)}`,
          dateObj: d,
          omzet: 0,
          laba: 0
        };
      }
    }

    // Collect daily totals
    list.forEach(t => {
      const d = new Date(t.timestamp);
      const dateKey = d.toDateString();
      if (!daysMap[dateKey]) {
        daysMap[dateKey] = {
          label: getShortDayName(d),
          fullDate: `${getShortDayName(d)}, ${formatCompactDate(d)}`,
          dateObj: d,
          omzet: 0,
          laba: 0
        };
      }
      daysMap[dateKey].omzet += t.totalAmount;
      daysMap[dateKey].laba += t.profit;
    });

    // Deduct expenses from Laba
    const limitDate = new Date();
    limitDate.setHours(0, 0, 0, 0);
    if (selectedPeriod === "7d") limitDate.setDate(limitDate.getDate() - 6);
    else if (selectedPeriod === "30d") limitDate.setDate(limitDate.getDate() - 29);
    
    expenses.forEach((e) => {
      const d = new Date(e.timestamp);
      if (selectedPeriod !== "all" && d < limitDate) return;
      
      const dateKey = d.toDateString();
      if (daysMap[dateKey]) {
        daysMap[dateKey].laba -= e.amount;
      }
    });

    // Convert map to sorted array
    return Object.values(daysMap)
      .sort((a, b) => a.dateObj.getTime() - b.dateObj.getTime())
      .map(item => ({
        name: item.label,
        fullName: item.fullDate,
        Omzet: item.omzet,
        Laba: item.laba
      }));
  };

  const chartData = assembleChartData();

  // --- ASSEMBLE PRODUCT RANKS ---
  const assembleProductRankings = () => {
    const list = getFilteredTransactions();
    const map: { [id: number]: { product: any; qty: number; revenue: number } } = {};

    list.forEach(tx => {
      tx.items.forEach(it => {
        if (!map[it.productId]) {
          const matchedProd = products.find(p => p.id === it.productId);
          map[it.productId] = {
            product: matchedProd || { name: it.name, color: "#10B981" },
            qty: 0,
            revenue: 0
          };
        }
        map[it.productId].qty += it.qty;
        map[it.productId].revenue += (it.price * it.qty);
      });
    });

    return Object.values(map)
      .sort((a, b) => b.qty - a.qty)
      .slice(0, 5); // top 5
  };

  const topProductRankings = assembleProductRankings();
  const maxQty = topProductRankings.length > 0 ? topProductRankings[0].qty : 1;

  // --- QUICK ADD HANDLERS ---
  const addQuickItemRow = () => {
    // Pick the first available product with positive stock if exists, else first product
    const initialProduct = products.find(p => p.stock > 0) || products[0];
    const initialProductQty = initialProduct && initialProduct.stock > 0 ? 1 : 0;
    setQuickItems([...quickItems, { productId: initialProduct?.id || 1, qty: initialProductQty }]);
  };

  const removeQuickItemRow = (index: number) => {
    setQuickItems(quickItems.filter((_, idx) => idx !== index));
  };

  const updateQuickItem = (index: number, val: Partial<{ productId: number; qty: number }>) => {
    setQuickItems(
      quickItems.map((item, idx) => {
        if (idx !== index) return item;
        const merged = { ...item, ...val };
        
        const prod = products.find(p => p.id === merged.productId);
        if (prod) {
          if (prod.stock <= 0) {
            addToast(`Stok "${prod.name}" habis total!`, "error");
            return { ...merged, qty: 0 };
          }
          if (merged.qty > prod.stock) {
            addToast(`Stok "${prod.name}" tidak mencukupi! Hanya ada ${prod.stock} ${prod.unit || "item"}.`, "error");
            return { ...merged, qty: prod.stock };
          }
        }
        return merged;
      })
    );
  };

  const handleSaveQuickTransaction = () => {
    if (quickItems.length === 0) {
      addToast("Silakan tambahkan minimal satu produk!", "warning");
      return;
    }

    // Comprehensive validation checks for stock and quantity
    for (const item of quickItems) {
      const prod = products.find(p => p.id === item.productId);
      if (!prod) {
        addToast("Produk tidak valid!", "error");
        return;
      }
      if (prod.stock <= 0) {
        addToast(`Gagal: Menu "${prod.name}" sudah habis (stok 0).`, "error");
        return;
      }
      if (item.qty <= 0) {
        addToast(`Gagal: Jumlah item untuk "${prod.name}" harus lebih dari 0.`, "error");
        return;
      }
      if (item.qty > prod.stock) {
        addToast(`Gagal: Stok "${prod.name}" tidak mencukupi (Sisa stok: ${prod.stock}).`, "error");
        return;
      }
    }

    addTransaction(quickItems);
    setQuickAddOpen(false);
    
    // Reset draft cart with first viable product
    const initialProduct = products.find(p => p.stock > 0) || products[0];
    const initialProductQty = initialProduct && initialProduct.stock > 0 ? 1 : 0;
    setQuickItems([{ productId: initialProduct?.id || 1, qty: initialProductQty }]);
  };

  // Greeting based on hour
  const getGreeting = () => {
    const hr = new Date().getHours();
    if (hr < 11) return "Selamat pagi";
    if (hr < 15) return "Selamat siang";
    if (hr < 18) return "Selamat sore";
    return "Selamat malam";
  };

  // Custom Chart Formatted Tooltip
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const displayLabel = payload[0].payload.fullName || label;
      return (
        <div className="bg-stone-900 border border-stone-800 text-stone-100 p-3 rounded-2xl shadow-xl space-y-1.5 text-xs font-sans min-w-[180px]">
          <p className="font-extrabold text-stone-400 border-b border-stone-800 pb-1 mb-1 font-heading uppercase tracking-wider">{displayLabel}</p>
          <p className="font-bold flex justify-between gap-4">
            <span>Omzet:</span>
            <span className="text-emerald-400 font-extrabold">{formatRupiah(payload[0].value)}</span>
          </p>
          {payload[1] && (
            <p className="font-bold flex justify-between gap-4">
              <span>Laba:</span>
              <span className="text-amber-400 font-extrabold">{formatRupiah(payload[1].value)}</span>
            </p>
          )}
          {payload[0].value > 0 && payload[1] && (
            <p className="text-[10px] text-stone-500 font-bold border-t border-stone-800 pt-1 mt-1 font-mono uppercase">
              Margin Laba: {Math.round((payload[1].value / payload[0].value) * 100)}%
            </p>
          )}
        </div>
      );
    }
    return null;
  };

  // --- CSV / EXCEL EXPORT CONTROLLER ---
  const generateCSVDataString = () => {
    const filteredTx = getFilteredTransactions();
    
    // Calculate global stats for current active period window
    const totalOmzet = filteredTx.reduce((sum, t) => sum + t.totalAmount, 0);
    const totalModal = filteredTx.reduce((sum, t) => sum + t.totalModal, 0);
    
    // Filter expenses on corresponding active period
    const limitDate = new Date();
    limitDate.setHours(0, 0, 0, 0);
    if (selectedPeriod === "7d") limitDate.setDate(limitDate.getDate() - 6);
    else if (selectedPeriod === "30d") limitDate.setDate(limitDate.getDate() - 29);
    
    const filteredEx = expenses.filter(e => {
      if (selectedPeriod === "all") return true;
      return new Date(e.timestamp) >= limitDate;
    });
    
    const totalExp = filteredEx.reduce((sum, e) => sum + e.amount, 0);
    const profitKotor = totalOmzet - totalModal;
    const netProfit = profitKotor - totalExp;
    const marginPercent = totalOmzet > 0 ? Math.round((netProfit / totalOmzet) * 100) : 0;

    // Helper to escape double quotes in CSV cells
    const escapeCSV = (str: string) => `"${str.replace(/"/g, '""')}"`;

    let csv = "";
    // CSV Title & Metadata Block
    csv += `LAPORAN PERFORMANCE KEUANGAN - ${(storeProfile?.name || "WARUNG BUDI").toUpperCase()}\r\n`;
    csv += `Pemilik Usaha,${escapeCSV(storeProfile?.owner?.name || "Budi Santoso")}\r\n`;
    csv += `Sektor/Tipe,${escapeCSV(storeProfile?.type || "Kuliner")}\r\n`;
    csv += `Rentang Analisis,${selectedPeriod === "7d" ? "7 Hari Terakhir" : selectedPeriod === "30d" ? "30 Hari Terakhir" : "Semua Periode Tercatat"}\r\n`;
    csv += `Waktu Ekspor,${new Date().toLocaleString("id-ID")}\r\n`;
    csv += `\r\n`;

    // Financial Metrics Summary Box
    csv += `=== RINGKASAN REKAPITULASI KEUANGAN ===\r\n`;
    csv += `Parameter Keuangan,Jumlah Pembukuan (Rupiah)\r\n`;
    csv += `Total Omzet Kotor (Penjualan),Rp ${totalOmzet.toLocaleString("id-ID")}\r\n`;
    csv += `Total Biaya Pokok (Modal HPP),Rp ${totalModal.toLocaleString("id-ID")}\r\n`;
    csv += `Laba Kotor Semula,Rp ${profitKotor.toLocaleString("id-ID")}\r\n`;
    csv += `Total Pengeluaran Logistik/Operasional,Rp ${totalExp.toLocaleString("id-ID")}\r\n`;
    csv += `Estimasi Laba Bersih (Bersih Dibawa),Rp ${netProfit.toLocaleString("id-ID")}\r\n`;
    csv += `Persentase Profitabilitas Margin,${marginPercent}%\r\n`;
    csv += `\r\n`;

    // Top Products
    csv += `=== MAKANAN & MINUMAN PALING SELEKTIF ===\r\n`;
    csv += `Nomor,Nama Produk,Kuantitas Terjual,Kontribusi Nilai Omzet (IDR)\r\n`;
    topProductRankings.forEach((pItem, idx) => {
      csv += `${idx + 1},${escapeCSV(pItem.product.name)},${pItem.qty},Rp ${pItem.revenue.toLocaleString("id-ID")}\r\n`;
    });
    csv += `\r\n`;

    // Ledger Transactions Detail
    csv += `=== BUKU BESAR DETAIL PENJUALAN (TRANSAKSI) ===\r\n`;
    csv += `ID Transaksi,Waktu Penjualan,Daftar Belanja Menu,Total Item,Total Omzet Pokok (IDR),Biaya Modal (HPP) (IDR),Laba Bersih Transaksi (IDR)\r\n`;
    filteredTx.forEach(tx => {
      const itemsStr = tx.items.map((it: any) => `${it.qty}x ${it.name}`).join(" | ");
      const totalPcs = tx.items.reduce((acc: number, it: any) => acc + it.qty, 0);
      const dateLocal = new Date(tx.timestamp).toLocaleString("id-ID", {
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      });
      csv += `${tx.id},${escapeCSV(dateLocal)},${escapeCSV(itemsStr)},${totalPcs},${tx.totalAmount},${tx.totalModal},${tx.profit}\r\n`;
    });
    csv += `\r\n`;

    // Expenses Log
    csv += `=== UTANG ATAU BIAYA OPERASIONAL LOGISTIK ===\r\n`;
    csv += `ID Pengeluaran,Tanggal Transaksi,Deskripsi Biaya,Kategori Pengeluaran,Jumlah Biaya (IDR)\r\n`;
    filteredEx.forEach(ex => {
      const exDate = new Date(ex.timestamp).toLocaleDateString("id-ID", {
        day: "numeric",
        month: "long",
        year: "numeric"
      });
      csv += `${ex.id},${escapeCSV(exDate)},${escapeCSV(ex.description)},${escapeCSV(ex.category || "Operasional")},${ex.amount}\r\n`;
    });

    return csv;
  };

  const handleExportCSV = () => {
    try {
      const csv = generateCSVDataString();
      const blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), csv], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `Laporan_Pembukuan_${storeProfile?.name?.replace(/\s+/g, "_") || "Toko"}_${selectedPeriod}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      addToast(`Excel (CSV) untuk periode "${selectedPeriod === "7d" ? "7 Hari" : selectedPeriod === "30d" ? "30 Hari" : "Semua"}" sukses diunduh!`, "success");
    } catch (e: any) {
      addToast("Tidak bisa unduh file secara langsung di iframe - Silakan Salin Data CSV sebagai ganti!", "warning");
    }
    setExportDropdownOpen(false);
  };

  const handleCopyCSVToClipboard = () => {
    try {
      const csv = generateCSVDataString();
      navigator.clipboard.writeText(csv);
      addToast("Data Excel (CSV) berhasil disalin ke papan klip!", "success");
    } catch (err) {
      addToast("Gagal menyalin ke papan klip.", "error");
    }
    setExportDropdownOpen(false);
  };

  const handleCopyReportText = () => {
    try {
      const filteredTx = getFilteredTransactions();
      const totalOmzet = filteredTx.reduce((sum, t) => sum + t.totalAmount, 0);
      const totalModal = filteredTx.reduce((sum, t) => sum + t.totalModal, 0);
      const profitKotor = totalOmzet - totalModal;
      
      const limitDate = new Date();
      limitDate.setHours(0, 0, 0, 0);
      if (selectedPeriod === "7d") limitDate.setDate(limitDate.getDate() - 6);
      else if (selectedPeriod === "30d") limitDate.setDate(limitDate.getDate() - 29);
      
      const filteredEx = expenses.filter(e => {
        if (selectedPeriod === "all") return true;
        return new Date(e.timestamp) >= limitDate;
      });
      const totalExp = filteredEx.reduce((sum, e) => sum + e.amount, 0);
      const netProfit = profitKotor - totalExp;

      const textReport = `===========================================
LAPORAN PERFORMANCE KEUANGAN NYATA: ${(storeProfile?.name || "WARUNG BUDI").toUpperCase()}
===========================================
Pemilik Usaha               : ${storeProfile?.owner?.name || "Budi Santoso"}
Sektor Usaha                : ${storeProfile?.type || "Kuliner"}
Periode Laporan             : ${selectedPeriod === "7d" ? "7 Hari Terakhir" : selectedPeriod === "30d" ? "30 Hari Terakhir" : "Semua Periode"}
Waktu Penarikan Data        : ${new Date().toLocaleString("id-ID")}

[ RINGKASAN REKAPITULASI KEUANGAN ]
- Total Omzet Kotor         : ${formatRupiah(totalOmzet)}
- Total Biaya Pokok (HPP)   : ${formatRupiah(totalModal)}
- Laba Kotor                : ${formatRupiah(profitKotor)}
- Biaya Pengeluaran/Utang   : ${formatRupiah(totalExp)}
- Estimasi Laba Bersih      : ${formatRupiah(netProfit)}
- Persentase Margin         : ${totalOmzet > 0 ? Math.round((netProfit / totalOmzet) * 100) : 0}%

[ 5 PRODUK PALING POPULER ]
${topProductRankings.map((it, idx) => `- Peringkat #${idx + 1}: ${it.product.name} (Volume: ${it.qty} porsi, Omzet: ${formatRupiah(it.revenue)})`).join("\n")}

Diperoleh secara tersertifikasi langsung lewat Kasir AI Copilot.
===========================================`;

      navigator.clipboard.writeText(textReport);
      addToast("Teks lengkap draf laporan berhasil disalin ke papan klip!", "success");
    } catch (err) {
      addToast("Gagal menyalin laporan.", "error");
    }
  };

  const handlePrintPDF = () => {
    const reportElement = document.getElementById("printable-report-modal");
    if (!reportElement) {
      window.print();
      return;
    }

    try {
      // Open same-origin blank window to avoid auth bridge redirections and 403 errors
      const printWindow = window.open("", "_blank");
      if (!printWindow) {
        addToast("Popup cetak diblokir! Silakan izinkan popup di pengaturan browser Anda.", "warning");
        return;
      }

      // Gather current style and stylesheet tags to render perfectly
      let stylesHtml = "";
      document.querySelectorAll("link[rel='stylesheet'], style").forEach((el) => {
        stylesHtml += el.outerHTML;
      });

      const reportHtml = reportElement.innerHTML;

      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Laporan Keuangan - ${storeProfile?.name || "Toko"}</title>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            ${stylesHtml}
            <style>
              body {
                background: white !important;
                color: #1a1513 !important;
                padding: 40px !important;
                font-family: 'Inter', system-ui, sans-serif !important;
              }
              .no-print {
                display: none !important;
              }
              @media print {
                body {
                  padding: 0 !important;
                  margin: 0 !important;
                  background: white !important;
                }
                .no-print {
                  display: none !important;
                }
                * {
                  -webkit-print-color-adjust: exact !important;
                  print-color-adjust: exact !important;
                }
              }
            </style>
          </head>
          <body>
            <div id="printable-report-modal" class="w-full max-w-4xl mx-auto bg-white p-2">
              ${reportHtml}
            </div>
            <script>
              window.focus();
              // Small delay to ensure all assets are rendered before opening print dialog
              setTimeout(() => {
                window.print();
              }, 500);
            </script>
          </body>
        </html>
      `);
      printWindow.document.close();
      addToast("Menyiapkan dokumen laporan PDF...", "success");
    } catch (err) {
      // Fallback
      window.print();
    }
  };

  // Derive details for the active period to show in the PDF preview
  const reportTx = getFilteredTransactions().sort((a: any, b: any) => b.timestamp.localeCompare(a.timestamp));

  return (
    <div className="space-y-8 max-w-[1400px] mx-auto">
      {/* 1. GREETING GRADIENT BANNER */}
      <div className="bg-gradient-to-br from-[#064E3B] via-[#047857] to-[#10B981] rounded-3xl p-8 md:p-10 text-white relative overflow-hidden shadow-[0_20px_40px_-15px_rgba(16,185,129,0.3)] flex justify-between items-center group">
        {/* Decorative circle */}
        <div className="absolute -bottom-16 -right-16 w-64 h-64 bg-white/10 rounded-full blur-3xl group-hover:bg-white/20 transition-all duration-700" />
        <div className="absolute top-0 right-1/3 w-32 h-32 bg-emerald-300/20 rounded-full blur-2xl" />
        
        <div className="space-y-4 z-10 max-w-[calc(100%-110px)]">
          <p className="text-[11px] font-black uppercase text-emerald-100/80 tracking-widest">Dashboard UMKM</p>
          <h2 className="font-heading font-extrabold text-2xl md:text-4xl tracking-tight leading-tight">
            {getGreeting()}, <span className="text-emerald-100">{storeProfile?.owner?.name || "Budi Santoso"}!</span> 👋
          </h2>
          <div className="flex flex-col sm:flex-row sm:items-center gap-3 pt-2">
            <span className="text-sm text-emerald-50/90 font-medium bg-black/10 px-3 py-1 rounded-full backdrop-blur-sm border border-white/10">{formatFullDate(new Date())}</span>
            {targetCompletedPercent < 42 && (
              <span className="inline-flex items-center gap-2 self-start text-[11px] font-bold bg-amber-500/20 border border-amber-400/40 px-3 py-1 rounded-full text-amber-100 backdrop-blur-sm">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                Penjualan masih {targetCompletedPercent}% dari target bulanan ({formatRupiah(monthlyTarget)})
              </span>
            )}
          </div>
        </div>

        {/* Small SVG Logo representation */}
        <div className="text-white opacity-[0.07] hidden md:block shrink-0 -mr-6 -mt-6 transform rotate-12 group-hover:rotate-0 group-hover:scale-110 transition-all duration-700">
          <Sparkles className="w-40 h-40" />
        </div>
      </div>

      {/* 2. STATS OVERVIEW CARDS (4-Columns) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5" id="stats-grid">
        {/* Card 1: Omzet Hari Ini */}
        <div className="group bg-white rounded-3xl p-6 flex flex-col justify-between hover:shadow-xl hover:-translate-y-1 transition-all duration-300 shadow-sm border border-stone-100 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-bl-[100px] -z-10 group-hover:scale-110 transition-transform duration-300" />
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black uppercase text-stone-400 tracking-widest">Omzet Hari Ini</span>
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-50 to-emerald-100/50 text-emerald-600 rounded-2xl flex items-center justify-center shadow-inner border border-emerald-100/50">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-6">
            <h3 className="font-heading font-extrabold text-3xl text-stone-900 tracking-tight">
              {formatRupiah(todayRevenue)}
            </h3>
            <p className="text-[11px] text-emerald-600 font-bold mt-2 uppercase tracking-wide">Dihitung otomatis</p>
          </div>
        </div>

        {/* Card 2: Sales Counts */}
        <div className="group bg-white rounded-3xl p-6 flex flex-col justify-between hover:shadow-xl hover:-translate-y-1 transition-all duration-300 shadow-sm border border-stone-100 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-sky-500/5 rounded-bl-[100px] -z-10 group-hover:scale-110 transition-transform duration-300" />
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black uppercase text-stone-400 tracking-widest">Transaksi Harian</span>
            <div className="w-10 h-10 bg-gradient-to-br from-sky-50 to-sky-100/50 text-sky-600 rounded-2xl flex items-center justify-center shadow-inner border border-sky-100/50">
              <ShoppingBag className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-6">
            <h3 className="font-heading font-extrabold text-3xl text-stone-900 tracking-tight">
              {todayTransactionsCount} <span className="text-sm text-stone-400 font-medium ml-1">struk</span>
            </h3>
            <p className="text-[11px] text-sky-600 font-bold mt-2 uppercase tracking-wide">Pelanggan Aktif</p>
          </div>
        </div>

        {/* Card 3: Best Seller Today */}
        <div className="group bg-white rounded-3xl p-6 flex flex-col justify-between hover:shadow-xl hover:-translate-y-1 transition-all duration-300 shadow-sm border border-stone-100 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-bl-[100px] -z-10 group-hover:scale-110 transition-transform duration-300" />
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black uppercase text-stone-400 tracking-widest">Terlaris</span>
            <div className="w-10 h-10 bg-gradient-to-br from-amber-50 to-amber-100/50 text-amber-600 rounded-2xl flex items-center justify-center shadow-inner border border-amber-100/50">
              <Star className="w-5 h-5 fill-amber-500/20" />
            </div>
          </div>
          <div className="mt-6">
            <h3 className="font-heading font-extrabold text-xl text-stone-900 tracking-tight truncate leading-tight h-8 flex items-end">
              {todayTopProduct}
            </h3>
            <p className="text-[11px] text-amber-600 font-bold mt-2 uppercase tracking-wide">
              {todayTopQty > 0 ? `${todayTopQty} porsi terjual` : "Belum ada pesanan"}
            </p>
          </div>
        </div>

        {/* Card 4: Net Profits */}
        <div className="group bg-white rounded-3xl p-6 flex flex-col justify-between hover:shadow-xl hover:-translate-y-1 transition-all duration-300 shadow-sm border border-stone-100 relative overflow-hidden bg-gradient-to-b from-white to-purple-50/30">
          <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/5 rounded-bl-[100px] -z-10 group-hover:scale-110 transition-transform duration-300" />
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black uppercase text-stone-400 tracking-widest">Laba Bersih</span>
            <div className="w-10 h-10 bg-gradient-to-br from-purple-50 to-purple-100/50 text-purple-600 rounded-2xl flex items-center justify-center shadow-inner border border-purple-100/50">
              <Wallet className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-6">
            <h3 className="font-heading font-extrabold text-3xl text-purple-900 tracking-tight">
              {formatRupiah(todayLaba)}
            </h3>
            <p className="text-[11px] text-purple-600 font-bold mt-2 uppercase tracking-wide flex items-center gap-1">
              <Percent className="w-3 h-3 text-purple-500" />
              Margin Kotor: {todayRevenue > 0 ? Math.round((todayLaba / todayRevenue) * 100) : 0}%
            </p>
          </div>
        </div>
      </div>

      {/* 3. SALES LINE CHART */}
      <div className="bg-white border border-stone-200/60 p-6 rounded-2xl shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 border-b border-stone-100 pb-4">
          <div>
            <h3 className="font-heading font-extrabold text-stone-800 text-sm">Grafik Tren Omzet vs Laba</h3>
            <p className="text-[11px] text-stone-400">Menampilkan statistik kumulatif omzet penjualan kotor berbanding estimasi saku bersih bawaan modal</p>
          </div>
          {/* Toggles & Exports Group */}
          <div className="flex flex-wrap items-center gap-2.5 self-start sm:self-center">
            {/* Toggles */}
            <div className="flex bg-stone-100 p-1 rounded-xl">
              <button
                onClick={() => setSelectedPeriod("7d")}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold cursor-pointer ${
                  selectedPeriod === "7d" ? "bg-white text-stone-800 shadow-sm" : "text-stone-500 hover:text-stone-800"
                }`}
              >
                7 Hari
              </button>
              <button
                onClick={() => setSelectedPeriod("30d")}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold cursor-pointer ${
                  selectedPeriod === "30d" ? "bg-white text-stone-800 shadow-sm" : "text-stone-500 hover:text-stone-800"
                }`}
              >
                30 Hari
              </button>
              <button
                onClick={() => setSelectedPeriod("all")}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold cursor-pointer ${
                  selectedPeriod === "all" ? "bg-white text-stone-800 shadow-sm" : "text-stone-500 hover:text-stone-800"
                }`}
              >
                Semua
              </button>
            </div>

            {/* Premium Export Console Dropdown Button */}
            <div className="relative">
              <button
                onClick={() => setExportDropdownOpen(!exportDropdownOpen)}
                className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold rounded-xl shadow-xs transition duration-150 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Unduh Laporan</span>
                <ChevronRight className={`w-3.5 h-3.5 text-emerald-100 transform transition-transform duration-200 ${exportDropdownOpen ? "rotate-90" : ""}`} />
              </button>

              {exportDropdownOpen && (
                <>
                  <div 
                    className="fixed inset-0 z-10" 
                    onClick={() => setExportDropdownOpen(false)} 
                  />
                  <div className="absolute right-0 mt-2 w-56 bg-white border border-stone-200 rounded-2xl shadow-xl py-2 z-20 animate-fadeIn text-left">
                    <p className="px-4 py-1.5 text-[10px] font-black uppercase text-stone-400 tracking-wider">Pilih Format Laporan</p>
                    
                    <button
                      onClick={handleExportCSV}
                      className="w-full flex items-center gap-2.5 px-4 py-2 hover:bg-stone-50 text-xs font-semibold text-stone-700 hover:text-stone-900 transition text-left cursor-pointer"
                    >
                      <FileSpreadsheet className="w-4 h-4 text-emerald-600 shrink-0" />
                      <div>
                        <div className="leading-tight">Unduh Excel (.csv)</div>
                        <div className="text-[9px] font-bold text-stone-400">Sistem Unduhan Berkas</div>
                      </div>
                    </button>

                    <button
                      onClick={handleCopyCSVToClipboard}
                      className="w-full flex items-center gap-2.5 px-4 py-2 hover:bg-stone-50 text-xs font-semibold text-teal-800 hover:text-teal-950 transition text-left cursor-pointer border-b border-stone-100 pb-2 bg-emerald-50/20"
                    >
                      <Copy className="w-4 h-4 text-teal-600 shrink-0" />
                      <div>
                        <div className="leading-tight font-black">Salin Data CSV</div>
                        <div className="text-[9px] font-bold text-stone-400">Solusi Cadangan Iframe</div>
                      </div>
                    </button>

                    <button
                      onClick={() => {
                        setReportPreviewOpen(true);
                        setExportDropdownOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2 hover:bg-stone-50 text-xs font-semibold text-stone-700 hover:text-stone-900 transition text-left cursor-pointer"
                    >
                      <FileText className="w-4 h-4 text-amber-500 shrink-0" />
                      <div>
                        <div className="leading-tight">Cetak PDF / Laporan</div>
                        <div className="text-[9px] font-bold text-stone-400">Pratinjau Cetak Formal</div>
                      </div>
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="h-[320px] w-full mt-2">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 10, right: 15, left: 10, bottom: 0 }}>
              <defs>
                <linearGradient id="colorOmzet" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10B981" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
              <XAxis dataKey="fullName" tickFormatter={(v) => v.split(',')[0]} tick={{ fill: "#9CA3AF", fontSize: 11, fontWeight: "600" }} axisLine={false} tickLine={false} tickMargin={12} />
              <YAxis tickFormatter={formatShortRupiah} tick={{ fill: "#9CA3AF", fontSize: 11, fontWeight: "600" }} axisLine={false} tickLine={false} tickMargin={8} />
              <Tooltip content={<CustomTooltip />} cursor={{ fill: "rgba(245, 245, 244, 0.4)" }} />
              <Legend verticalAlign="top" iconType="circle" height={44} wrapperStyle={{ fontSize: 12, fontWeight: "700", fontFamily: "sans-serif" }} />
              <Area type="monotone" dataKey="Omzet" stroke="#10B981" strokeWidth={3} fillOpacity={1} fill="url(#colorOmzet)" dot={{ strokeWidth: 2, r: 4, stroke: "#10B981", fill: "#fff" }} activeDot={{ r: 6, stroke: "#10B981", strokeWidth: 2, fill: "#fff" }} name="Omzet Penjualan" />
              <Line type="monotone" dataKey="Laba" stroke="#F59E0B" strokeWidth={2} strokeDasharray="4 4" dot={{ strokeWidth: 2, r: 3, stroke: "#F59E0B", fill: "#fff" }} activeDot={{ r: 5, stroke: "#F59E0B", strokeWidth: 2, fill: "#fff" }} name="Laba Bersih" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 4. REVENUE PRODUCT RANKINGS, STOK KRITIS, AND COPILOT AI INSIGHTS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Ranking items (4 cols grid) */}
        <div className="lg:col-span-4 bg-white border border-stone-200/60 p-6 rounded-2xl shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4 border-b border-stone-100 pb-3">
              <div>
                <h4 className="font-heading font-extrabold text-stone-800 text-xs">Peringkat 5 Menu Terlaris</h4>
                <p className="text-[10px] text-stone-400 capitalize">Berdasarkan volume penjualan disaring</p>
              </div>
              <button
                onClick={() => setActiveTab("produk")}
                className="text-xs font-extrabold text-emerald-600 hover:text-emerald-700 font-sans flex items-center gap-0.5 cursor-pointer"
              >
                Lihat Semua
                <Plus className="w-3.5 h-3.5 transform rotate-45" />
              </button>
            </div>

            <div className="space-y-4 py-2">
              {topProductRankings.length === 0 ? (
                <div className="text-center py-10 text-stone-400 text-xs font-bold uppercase tracking-wider">
                  Belum ada data penjualan tercatat.
                </div>
              ) : (
                topProductRankings.map((it, idx) => {
                  const percent = Math.round((it.qty / maxQty) * 100);
                  const rankColors = ["bg-amber-500", "bg-stone-400", "bg-amber-700", "bg-stone-100 text-stone-600", "bg-stone-100 text-stone-600"];
                  const isTextLight = idx < 3;

                  return (
                    <div key={idx} className="space-y-1.5 duration-150">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {/* Rank ring */}
                          <div className={`w-6 h-6 rounded-full font-black text-[10px] flex items-center justify-center select-none ${rankColors[idx]} ${isTextLight ? "text-white" : "text-stone-600"}`}>
                            {idx + 1}
                          </div>
                          {/* Product Avatar block */}
                          <div className="flex flex-col">
                            <span className="text-xs font-black text-stone-800 leading-none">{it.product.name}</span>
                            <span className="text-[10px] font-bold text-stone-400 mt-0.5">{it.qty} {it.product.unit || "item"} terjual</span>
                          </div>
                        </div>
                        {/* total revenues */}
                        <span className="text-xs font-black text-stone-800">{formatRupiah(it.revenue)}</span>
                      </div>
                      
                      {/* Progress bar */}
                      <div className="h-1.5 w-full bg-stone-100 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-300"
                          style={{
                            width: `${percent}%`,
                            backgroundColor: it.product.color || "#10B981"
                          }}
                        />
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Middle Stock Warning items (4 cols grid) */}
        <div id="papan-stok-kritis" className="lg:col-span-4 bg-white border border-stone-200/60 p-6 rounded-2xl shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4 border-b border-stone-100 pb-3">
              <div>
                <h4 className="font-heading font-extrabold text-stone-800 text-xs flex items-center gap-1.5">
                  <Package className="w-4 h-4 text-amber-500" />
                  Papan Stok Kritis
                </h4>
                <p className="text-[10px] text-stone-400 capitalize">Stok ≤ 5 porsi harus segera ditambah</p>
              </div>
              <button
                onClick={() => setActiveTab("produk")}
                className="text-xs font-extrabold text-emerald-600 hover:text-emerald-700 font-sans flex items-center gap-0.5 cursor-pointer"
              >
                Atur Stok
                <Plus className="w-3.5 h-3.5 transform rotate-45" />
              </button>
            </div>

            <div className="space-y-3 py-1 max-h-[265px] overflow-y-auto custom-scrollbar pr-1">
              {(() => {
                const criticalProducts = products.filter(p => p.stock <= 5).sort((a, b) => a.stock - b.stock);
                if (criticalProducts.length === 0) {
                  return (
                    <div className="text-center py-10 text-stone-400 text-xs font-bold uppercase tracking-wider space-y-1">
                      <div className="text-4xl text-center">🎉</div>
                      <p className="mt-2 text-emerald-600 font-extrabold">Semua Stok Aman!</p>
                      <p className="text-[9px] font-normal text-stone-400 lowercase leading-relaxed">Tidak ada bahan di bawah ambang batas minimum</p>
                    </div>
                  );
                }

                return criticalProducts.map((p) => {
                  const isEditingThis = restockProductId === p.id;
                  const isOutOfStock = p.stock === 0;

                  return (
                    <div key={p.id} className="p-3 bg-stone-50 border border-stone-200/55 rounded-xl space-y-2 hover:bg-stone-100/50 transition">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: p.color || "#EF4444" }} />
                          <div className="flex flex-col">
                            <span className="text-xs font-black text-stone-800 leading-tight">{p.name}</span>
                            <span className={`text-[10px] font-extrabold ${isOutOfStock ? "text-rose-600" : "text-amber-600"}`}>
                              {isOutOfStock ? "HABIS TOTAL (0)" : `Sisa ${p.stock} ${p.unit || "item"}`}
                            </span>
                          </div>
                        </div>

                        {/* Quick toggle controls */}
                        {!isEditingThis ? (
                          <button
                            onClick={() => {
                              setRestockProductId(p.id);
                              setRestockQtyInput("25"); // default smart value
                            }}
                            className="px-2.5 py-1 text-[9px] font-black uppercase tracking-wider border border-emerald-200 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg cursor-pointer transition active:scale-95 duration-100"
                          >
                            Isi Stok
                          </button>
                        ) : (
                          <button
                            onClick={() => setRestockProductId(null)}
                            className="text-stone-400 hover:text-stone-700 font-bold text-[9px] uppercase hover:underline cursor-pointer"
                          >
                            Batal
                          </button>
                        )}
                      </div>

                      {/* Expandable Quick Replenish Row Form */}
                      {isEditingThis && (
                        <div className="pt-2 border-t border-stone-200/50 flex flex-col gap-1.5 animate-fadeIn">
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              value={restockQtyInput}
                              onChange={(e) => setRestockQtyInput(e.target.value)}
                              placeholder="+ Qty"
                              className="w-14 h-7 text-xs font-bold text-center bg-white border border-stone-200 rounded-lg outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-300"
                            />
                            
                            {/* Fast presets selection pills */}
                            <button
                              onClick={() => setRestockQtyInput("10")}
                              className="px-2 py-1 bg-white hover:bg-stone-50 border border-stone-200 text-[9px] font-extrabold rounded-md text-stone-600 cursor-pointer"
                            >
                              +10
                            </button>
                            <button
                              onClick={() => setRestockQtyInput("50")}
                              className="px-2 py-1 bg-white hover:bg-stone-50 border border-stone-200 text-[9px] font-extrabold rounded-md text-stone-600 cursor-pointer"
                            >
                              +50
                            </button>

                            {/* Save execution CTA trigger */}
                            <button
                              onClick={async () => {
                                const addAmount = parseInt(restockQtyInput, 10);
                                if (isNaN(addAmount) || addAmount <= 0) {
                                  addToast("Jumlah tambah stok tidak valid!", "warning");
                                  return;
                                }
                                const updatedProduct = {
                                  ...p,
                                  stock: p.stock + addAmount
                                };
                                await updateProduct(updatedProduct);
                                addToast(`Stok "${p.name}" bertambah +${addAmount}. Total baru: ${updatedProduct.stock} ${p.unit || "item"}`, "success");
                                setRestockProductId(null);
                              }}
                              className="flex-1 h-7 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg flex items-center justify-center cursor-pointer transition shadow-xs text-[10px] font-black gap-0.5"
                            >
                              <Check className="w-3 h-3 text-white" />
                              Simpan
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                });
              })()}
            </div>
          </div>
        </div>

        {/* Right Insights Panel (4 cols grid) */}
        <div className="lg:col-span-4 bg-gradient-to-br from-stone-50 to-emerald-50/20 border border-stone-200/60 p-6 rounded-2xl shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4 border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-100/80 text-amber-600 flex items-center justify-center shrink-0">
                  <Sparkles className="w-4.5 h-4.5 animate-pulse" />
                </div>
                <div className="flex flex-col">
                  <h4 className="font-heading font-extrabold text-stone-800 text-xs">Rekomendasi AI Copilot</h4>
                  <p className="text-[10px] text-stone-400 text-left">Real-time harian</p>
                </div>
              </div>

              {/* Refresh button */}
              <button
                onClick={refreshDailyInsights}
                disabled={insightsLoading}
                className="p-1.5 text-stone-400 hover:text-emerald-600 hover:bg-stone-100 rounded-full cursor-pointer disabled:opacity-40 transition-all duration-150"
                title="Perbarui rekomendasi AI"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${insightsLoading ? "animate-spin text-emerald-600" : ""}`} />
              </button>
            </div>

            <div className="space-y-3 py-1">
              {dailyInsights.map((ins, idx) => (
                <div key={idx} className="flex gap-2.5 text-xs leading-relaxed">
                  <div className="w-4 h-4 bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0 rounded-full font-black text-[9px] mt-0.5">
                    ✓
                  </div>
                  <p className="font-semibold text-stone-600 text-left">
                    {ins}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4">
            <button
              onClick={() => setActiveTab("copilot")}
              className="flex items-center justify-center gap-1.5 w-full h-10 bg-stone-900 hover:bg-black text-white text-xs font-bold tracking-wide rounded-xl shadow-md transition transform active:scale-97 cursor-pointer"
            >
              Diskusi Lebih Detail dengan Copilot
              <ChevronRight className="w-3.5 h-3.5 text-emerald-400" />
            </button>
          </div>
        </div>
      </div>

      {/* 5. FLOATING QUICK ACTION BAR (FAB) ONLY ON MOBILE & TABLETS */}
      <button
        onClick={() => setQuickAddOpen(true)}
        className="fixed bottom-20 md:bottom-6 right-6 w-14 h-14 bg-emerald-600 hover:bg-emerald-700 hover:scale-105 active:scale-95 text-white flex items-center justify-center rounded-full shadow-2xl z-40 duration-200 cursor-pointer border border-emerald-500"
        title="Catat Transaksi Cepat"
      >
        <Plus className="w-7 h-7 text-white" />
      </button>

      {/* QUICK ADD MODAL DIALOG */}
      {quickAddOpen && (
        <div className="fixed inset-0 bg-stone-900/40 backdrop-blur-xs flex items-end md:items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl md:rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl border border-stone-200 animate-slide-up duration-150 p-6 flex flex-col max-h-[85vh]">
            
            {/* Header */}
            <div className="flex justify-between items-center pb-4 border-b border-stone-100 shrink-0">
              <div className="flex items-center gap-2">
                <PlusSquare className="w-5 h-5 text-emerald-600" />
                <h3 className="font-heading font-extrabold text-stone-800 text-sm">Catat Penjualan</h3>
              </div>
              <button
                onClick={() => setQuickAddOpen(false)}
                className="p-1 text-stone-400 hover:text-stone-800 rounded-full hover:bg-stone-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content List Items */}
            <div className="flex-1 py-4 overflow-y-auto space-y-4">
              {quickItems.map((item, idx) => {
                const matchedProd = products.find(p => p.id === item.productId);
                const isOutOfStock = !matchedProd || matchedProd.stock <= 0;
                const isLowStock = matchedProd && matchedProd.stock > 0 && matchedProd.stock <= 5;
                
                return (
                  <div key={idx} className="space-y-2 bg-stone-50 p-3.5 rounded-2xl border border-stone-200/50">
                    <div className="flex gap-2.5 items-center">
                      {/* Choose Product */}
                      <select
                        value={item.productId}
                        onChange={(e) => {
                          const newProdId = parseInt(e.target.value, 10);
                          const newProd = products.find(p => p.id === newProdId);
                          const defaultQty = newProd && newProd.stock <= 0 ? 0 : 1;
                          updateQuickItem(idx, { productId: newProdId, qty: defaultQty });
                        }}
                        className="flex-1 h-10 px-2.5 text-xs font-bold text-stone-800 rounded-xl border border-stone-200 outline-none bg-white focus:border-emerald-500 shadow-xs focus:ring-1 focus:ring-emerald-500/20"
                      >
                        {products.map(p => (
                          <option key={p.id} value={p.id}>
                            {p.name} ({formatRupiah(p.price)}) {p.stock <= 0 ? "[HABIS]" : `[Stok: ${p.stock}]`}
                          </option>
                        ))}
                      </select>

                      {/* Stepper qty controls */}
                      <div className="flex items-center gap-1 bg-white border border-stone-200 rounded-xl h-10 px-1.5 shadow-xs">
                        <button
                          type="button"
                          onClick={() => updateQuickItem(idx, { qty: Math.max(1, item.qty - 1) })}
                          disabled={isOutOfStock}
                          className="w-6 h-6 flex items-center justify-center rounded-lg hover:bg-stone-50 disabled:opacity-40 text-stone-500 hover:text-stone-800 transition cursor-pointer active:scale-90"
                        >
                          <MinusCircle className="w-4 h-4" />
                        </button>
                        <input
                          type="number"
                          value={item.qty}
                          disabled={isOutOfStock}
                          onChange={(e) => updateQuickItem(idx, { qty: Math.max(0, parseInt(e.target.value, 10) || 0) })}
                          className="w-8 text-center text-xs font-black text-stone-800 bg-transparent shrink-0 outline-none"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            if (matchedProd && item.qty >= matchedProd.stock) {
                              addToast(`Stok "${matchedProd.name}" sudah mencapai batas maksimum!`, "error");
                            } else {
                              updateQuickItem(idx, { qty: item.qty + 1 });
                            }
                          }}
                          disabled={isOutOfStock}
                          className="w-6 h-6 flex items-center justify-center rounded-lg hover:bg-stone-50 disabled:opacity-40 text-stone-500 hover:text-stone-800 transition cursor-pointer active:scale-90"
                        >
                          <PlusCircle className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Trash row */}
                      {quickItems.length > 1 && (
                        <button
                          onClick={() => removeQuickItemRow(idx)}
                          className="p-2 text-stone-400 hover:text-rose-600 hover:bg-rose-50 border border-transparent hover:border-stone-200 rounded-xl cursor-pointer shrink-0 transition"
                          title="Hapus Baris"
                        >
                          <Trash2Custom className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>

                    {/* Stock status metadata indicator */}
                    <div className="flex justify-between items-center px-1 text-[10px] font-bold">
                      {isOutOfStock ? (
                        <span className="text-rose-600 flex items-center gap-1 font-extrabold uppercase animate-pulse">
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                          Stok Habis
                        </span>
                      ) : isLowStock ? (
                        <span className="text-amber-600 flex items-center gap-1 font-extrabold">
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                          Stok Tipis: Sisa {matchedProd.stock} {matchedProd.unit || "item"}
                        </span>
                      ) : (
                        <span className="text-stone-400 font-semibold">
                          Tersedia: {matchedProd.stock} {matchedProd.unit || "item"}
                        </span>
                      )}
                      
                      {matchedProd && (
                        <span className="font-mono text-stone-500">
                          Subtotal: {formatRupiah(matchedProd.price * item.qty)}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}

              <button
                onClick={addQuickItemRow}
                className="text-xs font-extrabold text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 flex items-center justify-center py-2 px-4 rounded-xl border border-dashed border-emerald-300 w-full duration-150 cursor-pointer"
              >
                ＋ Tambah Baris Menu
              </button>
            </div>

            {/* Calculations total sum section */}
            <div className="bg-emerald-50/60 border border-emerald-100/50 p-4 rounded-xl shrink-0 space-y-2 mb-4">
              <div className="flex justify-between items-center text-xs font-bold text-stone-500">
                <span>Total Jumlah:</span>
                <span>
                  {quickItems.reduce((acc, item) => acc + item.qty, 0)} Item
                </span>
              </div>
              <div className="flex justify-between items-center font-heading">
                <span className="text-xs font-bold text-stone-600">Total Tagihan:</span>
                <span className="text-sm font-extrabold text-emerald-800">
                  {formatRupiah(
                    quickItems.reduce((acc, item) => {
                      const matched = products.find(p => p.id === item.productId);
                      return acc + (matched ? matched.price * item.qty : 0);
                    }, 0)
                  )}
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="grid grid-cols-2 gap-4 shrink-0">
              <button
                onClick={() => setQuickAddOpen(false)}
                className="h-10 border border-stone-200 hover:bg-stone-50 font-bold text-xs rounded-xl transition duration-150 cursor-pointer text-stone-500"
              >
                Batal
              </button>
              <button
                onClick={handleSaveQuickTransaction}
                className="h-10 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-md transform active:scale-97 duration-150 cursor-pointer"
              >
                Catat Nota
              </button>
            </div>
          </div>
        </div>
      )}

      {/* RENDER BEAUTIFUL BUSINESS REPORT PREVIEW MODAL */}
      {reportPreviewOpen && (
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto no-print">
          <div className="bg-white rounded-3xl w-full max-w-4xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col my-8 max-h-[90vh]">
            
            {/* Modal Interactive Header */}
            <div className="flex justify-between items-center px-6 py-4 bg-stone-50 border-b border-stone-200/80 shrink-0">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-600" />
                <h3 className="font-heading font-extrabold text-stone-800 text-sm">Pratinjau Laporan Keuangan</h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyReportText}
                  className="flex items-center gap-1.5 px-3 h-9 bg-teal-50 border border-teal-200 hover:bg-teal-100/80 text-teal-800 font-extrabold text-xs rounded-xl cursor-pointer duration-150 transition active:scale-95"
                >
                  <Copy className="w-3.5 h-3.5 text-teal-600" />
                  Salin Teks Laporan
                </button>
                <button
                  onClick={handlePrintPDF}
                  className="flex items-center gap-1.5 px-4 h-9 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-md cursor-pointer duration-150 transition active:scale-95"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Cetak / Simpan PDF
                </button>
                <button
                  onClick={() => setReportPreviewOpen(false)}
                  className="p-1.5 text-stone-400 hover:text-stone-700 rounded-full hover:bg-stone-200"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Printable Report Sheet Content Body */}
            <div className="flex-1 overflow-y-auto p-8 md:p-12 space-y-8 bg-white custom-scrollbar" id="printable-report-modal">
              {/* Dynamic Styled Block for Native PDF Printing Controls Isolation */}
              <style>{`
                @media print {
                  body {
                    background: white !important;
                    color: black !important;
                  }
                  /* Hide normal page elements when printing */
                  body * {
                    visibility: hidden !important;
                  }
                  /* Only keep the printable report modal and its descendants visible */
                  #printable-report-modal,
                  #printable-report-modal * {
                    visibility: visible !important;
                  }
                  /* Isolate and style the PDF container */
                  #printable-report-modal {
                    position: absolute !important;
                    left: 0 !important;
                    top: 0 !important;
                    width: 100% !important;
                    padding: 0px !important;
                    margin: 0px !important;
                    height: auto !important;
                    background: white !important;
                    color: black !important;
                    box-shadow: none !important;
                    border: none !important;
                    z-index: 99999 !important;
                  }
                  /* Ensure page breaks are handled nicely */
                  .page-break {
                    page-break-before: always;
                  }
                  /* Enforce text styles during physical print colors override */
                  * {
                    -webkit-print-color-adjust: exact !important;
                    print-color-adjust: exact !important;
                  }
                }
              `}</style>

              {/* Tips Banner (hides when printed) */}
              <div className="no-print bg-amber-50 border border-amber-200 rounded-2xl p-4 flex gap-3 text-xs leading-relaxed text-amber-900 shadow-xs mb-4">
                <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <p className="font-extrabold text-amber-950 mb-0.5">💡 Tips Kasir Pintar (Bebas Hambatan Iframe)</p>
                  <p className="font-medium text-amber-800">
                    Karena keterbatasan iFrame browser, tombol <b>"Cetak / Simpan PDF"</b> mungkin terblokir atau memprint halaman luar. 
                    Gunakan tombol <b className="text-teal-900 font-extrabold">"Salin Teks Laporan"</b> di atas atau di bawah untuk menyalin rekap teks lengkap, atau buka aplikasi di <b>Tab Baru</b> untuk meloloskan cetak langsung!
                  </p>
                </div>
              </div>

              {/* PDF Document Header BRANDING */}
              <div className="border-b-4 border-emerald-900 pb-6 flex justify-between items-start">
                <div className="space-y-1.5">
                  <p className="text-emerald-800 text-[11px] font-black tracking-widest uppercase mb-1">LAPORAN KEUANGAN KASIR AI</p>
                  <h1 className="font-heading font-extrabold text-3xl text-stone-900 tracking-tight">{(storeProfile?.name || "WARUNG MAKAN").toUpperCase()}</h1>
                  <p className="text-xs text-stone-500 font-bold">
                    Pemilik: <span className="text-stone-700">{storeProfile?.owner?.name || "Budi Santoso"}</span>  •  Tipe Usaha: <span className="text-stone-700">{storeProfile?.type || "Kuliner"}</span>
                  </p>
                </div>
                <div className="text-right space-y-1">
                  <div className="bg-emerald-50 text-emerald-800 text-[10px] font-black px-3 py-1 rounded-full uppercase inline-block">
                    {selectedPeriod === "7d" ? "7 Hari Terakhir" : selectedPeriod === "30d" ? "30 Hari Terakhir" : "Semua Data"}
                  </div>
                  <p className="text-[10px] text-stone-400 font-semibold pt-1">
                    Tanggal Cetak: {new Date().toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" })}
                  </p>
                </div>
              </div>

              {/* Stats Highlighting Matrix Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 leading-tight">
                  <span className="text-[9px] font-black text-stone-400 uppercase tracking-wider">OMZET KOTOR</span>
                  <div className="text-xl font-extrabold text-stone-900 mt-1">{formatRupiah(reportTx.reduce((sum, t) => sum + t.totalAmount, 0))}</div>
                  <p className="text-[9px] font-bold text-stone-400 mt-1 uppercase">Total Pendapatan</p>
                </div>
                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 leading-tight">
                  <span className="text-[10px] font-black text-stone-400 uppercase tracking-wider">BIAYA POKOK (HPP)</span>
                  <div className="text-xl font-extrabold text-stone-800 mt-1">{formatRupiah(reportTx.reduce((sum, t) => sum + t.totalModal, 0))}</div>
                  <p className="text-[9px] font-bold text-stone-400 mt-1 uppercase">Modal Menu Terjual</p>
                </div>
                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 leading-tight">
                  <span className="text-[10px] font-black text-stone-400 uppercase tracking-wider">OPERASIONAL LOGISTIK</span>
                  <div className="text-xl font-extrabold text-stone-800 mt-1">
                    {formatRupiah(
                      expenses.filter(e => {
                        if (selectedPeriod === "all") return true;
                        const lim = new Date();
                        lim.setHours(0, 0, 0, 0);
                        if (selectedPeriod === "7d") lim.setDate(lim.getDate() - 6);
                        else if (selectedPeriod === "30d") lim.setDate(lim.getDate() - 29);
                        return new Date(e.timestamp) >= lim;
                      }).reduce((sum, e) => sum + e.amount, 0)
                    )}
                  </div>
                  <p className="text-[9px] font-bold text-stone-400 mt-1 uppercase">Total Biaya & Belanja</p>
                </div>
                <div className="p-4 rounded-3xl bg-emerald-50 border border-emerald-100 leading-tight">
                  <span className="text-[10px] font-black text-emerald-700 uppercase tracking-wider">LABA BERSIH (SAKU)</span>
                  <div className="text-xl font-black text-emerald-900 mt-1">
                    {(() => {
                      const omz = reportTx.reduce((sum, t) => sum + t.totalAmount, 0);
                      const hpp = reportTx.reduce((sum, t) => sum + t.totalModal, 0);
                      const exps = expenses.filter(e => {
                        if (selectedPeriod === "all") return true;
                        const lim = new Date();
                        lim.setHours(0, 0, 0, 0);
                        if (selectedPeriod === "7d") lim.setDate(lim.getDate() - 6);
                        else if (selectedPeriod === "30d") lim.setDate(lim.getDate() - 29);
                        return new Date(e.timestamp) >= lim;
                      }).reduce((sum, e) => sum + e.amount, 0);
                      return formatRupiah((omz - hpp) - exps);
                    })()}
                  </div>
                  <p className="text-[9px] font-bold text-emerald-600 mt-1 uppercase">
                    Net Margin: {(() => {
                      const omz = reportTx.reduce((sum, t) => sum + t.totalAmount, 0);
                      const hpp = reportTx.reduce((sum, t) => sum + t.totalModal, 0);
                      const exps = expenses.filter(e => {
                        if (selectedPeriod === "all") return true;
                        const lim = new Date();
                        lim.setHours(0, 0, 0, 0);
                        if (selectedPeriod === "7d") lim.setDate(lim.getDate() - 6);
                        else if (selectedPeriod === "30d") lim.setDate(lim.getDate() - 29);
                        return new Date(e.timestamp) >= lim;
                      }).reduce((sum, e) => sum + e.amount, 0);
                      const pro = (omz - hpp) - exps;
                      return omz > 0 ? Math.round((pro / omz) * 100) : 0;
                    })()}%
                  </p>
                </div>
              </div>

              {/* Menu Performance Rankings Table */}
              <div className="space-y-3">
                <h3 className="font-heading font-extrabold text-stone-800 text-xs border-b border-stone-200 pb-1 uppercase tracking-wider">I. Menu Terlaris & Kontribusi Omzet</h3>
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="bg-stone-50 border-b border-stone-200 text-stone-500 font-extrabold">
                      <th className="py-2.5 px-3 w-12">No</th>
                      <th className="py-2.5 px-3">Nama Menu Masakan</th>
                      <th className="py-2.5 px-3 text-center">Kuantitas Terjual</th>
                      <th className="py-2.5 px-3 text-right">Kontribusi Omzet</th>
                    </tr>
                  </thead>
                  <tbody>
                    {topProductRankings.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-6 text-center text-stone-400 uppercase font-bold tracking-wider">Tidak ada pesanan menu terekam</td>
                      </tr>
                    ) : (
                      topProductRankings.map((p, index) => (
                        <tr key={index} className="border-b border-stone-100 font-semibold text-stone-700">
                          <td className="py-2 px-3 text-stone-500">{index + 1}</td>
                          <td className="py-2 px-3 font-black text-stone-800">{p.product.name}</td>
                          <td className="py-2 px-3 text-center">{p.qty} {p.product.unit || "item"}</td>
                          <td className="py-2 px-3 text-right font-mono text-stone-900">{formatRupiah(p.revenue)}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>

              {/* Transactions Ledger list */}
              <div className="space-y-3 page-break">
                <h3 className="font-heading font-extrabold text-stone-800 text-xs border-b border-stone-200 pb-1 uppercase tracking-wider pt-4">II. Jurnal Buku Kas Transaksi</h3>
                <table className="w-full text-[11px] text-left">
                  <thead>
                    <tr className="bg-stone-50 border-b border-stone-200 text-stone-500 font-extrabold">
                      <th className="py-2.5 px-3">Nota ID</th>
                      <th className="py-2.5 px-3">Tanggal Waktu</th>
                      <th className="py-2.5 px-3">Rincian Belanja Menu</th>
                      <th className="py-2.5 px-3 text-right">Omzet</th>
                      <th className="py-2.5 px-3 text-right">Modal</th>
                      <th className="py-2.5 px-3 text-right text-emerald-800">Laba Bersih</th>
                    </tr>
                  </thead>
                  <tbody>
                    {reportTx.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-6 text-center text-stone-400 uppercase font-bold tracking-wider">Belum ada transaksi terekam</td>
                      </tr>
                    ) : (
                      reportTx.map((tx) => {
                        const itemsDescription = tx.items.map((it: any) => `${it.qty}x ${it.name}`).join(", ");
                        return (
                          <tr key={tx.id} className="border-b border-stone-100 font-medium text-stone-600">
                            <td className="py-2 px-3 font-mono font-bold text-stone-900">{tx.id}</td>
                            <td className="py-2 px-3 text-stone-400">{new Date(tx.timestamp).toLocaleString("id-ID", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</td>
                            <td className="py-2 px-3 font-semibold text-stone-800 truncate max-w-[240px]" title={itemsDescription}>{itemsDescription}</td>
                            <td className="py-2 px-3 text-right font-mono text-stone-900">{formatRupiah(tx.totalAmount)}</td>
                            <td className="py-2 px-3 text-right font-mono text-stone-400">{formatRupiah(tx.totalModal)}</td>
                            <td className="py-2 px-3 text-right font-mono font-bold text-emerald-700">{formatRupiah(tx.profit)}</td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>

              {/* Operational Expenses section */}
              {(() => {
                const lim = new Date();
                lim.setHours(0, 0, 0, 0);
                if (selectedPeriod === "7d") lim.setDate(lim.getDate() - 6);
                else if (selectedPeriod === "30d") lim.setDate(lim.getDate() - 29);
                const filteredEx = expenses.filter(e => {
                  if (selectedPeriod === "all") return true;
                  return new Date(e.timestamp) >= lim;
                }).sort((a,b) => b.timestamp.localeCompare(a.timestamp));
                
                if (filteredEx.length === 0) return null;

                return (
                  <div className="space-y-3">
                    <h3 className="font-heading font-extrabold text-stone-800 text-xs border-b border-stone-200 pb-1 uppercase tracking-wider pt-4">III. Pengeluaran Logistik & Operasional</h3>
                    <table className="w-full text-xs text-left">
                      <thead>
                        <tr className="bg-stone-50 border-b border-stone-200 text-stone-500 font-extrabold">
                          <th className="py-2.5 px-3">Tanggal</th>
                          <th className="py-2.5 px-3">Deskripsi / Catatan</th>
                          <th className="py-2.5 px-3">Kategori</th>
                          <th className="py-2.5 px-3 text-right">Nilai Pengeluaran</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredEx.map((ex) => (
                          <tr key={ex.id} className="border-b border-stone-100 font-semibold text-stone-700">
                            <td className="py-2 px-3 text-stone-400">
                              {new Date(ex.timestamp).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })}
                            </td>
                            <td className="py-2 px-3 font-black text-stone-800">{ex.description}</td>
                            <td className="py-2 px-3 text-stone-500 uppercase text-[10px] tracking-wider font-bold">{ex.category || "Operasional"}</td>
                            <td className="py-2 px-3 text-right font-mono text-rose-700">{formatRupiah(ex.amount)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                );
              })()}

              {/* Signatures & Certification Area */}
              <div className="pt-12 flex justify-between items-start text-xs font-semibold leading-relaxed text-stone-500">
                <div className="space-y-1">
                  <p className="font-bold text-emerald-800">KASIR AI COPILOT</p>
                  <p>Laporan draf tersertifikasi otomatis oleh AI</p>
                  <p className="text-[10px] text-stone-400 pt-1">ID: {storeProfile?.name?.replace(/\s+/g, "").toUpperCase()}-{selectedPeriod.toUpperCase()}</p>
                </div>
                <div className="text-right w-48 space-y-12">
                  <p className="font-bold">Pemilik Usaha,</p>
                  <div>
                    <p className="font-extrabold text-stone-900 underline">{storeProfile?.owner?.name || "Budi Santoso"}</p>
                    <p className="text-[10px] text-stone-400 font-bold">Kasir Pintar UMKM</p>
                  </div>
                </div>
              </div>

            </div>

            {/* Modal Actions Footer */}
            <div className="px-6 py-4 bg-stone-50 border-t border-stone-200 flex justify-end gap-3 shrink-0 no-print">
              <button
                onClick={() => setReportPreviewOpen(false)}
                className="px-4 py-2 hover:bg-stone-100 font-bold text-stone-500 hover:text-stone-700 text-xs rounded-xl duration-150 cursor-pointer"
              >
                Batal/Tutup
              </button>
              <button
                onClick={handleCopyReportText}
                className="flex items-center gap-1.5 px-4 py-2 border border-teal-200 bg-teal-50 hover:bg-teal-100/80 text-teal-800 font-extrabold text-xs rounded-xl duration-150 transition active:scale-95 cursor-pointer shadow-sm"
              >
                <Copy className="w-3.5 h-3.5 text-teal-600" />
                Salin Teks Laporan (Cadangan)
              </button>
              <button
                onClick={handlePrintPDF}
                className="flex items-center gap-1.5 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-md transition active:scale-95 duration-100 cursor-pointer"
              >
                <Printer className="w-4 h-4 text-emerald-100" />
                Cetak Laporan / Simpan PDF
              </button>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}

function Trash2Custom(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="3 6 5 6 21 6" />
      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    </svg>
  );
}
