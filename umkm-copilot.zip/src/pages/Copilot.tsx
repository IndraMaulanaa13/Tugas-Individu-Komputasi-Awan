import React, { useState, useRef, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { formatTimeOnly } from "../utils/date";
import ConfirmModal from "../components/ConfirmModal";
import {
  Send,
  Plus,
  Sparkles,
  Paperclip,
  Trash2,
  ChevronLeft,
  ChevronRight,
  MessageSquare,
  BadgeAlert,
  Loader2,
  HelpCircle,
  TrendingUp,
  Tag,
  Package,
  Megaphone,
  Lightbulb
} from "lucide-react";

export default function Copilot() {
  const {
    chatSessions,
    activeChatId,
    createNewChat,
    selectChat,
    deleteChat,
    sendMessageToCopilot,
    chatSendLoading,
    storeProfile,
    getPeriodMetrics,
    addToast
  } = useApp();

  const [inputMessage, setInputMessage] = useState("");
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [chatToDeleteId, setChatToDeleteId] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<"cfo" | "harga" | "stok" | "promo">("cfo");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Drag to scroll logic for horizontal prompt chips
  const chipsScrollRef = useRef<HTMLDivElement | null>(null);
  const [dragState, setDragState] = useState({
    isDragging: false,
    startX: 0,
    scrollLeft: 0,
    hasMoved: false
  });

  const onChipsMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!chipsScrollRef.current) return;
    setDragState({
      isDragging: true,
      startX: e.pageX - chipsScrollRef.current.offsetLeft,
      scrollLeft: chipsScrollRef.current.scrollLeft,
      hasMoved: false
    });
  };

  const onChipsMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!dragState.isDragging || !chipsScrollRef.current) return;
    const x = e.pageX - chipsScrollRef.current.offsetLeft;
    const walk = (x - dragState.startX) * 1.5; // multiplier for scrolling speed
    if (Math.abs(walk) > 4) {
      setDragState(prev => ({ ...prev, hasMoved: true }));
    }
    chipsScrollRef.current.scrollLeft = dragState.scrollLeft - walk;
  };

  const onChipsMouseUpOrLeave = () => {
    setDragState(prev => ({ ...prev, isDragging: false }));
  };

  const handleChipClickWithDragCheck = (promptText: string, e: React.MouseEvent<HTMLButtonElement>) => {
    if (dragState.hasMoved) {
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    handleChipClick(promptText);
  };

  const shortcutCategories = [
    { id: "cfo", name: "Keuangan & Omzet", icon: TrendingUp, colorClass: "text-emerald-700", borderColorClass: "border-emerald-200/60", bgColorClass: "bg-emerald-50/70" },
    { id: "harga", name: "Strategi Harga", icon: Tag, colorClass: "text-sky-700", borderColorClass: "border-sky-200/60", bgColorClass: "bg-sky-50/70" },
    { id: "stok", name: "Stok & Logistik", icon: Package, colorClass: "text-amber-700", borderColorClass: "border-amber-200/60", bgColorClass: "bg-amber-50/70" },
    { id: "promo", name: "Tips Promosi", icon: Megaphone, colorClass: "text-purple-700", borderColorClass: "border-purple-200/60", bgColorClass: "bg-purple-50/70" },
  ] as const;

  const shortcutsByCategory = {
    cfo: [
      "Berapa margin keuntungan bersih usaha saya sejauh ini?",
      "Tolong analisis trend omzet kotor harian saya!",
      "Bagaimana rincian pengeluaran terbesar usaha saat ini?",
      "Bikin simpulan laba kotor vs pengeluaran bulan ini",
      "Kapan hari paling sepi penjualan dan solusinya?"
    ],
    harga: [
      "Bagaimana cara menaikkan harga jual teraman tanpa kehilangan pembeli?",
      "Rekomendasi harga jual ideal agar untung minimal 50%",
      "Ide paket menu bundling hemat untuk meningkatkan penjualan!",
      "Tips menghadapi kompetitor yang membanting harga dagangan",
      "Bagaimana cara menghitung modal porsi makanan yang pas?"
    ],
    stok: [
      "Bagaimana mengontrol stok bahan baku agar tidak gampang rusak?",
      "Tips kurangi kerugian makanan sisa (waste management warung)",
      "Berapa batas toleransi kerugian bahan baku yang wajar?",
      "Tips gampang mencatat keluar masuk barang harian",
      "Metode FIFO sederhana untuk rotasi bahan memasak"
    ],
    promo: [
      "Rancang satu strategi promosi diskon kreatif akhir pekan",
      "Tulis pesan siaran WhatsApp menarik untuk pelanggan setia",
      "Bagaimana cara menarik minat pelanggan di jam sepi siang?",
      "Trik branding warung agar makin dikenal warga sekitar",
      "Metode kartu loyalitas sederhana untuk pembeli langganan"
    ]
  } as const;

  // Auto scroll to message bottom on loading or responses
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatSessions, chatSendLoading, activeChatId]);

  const activeSession = chatSessions.find((s) => s.id === activeChatId);

  const popularChips = [
    "Berapa margin keuntungan bersih usaha saya sejauh ini?",
    "Bagaimana cara menaikkan harga jual tanpa kehilangan pembeli?",
    "Tips kurangi kerugian makanan sisa (waste management warung)",
    "Rancang satu strategi promosi diskon kreatif akhir pekan",
    "Bikin simpulan laba kotor vs pengeluaran bulan ini",
    "Bagaimana mengontrol stok bahan baku agar tidak gampang rusak?"
  ];

  const handleSend = async () => {
    if (!inputMessage.trim() || chatSendLoading) return;
    const msg = inputMessage;
    setInputMessage("");
    
    // If no chat session yet, create one
    let targetChatId = activeChatId;
    if (!targetChatId) {
      targetChatId = createNewChat();
    }
    
    await sendMessageToCopilot(msg);
  };

  const handleChipClick = async (chipText: string) => {
    let targetChatId = activeChatId;
    if (!targetChatId) {
      targetChatId = createNewChat();
    }
    
    // Inject user msg
    setInputMessage("");
    await sendMessageToCopilot(chipText);
  };

  const handleCreateNewChatClick = () => {
    createNewChat();
    setShowMobileSidebar(false);
  };

  // CUSTOM REUSABLE MARKDOWN CONVERTER INTERNAL HELPER
  const renderMessageContent = (text: string) => {
    const lines = text.split("\n");
    let isInsideTable = false;
    let tableHeaders: string[] = [];
    let tableRows: string[][] = [];

    return lines.map((line, lineIdx) => {
      // 1. Parse Tables
      if (line.trim().startsWith("|") && line.trim().endsWith("|")) {
        const columns = line.split("|").map(c => c.trim()).filter(c => c !== "");
        // Check if separation border row
        if (columns.every(col => col.startsWith("-") || col.includes("---"))) {
          return null; // skip dividing row
        }
        
        if (!isInsideTable) {
          isInsideTable = true;
          tableHeaders = columns;
          return null;
        } else {
          tableRows.push(columns);
          
          // If this is the last line or next line is not a table row, draw table
          const nextLine = lines[lineIdx + 1];
          const isNextTableLine = nextLine && nextLine.trim().startsWith("|") && nextLine.trim().endsWith("|");
          
          if (!isNextTableLine) {
            isInsideTable = false;
            const headersCopy = [...tableHeaders];
            const rowsCopy = [...tableRows];
            tableHeaders = [];
            tableRows = [];
            return (
              <div key={`tbl-${lineIdx}`} className="overflow-x-auto my-3 border border-stone-200/60 rounded-xl bg-stone-50 p-1 font-sans text-xs">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-stone-200 text-[10px] uppercase text-stone-400 font-extrabold text-left bg-stone-100">
                      {headersCopy.map((header, hIdx) => (
                        <th key={hIdx} className="py-2.5 px-3">{header}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {rowsCopy.map((rowArr, rIdx) => (
                      <tr key={rIdx} className="hover:bg-white duration-100 font-medium">
                        {rowArr.map((cellText, cellIdx) => (
                          <td key={cellIdx} className="py-2 px-3 text-stone-700">{parseBolding(cellText)}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );
          }
          return null;
        }
      }

      if (isInsideTable) {
        return null; // swallowed into table structure
      }

      // 2. Parse Lists
      if (line.trim().startsWith("- ") || line.trim().startsWith("* ")) {
        const cleanContent = line.trim().substring(2);
        return (
          <ul key={lineIdx} className="list-disc pl-5 my-1.5 font-bold font-body space-y-1 text-stone-700 font-semibold">
            <li>{parseBolding(cleanContent)}</li>
          </ul>
        );
      }

      // 3. Headers
      if (line.trim().startsWith("### ")) {
        return (
          <h5 key={lineIdx} className="font-heading font-extrabold text-stone-900 text-xs tracking-tight mt-4 mb-2">
            {parseBolding(line.trim().substring(4))}
          </h5>
        );
      }
      if (line.trim().startsWith("## ")) {
        return (
          <h4 key={lineIdx} className="font-heading font-extrabold text-stone-900 text-sm tracking-tight mt-5 mb-2.5">
            {parseBolding(line.trim().substring(3))}
          </h4>
        );
      }

      // 4. Default paragraphs
      if (line.trim() === "") {
        return <div key={lineIdx} className="h-2" />;
      }

      return (
        <p key={lineIdx} className="my-1 text-stone-700 leading-relaxed font-semibold text-xs">
          {parseBolding(line)}
        </p>
      );
    });
  };

  // Convert **strong** into React elements
  const parseBolding = (inputText: string): React.ReactNode[] => {
    const parts = inputText.split(/\*\*([\s\S]*?)\*\*/g);
    return parts.map((part, index) => {
      // odd indices represent matched bold groups
      if (index % 2 === 1) {
        return <b key={index} className="font-extrabold text-stone-900 font-heading bg-emerald-100/50 px-1 py-0.2 rounded-md">{part}</b>;
      }
      return <React.Fragment key={index}>{part}</React.Fragment>;
    });
  };

  return (
    <div className="flex h-[calc(100vh-140px)] md:h-[calc(100vh-120px)] border border-stone-200/60 rounded-3xl bg-white overflow-hidden shadow-sm shadow-stone-200/30">
      {/* SIDEBAR LIST IN PANEL (280px width) - Responsive toggle hidden */}
      <aside className={`hidden md:flex flex-col w-68 h-full bg-stone-50/50 border-r border-stone-200 shrink-0 select-none`}>
        {/* Thread headers */}
        <div className="p-4 border-b border-stone-200 space-y-3 shrink-0">
          <div className="flex justify-between items-center">
            <span className="font-heading font-black text-stone-800 text-xs">Riwayat Diskusi</span>
            <span className="text-[10px] font-bold text-stone-400 bg-stone-100 px-2 py-0.5 rounded-full">
              {chatSessions.length}
            </span>
          </div>
          <button
            onClick={createNewChat}
            className="flex items-center justify-center gap-1.5 w-full h-9 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-md cursor-pointer duration-150-out"
          >
            <Plus className="w-4 h-4" />
            Mulai Diskusi Baru
          </button>
        </div>

        {/* Sessions list */}
        <div className="flex-1 overflow-y-auto p-2.5 space-y-1.5">
          {chatSessions.length === 0 ? (
            <div className="text-center py-16 text-stone-400 text-[11px] font-semibold block uppercase">
              Riwayat Kosong.
            </div>
          ) : (
            chatSessions.map((session) => {
              const active = session.id === activeChatId;
              const lastMsg = session.messages[session.messages.length - 1];

              return (
                <div
                  key={session.id}
                  onClick={() => selectChat(session.id)}
                  className={`group relative p-3 rounded-2xl border transition duration-150 cursor-pointer ${
                    active
                      ? "bg-emerald-50/45 border-emerald-200 text-stone-800"
                      : "bg-transparent border-transparent hover:bg-stone-50 text-stone-600"
                  }`}
                >
                  <div className="flex justify-between items-start gap-2 pr-4">
                    <span className="font-heading font-extrabold text-xs leading-none font-semibold truncate max-w-[150px]">
                      {session.title}
                    </span>
                    <span className="text-[9px] text-stone-400 font-extrabold shrink-0 mt-0.5">
                      {session.date}
                    </span>
                  </div>
                  
                  {/* previews last text */}
                  <p className="text-[10px] text-stone-400 truncate mt-1.5 font-sans leading-none">
                    {lastMsg?.text || "Buka percakapan..."}
                  </p>

                  {/* trash hover deletes */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setChatToDeleteId(session.id);
                      setConfirmOpen(true);
                    }}
                    className="absolute right-2.5 bottom-2.5 text-stone-400 hover:text-red-500 opacity-0 group-hover:opacity-100 duration-150 p-1 rounded hover:bg-white cursor-pointer"
                    title="Hapus Diskusi"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })
          )}
        </div>
      </aside>

      {/* CHAT SESSION BODY AREA PANEL */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative bg-stone-50/20">
        
        {/* Sub Header bar */}
        <div className="h-14 border-b border-stone-200 bg-white flex items-center justify-between px-6 shrink-0 z-10 shadow-sm leading-none">
          <div className="flex items-center gap-2.5">
            {/* Logo avatar */}
            <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white font-extrabold text-base flex items-center justify-center shadow-md select-none shrink-0 border border-emerald-500">
              C
            </div>
            <div className="flex flex-col">
              <span className="font-heading font-black text-stone-800 text-xs">Copilot virtual CFO</span>
              <span className="text-[10px] text-emerald-600 font-bold mt-1 tracking-wide flex items-center gap-1">
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                Aktif & Siap Menganalisis
              </span>
            </div>
          </div>

          <span className="text-[9px] text-stone-400/80 font-bold uppercase tracking-wider hidden sm:block select-none">
            Powered by Gemini 3.5 Flash 🤖
          </span>
        </div>

        {/* CHAT BUBBLES LISTS (Scrollable content) */}
        <div className="flex-1 overflow-y-auto px-4 md:px-6 py-6 space-y-6">
          <div className="max-w-[720px] mx-auto space-y-6">
            
            {/* If no active chat session, show empty state suggestion dashboard */}
            {!activeSession || activeSession.messages.length === 0 ? (
              <div className="space-y-8 py-4 animate-slide-up">
                <div className="flex flex-col items-center justify-center text-center space-y-3">
                  <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center shadow-md shadow-emerald-500/10">
                    <Sparkles className="w-9 h-9 animate-bounce" />
                  </div>
                  <div>
                    <h3 className="font-heading font-black text-stone-800 text-base md:text-lg">
                      Halo! Saya Copilot, asisten keuangan pribadi Anda! 👋
                    </h3>
                    <p className="text-stone-400 text-xs font-semibold leading-relaxed max-w-sm mx-auto mt-1">
                      Ketikkan pertanyaan apa saja seputar target omzet, pasokan persediaan stok barang, atau saran kenaikan harga optimal.
                    </p>
                  </div>
                </div>

                {/* Popular chips buttons grid layout */}
                <div className="space-y-3">
                  <span className="text-[10px] text-stone-400 tracking-wider uppercase font-black block text-center select-none">Topik Tanya Populer</span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-lg mx-auto p-1 text-left">
                    {popularChips.map((chip, index) => (
                      <button
                        key={index}
                        onClick={() => handleChipClick(chip)}
                        className="bg-white hover:bg-emerald-50 border border-stone-200 hover:border-emerald-300 text-stone-700 p-3 rounded-2xl text-xs font-bold transition duration-150 text-left outline-none cursor-pointer hover:shadow-md"
                      >
                        {chip}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              /* Actual ongoing conversation bubbles rendering */
              activeSession.messages.map((msg) => {
                const isUser = msg.role === "user";

                return (
                  <div
                    key={msg.id}
                    className={`flex gap-3 max-w-[85%] ${isUser ? "ml-auto flex-row-reverse" : "mr-auto"}`}
                  >
                    {/* Model custom visual icon indicator */}
                    {!isUser && (
                      <div className="w-8 h-8 rounded-full bg-emerald-600 text-white font-black text-xs shrink-0 flex items-center justify-center shadow-md shadow-emerald-700/20">
                        C
                      </div>
                    )}

                    <div className="space-y-1">
                      {/* Bubble canvas */}
                      <div
                        className={`px-4 py-3 border text-xs leading-relaxed ${
                          isUser
                            ? "bg-emerald-600 border-emerald-500 text-white rounded-2xl md:rounded-3xl rounded-tr-sm"
                            : "bg-white border-stone-200 text-stone-800 rounded-2xl md:rounded-3xl rounded-tl-sm shadow-sm p-4"
                        }`}
                      >
                        {isUser ? (
                          <p className="font-extrabold font-body text-xs">{msg.text}</p>
                        ) : (
                          <div className="space-y-2">
                            {renderMessageContent(msg.text)}
                          </div>
                        )}
                      </div>
                      
                      {/* Time text label stamp */}
                      <span className={`text-[9px] text-stone-400 font-bold block ${isUser ? "text-right" : "text-left"}`}>
                        {formatTimeOnly(msg.timestamp)}
                      </span>
                    </div>
                  </div>
                );
              })
            )}

            {/* Bouncing thinking dots indicator */}
            {chatSendLoading && (
              <div className="flex gap-3 max-w-[85%] mr-auto items-center animate-pulse">
                <div className="w-8 h-8 rounded-full bg-emerald-600 text-white font-black text-xs shrink-0 flex items-center justify-center">
                  C
                </div>
                <div className="bg-stone-100 border border-stone-200 rounded-2xl px-4 py-3 flex gap-1.5 items-center bg-white shadow-sm">
                  <Loader2 className="w-4 h-4 text-emerald-600 animate-spin" />
                  <span className="text-xxs font-black tracking-wider uppercase text-emerald-700">Copilot berpikir...</span>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* INPUT KEYBOARD CONTROLLER BAR PANEL */}
        <div className="sticky bottom-0 right-0 left-0 bg-white border-t border-stone-200 px-4 md:px-6 py-4 shrink-0 z-10 shadow-lg">
          <div className="max-w-[720px] mx-auto space-y-3">
            
            {/* Prompt Shortcuts / Tombol Dialog Pintar AI Persistent Widget (Visible when conversation is active) */}
            {activeSession && activeSession.messages.length > 0 && (
              <div className="bg-stone-50 border border-stone-200/75 rounded-2xl p-3 space-y-2.5 shadow-xs select-none">
                {/* Header title & category tabs */}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pb-1.5 border-b border-stone-200/50">
                  <div className="flex items-center gap-1.5 shrink-0">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
                    <span className="text-[10px] font-black uppercase tracking-wider text-stone-500">Tombol Dialog Pintar AI</span>
                  </div>
                  
                  {/* Category Pill Buttons */}
                  <div className="flex flex-wrap gap-1">
                    {shortcutCategories.map((cat) => {
                      const CatIcon = cat.icon;
                      const isSelected = activeCategory === cat.id;
                      return (
                        <button
                          key={cat.id}
                          onClick={() => setActiveCategory(cat.id)}
                          className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[9px] font-extrabold uppercase tracking-wide transition border cursor-pointer ${
                            isSelected
                              ? `${cat.bgColorClass} ${cat.colorClass} ${cat.borderColorClass} font-black shadow-xs`
                              : "bg-white text-stone-600 border-stone-200 hover:bg-stone-100"
                          }`}
                        >
                          <CatIcon className="w-3 h-3" />
                          {cat.name}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Horizontal scrolling chips list */}
                <div 
                  ref={chipsScrollRef}
                  onMouseDown={onChipsMouseDown}
                  onMouseMove={onChipsMouseMove}
                  onMouseUp={onChipsMouseUpOrLeave}
                  onMouseLeave={onChipsMouseUpOrLeave}
                  className={`flex gap-2 overflow-x-auto pb-2 pt-1.5 whitespace-nowrap custom-scrollbar ${
                    dragState.isDragging ? "cursor-grabbing" : "cursor-grab"
                  }`}
                >
                  {shortcutsByCategory[activeCategory].map((promptText, idx) => (
                    <button
                      key={idx}
                      onClick={(e) => handleChipClickWithDragCheck(promptText, e)}
                      className="bg-white hover:bg-emerald-50 border border-stone-200 hover:border-emerald-300 text-stone-700 py-1.5 px-3 rounded-xl text-[10px] font-extrabold duration-150 shrink-0 select-none cursor-pointer hover:shadow-sm"
                    >
                      {promptText}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="flex gap-3 items-end">
              {/* Input keyboard textarea box */}
              <div className="flex-1 relative bg-stone-50 border border-stone-200 rounded-2xl px-4 py-2.5 flex gap-2 hover:border-stone-300 focus-within:border-emerald-500 duration-150">
                <textarea
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                  rows={1}
                  placeholder="Tanyakan ke Copilot (contoh: 'Kenapa omzet melorot hari Rabu?')"
                  className="flex-1 bg-transparent border-0 outline-none resize-none text-xs font-bold text-stone-800 placeholder-stone-400 max-h-24 h-6 py-0.5 leading-relaxed font-body"
                />
                <button
                  className="text-stone-400 hover:text-stone-700 duration-150 p-0.5 shrink-0"
                  title="Sematkan Dokumen Penjualan"
                  onClick={() => addToast("Fitur lampir files disimulasikan.", "info")}
                >
                  <Paperclip className="w-4.5 h-4.5" />
                </button>
              </div>

              {/* Send circle trigger */}
              <button
                onClick={handleSend}
                disabled={!inputMessage.trim() || chatSendLoading}
                className="w-10 h-10 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white rounded-full flex items-center justify-center shadow-md transform active:scale-95 duration-100 cursor-pointer shrink-0"
              >
                <Send className="w-4.5 h-4.5 text-white" />
              </button>
            </div>
          </div>
        </div>

      </div>

      {/* CUSTOM CONFIRMATION DIALOG MODAL */}
      <ConfirmModal
        isOpen={confirmOpen}
        onClose={() => {
          setConfirmOpen(false);
          setChatToDeleteId(null);
        }}
        onConfirm={() => {
          if (chatToDeleteId) {
            deleteChat(chatToDeleteId);
            addToast("Ruang obrolan berhasil dihapus!", "success");
          }
        }}
        title="Hapus Diskusi Copilot?"
        message="Seluruh analisis operasional dan saran strategis dalam ruang obrolan ini akan dihapus secara permanen."
        confirmText="Ya, Hapus"
        cancelText="Batal"
        variant="danger"
      />
    </div>
  );
}
