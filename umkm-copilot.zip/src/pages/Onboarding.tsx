import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { StoreProfile, Product } from "../types";
import { formatRupiah } from "../utils/currency";
import confetti from "canvas-confetti";
import { auth } from "../firebase";
import { signOut } from "firebase/auth";
import { 
  Building2, 
  MapPin, 
  Calendar, 
  Plus, 
  Trash2, 
  Sparkles, 
  Target, 
  Clock, 
  ChevronRight, 
  ChevronLeft,
  LogOut,
  User
} from "lucide-react";

export default function Onboarding() {
  const { completeOnboarding } = useApp();
  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [submitError, setSubmitError] = useState("");
  const [useDummy, setUseDummy] = useState(true);

  // --- Step 1 States ---
  const [storeName, setStoreName] = useState("");
  const [ownerName, setOwnerName] = useState("Budi Santoso");
  const [storeType, setStoreType] = useState("Kuliner");
  const [storeCity, setStoreCity] = useState("");
  const [storeSince, setStoreSince] = useState(2025);

  const [errorMsg, setErrorMsg] = useState("");

  // --- Step 2 States ---
  const [initialProducts, setInitialProducts] = useState<any[]>([
    { name: "Bakso Sapi Spesial", price: 16000, modal: 9000, stock: 40, unit: "porsi" },
    { name: "Es Teh Manis", price: 5000, modal: 2000, stock: 100, unit: "gelas" },
    { name: "Kerupuk Kaleng", price: 2000, modal: 1000, stock: 50, unit: "pcs" },
  ]);

  // --- Step 3 States ---
  const [monthlyTarget, setMonthlyTarget] = useState(15000000);
  const [activeDays, setActiveDays] = useState<{ [key: string]: boolean }>({
    "Sen": true, "Sel": true, "Rab": true, "Kam": true, "Jum": true, "Sab": true, "Min": true
  });
  const [openTime, setOpenTime] = useState("09:00");
  const [closeTime, setCloseTime] = useState("21:00");

  const businessTypes = [
    "Kuliner",
    "Fashion & Pakaian",
    "Elektronik",
    "Pertanian",
    "Jasa & Service",
    "Kecantikan",
    "Bengkel",
    "Toko Kelontong",
    "Lainnya"
  ];

  const indonesianDaysFull = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"];
  const indonesianDaysShort = ["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"];

  const yearsList = Array.from({ length: 36 }, (_, i) => 1990 + i).reverse();

  // --- handlers ---
  const addProductRow = () => {
    if (initialProducts.length >= 15) return;
    setInitialProducts([
      ...initialProducts,
      { name: "", price: 0, modal: 0, stock: 10, unit: "pcs" }
    ]);
  };

  const removeProductRow = (index: number) => {
    setInitialProducts(initialProducts.filter((_, idx) => idx !== index));
  };

  const updateProductItem = (index: number, field: string, val: any) => {
    const updated = initialProducts.map((p, idx) => {
      if (idx === index) {
        return { ...p, [field]: val };
      }
      return p;
    });
    setInitialProducts(updated);
  };

  const toggleDay = (day: string) => {
    setActiveDays({ ...activeDays, [day]: !activeDays[day] });
  };

  const handleNextStep = () => {
    setErrorMsg("");
    if (currentStep === 1) {
      if (!storeName.trim()) {
        setErrorMsg("Nama toko wajib diisi!");
        return;
      }
      if (!ownerName.trim()) {
        setErrorMsg("Nama pemilik/user wajib diisi!");
        return;
      }
      if (!storeCity.trim()) {
        setErrorMsg("Kota wajib diisi!");
        return;
      }
    }
    if (currentStep === 2) {
      const invalidProduct = initialProducts.some(p => !p.name.trim() || p.price <= 0 || p.modal <= 0);
      if (invalidProduct) {
        setErrorMsg("Pastikan seluruh nama produk, harga jual, dan modal diisi dengan benar.");
        return;
      }
    }
    setCurrentStep(currentStep + 1);
  };

  const handlePrevStep = () => {
    setCurrentStep(currentStep - 1);
  };

  const handleFinish = async () => {
    setLoading(true);
    setSubmitError("");
    
    // Generate avatar initials from dynamic owner name
    const ownerNameTrimmed = ownerName.trim();
    const initials = ownerNameTrimmed
      ? ownerNameTrimmed.split(" ").slice(0, 2).map((w) => w[0]).join("").toUpperCase()
      : "US";

    const profile: StoreProfile = {
      id: "store-custom",
      name: storeName,
      type: storeType,
      location: storeCity,
      since: storeSince,
      owner: { name: ownerNameTrimmed || "User", avatar: initials },
      target: { monthly: monthlyTarget },
      hours: { open: openTime, close: closeTime, activeDays }
    };

    try {
      await completeOnboarding(profile, initialProducts, useDummy);
      // Celebratory Confetti explosions!
      confetti({
        particleCount: 150,
        spread: 80,
        origin: { y: 0.6 }
      });
    } catch (e: any) {
      setSubmitError(e.message || "Gagal menghubungi database Copilot.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen grid grid-cols-1 lg:grid-cols-12 bg-stone-50 font-sans text-stone-700 antialiased overflow-x-hidden md:overflow-y-auto">
      {/* LEFT FORM FIELD CONTAINER (55%) */}
      <div className="lg:col-span-7 flex flex-col justify-center px-6 sm:px-12 py-10 max-w-2xl mx-auto w-full">
        {/* Top Header Ganti Akun */}
        <div className="flex items-center justify-between mb-8 pb-4 border-b border-stone-200/60 w-full">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-stone-800 tracking-tight text-xs uppercase bg-stone-100 text-stone-600 px-3 py-1 rounded-lg">UMKM Copilot Setup</span>
          </div>
          <button
            onClick={async () => {
              try {
                await signOut(auth);
              } catch (err) {
                console.error("Gagal keluar:", err);
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-extrabold text-stone-500 hover:text-rose-600 hover:bg-rose-50/70 rounded-xl transition-all duration-200 cursor-pointer border border-stone-200 shadow-sm"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Ganti Akun</span>
          </button>
        </div>

        {/* Stepper with progress bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-stone-400 mb-2">
            <span className="font-bold text-emerald-800">Progres Pengisian</span>
            <span className="text-emerald-700 font-extrabold">Langkah {currentStep} dari 3</span>
          </div>
          <div className="h-1.5 w-full bg-stone-200 rounded-full overflow-hidden">
            <div 
              className="h-full bg-emerald-500 rounded-full transition-all duration-300"
              style={{ width: `${(currentStep / 3) * 100}%` }}
            />
          </div>
          <div className="flex items-center gap-4 mt-4">
            <span className={`text-xs font-bold ${currentStep >= 1 ? "text-emerald-600 font-extrabold" : "text-stone-400"}`}>
              1. Info Toko {currentStep > 1 ? "✔" : ""}
            </span>
            <span className={`text-xs font-bold ${currentStep >= 2 ? "text-emerald-600 font-extrabold" : "text-stone-400"}`}>
              2. Produk Awal {currentStep > 2 ? "✔" : ""}
            </span>
            <span className={`text-xs font-bold ${currentStep >= 3 ? "text-emerald-600 font-extrabold" : "text-stone-400"}`}>
              3. Target Bisnis
            </span>
          </div>
        </div>

        {/* STEP 1: Info Toko */}
        {currentStep === 1 && (
          <div className="space-y-6">
            <div>
              <h2 className="font-heading font-extrabold text-2xl text-stone-900 tracking-tight leading-none mb-2">
                Ceritakan tentang usaha Anda
              </h2>
              <p className="text-stone-500 text-sm">
                Kami menyesuaikan analisis AI dengan kategori bisnis dan lokasi toko Anda.
              </p>
            </div>

            <div className="space-y-4">
              {errorMsg && (
                <div className="bg-rose-50 text-rose-600 text-sm font-bold p-3 rounded-xl border border-rose-100">
                  {errorMsg}
                </div>
              )}
              <div>
                <label className="block text-xs font-bold uppercase text-stone-500 mb-1.5">
                  Nama Toko / Warung <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Building2 className="absolute left-3.5 top-3.5 w-[18px] h-[18px] text-stone-400" />
                  <input
                    type="text"
                    value={storeName}
                    onChange={(e) => setStoreName(e.target.value)}
                    placeholder="contoh: Warung Bakso Pak Budi"
                    className="w-full h-11 pl-11 pr-4 rounded-xl border-1.5 border-stone-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition outline-none font-sans font-medium text-stone-800"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-stone-500 mb-1.5">
                  Nama Pemilik / User <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <User className="absolute left-3.5 top-3.5 w-[18px] h-[18px] text-stone-400" />
                  <input
                    type="text"
                    value={ownerName}
                    onChange={(e) => setOwnerName(e.target.value)}
                    placeholder="contoh: Budi Santoso"
                    className="w-full h-11 pl-11 pr-4 rounded-xl border-1.5 border-stone-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition outline-none font-sans font-medium text-stone-800"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-stone-500 mb-1.5">
                    Kategori Bisnis
                  </label>
                  <select
                    value={storeType}
                    onChange={(e) => setStoreType(e.target.value)}
                    className="w-full h-11 px-4 rounded-xl border-1.5 border-stone-200 focus:border-emerald-500 hover:border-stone-300 transition outline-none font-sans font-semibold text-stone-800"
                  >
                    {businessTypes.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-stone-500 mb-1.5">
                    Nama Kota Toko Berdiri <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <MapPin className="absolute left-3.5 top-3.5 w-[18px] h-[18px] text-stone-400" />
                    <input
                      type="text"
                      value={storeCity}
                      onChange={(e) => setStoreCity(e.target.value)}
                      placeholder="Surabaya"
                      className="w-full h-11 pl-11 pr-4 rounded-xl border-1.5 border-stone-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition outline-none font-sans"
                      required
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-stone-500 mb-1.5">
                  Tahun Mulai Beroperasi
                </label>
                <div className="relative">
                  <Calendar className="absolute left-3.5 top-3.5 w-[18px] h-[18px] text-stone-400" />
                  <select
                    value={storeSince}
                    onChange={(e) => setStoreSince(parseInt(e.target.value, 10))}
                    className="w-full h-11 pl-11 pr-4 rounded-xl border-1.5 border-stone-200 focus:border-emerald-500 hover:border-stone-300 transition outline-none font-sans font-semibold text-stone-800"
                  >
                    {yearsList.map((yr) => (
                      <option key={yr} value={yr}>
                        {yr}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <button
              onClick={handleNextStep}
              className="flex items-center justify-center gap-2 w-full h-[52px] bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white rounded-xl font-extrabold text-[15px] tracking-wide shadow-[0_8px_20px_-8px_rgba(16,185,129,0.5)] transform active:scale-[0.98] transition-all duration-200 cursor-pointer border border-emerald-400/20"
            >
              Lanjutkan ke Produk Awal
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        )}

        {/* STEP 2: Produk Awal */}
        {currentStep === 2 && (
          <div className="space-y-6">
            <div>
              <h2 className="font-heading font-extrabold text-2xl text-stone-900 tracking-tight leading-none mb-2">
                Tambahkan menu atau produk awal
              </h2>
              <p className="text-stone-500 text-sm">
                Tambahkan produk paling terlaris untuk simulasikan menu Anda. Tenang, produk bisa ditambah atau diubah kapan saja nanti! 😊
              </p>
            </div>

            <div className="overflow-x-auto border border-stone-200/60 rounded-2xl bg-white shadow-sm p-1.5">
              {errorMsg && (
                <div className="mb-4 bg-rose-50 text-rose-600 text-sm font-bold p-3 rounded-xl border border-rose-100 mx-2 mt-2">
                  {errorMsg}
                </div>
              )}
              <table className="w-full text-left border-collapse min-w-[500px]">
                <thead>
                  <tr className="border-b border-stone-100 text-[10px] font-bold text-stone-400 uppercase tracking-wider h-10 px-4">
                    <th className="py-2 pl-4 w-[280px]">Nama Produk</th>
                    <th className="py-2 px-2 w-[110px]">Modal</th>
                    <th className="py-2 px-2 w-[110px]">Harga Jual</th>
                    <th className="py-2 px-2 w-[80px]">Stok</th>
                    <th className="py-2 pr-4 text-center w-[60px]">Batal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-50">
                  {initialProducts.map((prod, index) => {
                    const margin = prod.price > 0 
                      ? Math.round(((prod.price - prod.modal) / prod.price) * 100) 
                      : 0;

                    return (
                      <tr key={index} className="hover:bg-stone-50/50 duration-150">
                        {/* Name */}
                        <td className="py-2.5 pl-4 pr-2">
                          <input
                            type="text"
                            value={prod.name}
                            onChange={(e) => updateProductItem(index, "name", e.target.value)}
                            placeholder="Contoh: Es Campur"
                            className="w-full h-9 px-2.5 rounded-lg border border-stone-200 focus:border-emerald-500 text-xs text-stone-800 font-bold"
                          />
                        </td>
                        {/* Cost (Modal) */}
                        <td className="py-2.5 px-1.5">
                          <input
                            type="number"
                            value={prod.modal === 0 ? "" : prod.modal}
                            onChange={(e) => updateProductItem(index, "modal", parseInt(e.target.value, 10) || 0)}
                            placeholder="8000"
                            className="w-full h-9 px-1.5 rounded-lg border border-stone-200 focus:border-emerald-500 text-xs text-stone-800 font-bold"
                          />
                        </td>
                        {/* Price (Jual) */}
                        <td className="py-2.5 px-1.5">
                          <input
                            type="number"
                            value={prod.price === 0 ? "" : prod.price}
                            onChange={(e) => updateProductItem(index, "price", parseInt(e.target.value, 10) || 0)}
                            placeholder="15000"
                            className="w-full h-9 px-1.5 rounded-lg border border-stone-200 focus:border-emerald-500 text-xs text-stone-800 font-extrabold text-emerald-700"
                          />
                        </td>
                        {/* Stock */}
                        <td className="py-2.5 px-1.5">
                          <input
                            type="number"
                            value={prod.stock === 0 ? "" : prod.stock}
                            onChange={(e) => updateProductItem(index, "stock", parseInt(e.target.value, 10) || 0)}
                            placeholder="50"
                            className="w-full h-9 px-1.5 rounded-lg border border-stone-200 focus:border-emerald-500 text-xs text-stone-800 font-bold text-center"
                          />
                        </td>
                        {/* Actions */}
                        <td className="py-2.5 pr-4 text-center">
                          <button
                            onClick={() => removeProductRow(index)}
                            disabled={initialProducts.length <= 1}
                            className="text-stone-400 hover:text-red-500 disabled:opacity-30 duration-150 p-1 rounded-full cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              {initialProducts.length < 15 && (
                <button
                  onClick={addProductRow}
                  className="flex items-center justify-center gap-1.5 py-2.5 px-4 w-full text-xs font-extrabold text-emerald-600 hover:bg-emerald-50 active:bg-emerald-100 rounded-b-xl border-dashed border-t border-stone-200 duration-150 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  Tambah Baris Produk Baru
                </button>
              )}
            </div>

            {/* Stepper CTAs */}
            <div className="flex gap-4">
              <button
                onClick={handlePrevStep}
                className="flex items-center justify-center gap-2 w-1/3 h-[52px] bg-white border-2 border-stone-200 hover:bg-stone-50 hover:border-stone-300 text-stone-600 font-extrabold rounded-xl text-[15px] transition-all duration-200 cursor-pointer shadow-sm"
              >
                <ChevronLeft className="w-5 h-5" />
                Kembali
              </button>
              <button
                onClick={handleNextStep}
                className="flex items-center justify-center gap-2 flex-1 h-[52px] bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white rounded-xl font-extrabold text-[15px] tracking-wide shadow-[0_8px_20px_-8px_rgba(16,185,129,0.5)] transform active:scale-[0.98] transition-all duration-200 cursor-pointer border border-emerald-400/20"
              >
                Simpan & Atur Target
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Target Bisnis & Konfirmasi */}
        {currentStep === 3 && (
          <div className="space-y-6">
            <div>
              <h2 className="font-heading font-extrabold text-2xl text-stone-900 tracking-tight leading-none mb-2">
                Sesuaikan Target & Waktu Kerja
              </h2>
              <p className="text-stone-500 text-sm">
                Terakhir, tentukan target omzet impian toko Anda agar Copilot dapat membantu Anda memantau pencapaiannya.
              </p>
            </div>

            <div className="space-y-5 bg-white border border-stone-200/60 p-6 rounded-2xl shadow-sm">
              {/* Target Slider */}
              <div>
                <div className="flex items-center justify-between font-bold text-xs uppercase text-stone-500 mb-1.5">
                  <span className="flex items-center gap-1.5">
                    <Target className="w-4 h-4 text-emerald-600" />
                    Target Omzet per Bulan
                  </span>
                  <span className="text-emerald-700 text-sm font-extrabold">
                    {formatRupiah(monthlyTarget)}
                  </span>
                </div>
                <input
                  type="range"
                  min="1000000"
                  max="100000000"
                  step="1000000"
                  value={monthlyTarget}
                  onChange={(e) => setMonthlyTarget(parseInt(e.target.value, 10))}
                  className="w-full h-2 bg-stone-200 accent-emerald-600 rounded-full cursor-pointer"
                />
                <div className="flex items-center justify-between text-[10px] text-stone-400 font-extrabold mt-1 uppercase">
                  <span>Rp 1 Juta</span>
                  <span>Rp 25 Jt</span>
                  <span>Rp 50 Jt</span>
                  <span>Rp 100 Juta</span>
                </div>
              </div>

              {/* Day Multi-toggles */}
              <div>
                <label className="block text-xs font-bold uppercase text-stone-500 mb-2">
                  Hari Operasinal Toko Buka
                </label>
                <div className="flex flex-wrap gap-2">
                  {indonesianDaysShort.map((day) => {
                    const active = activeDays[day];
                    return (
                      <button
                        key={day}
                        onClick={() => toggleDay(day)}
                        className={`w-10 h-10 rounded-xl font-bold text-xs border transition flex items-center justify-center cursor-pointer ${
                          active
                            ? "bg-emerald-600 text-white border-emerald-600 shadow-sm"
                            : "bg-white text-stone-500 border-stone-200 hover:border-stone-300"
                        }`}
                      >
                        {day}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Time Selector Inputs */}
              <div>
                <label className="block text-xs font-bold uppercase text-stone-500 mb-1.5 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-emerald-600" />
                  Jam Buka & Tutup Toko
                </label>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <span className="text-[10px] text-stone-400 uppercase font-black block mb-1">Mulai Buka</span>
                    <input
                      type="time"
                      value={openTime}
                      onChange={(e) => setOpenTime(e.target.value)}
                      className="w-full h-10 px-3 border border-stone-200 rounded-xl text-xs text-stone-800 font-bold"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] text-stone-400 uppercase font-black block mb-1">Selesai Tutup</span>
                    <input
                      type="time"
                      value={closeTime}
                      onChange={(e) => setCloseTime(e.target.value)}
                      className="w-full h-10 px-3 border border-stone-200 rounded-xl text-xs text-stone-800 font-bold"
                    />
                  </div>
                </div>
              </div>
              {/* Use Dummy Data Toggle */}
              <div className="flex items-center gap-3 bg-indigo-50/50 p-4 border border-indigo-100/50 rounded-2xl">
                <input
                  type="checkbox"
                  id="useDummy"
                  checked={useDummy}
                  onChange={(e) => setUseDummy(e.target.checked)}
                  className="w-5 h-5 rounded border-stone-300 text-emerald-600 focus:ring-emerald-600 cursor-pointer"
                />
                <label htmlFor="useDummy" className="text-xs font-bold text-indigo-900 cursor-pointer">
                  Isi dengan Data Uji Coba (Bisa di-reset kapan saja)
                </label>
              </div>

            </div>

            {/* CTAs */}
            <div className="flex gap-4 pt-2">
              <button
                onClick={handlePrevStep}
                className="flex items-center justify-center gap-2 w-1/3 h-[52px] bg-white border-2 border-stone-200 hover:bg-stone-50 hover:border-stone-300 text-stone-600 font-extrabold rounded-xl text-[15px] transition-all duration-200 cursor-pointer shadow-sm"
              >
                <ChevronLeft className="w-5 h-5" />
                Kembali
              </button>
              <button
                onClick={handleFinish}
                disabled={loading}
                className="flex items-center justify-center gap-2 flex-1 h-[52px] bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white rounded-xl font-extrabold text-[15px] tracking-wide shadow-[0_8px_20px_-8px_rgba(16,185,129,0.5)] transform active:scale-[0.98] transition-all duration-200 cursor-pointer border border-emerald-400/20 disabled:opacity-50"
              >
                {loading ? "Memproses..." : "Mulai Gunakan Copilot 🚀"}
              </button>
            </div>
            {submitError && (
              <div className="mt-4 p-3 bg-rose-50 border border-rose-200 text-rose-600 rounded-xl text-sm font-bold">
                {submitError}
              </div>
            )}
          </div>
        )}
      </div>

      {/* RIGHT ILLUSTRATION COLLATERAL SIDEBAR (45%) */}
      <div className="hidden lg:flex lg:col-span-5 bg-gradient-to-br from-[#064E3B] via-[#047857] to-[#10B981] p-12 text-white flex-col justify-between relative overflow-hidden">
        {/* Subtle geometric circles */}
        <div className="absolute -top-16 -right-16 w-64 h-64 bg-emerald-300/10 rounded-full blur-2xl" />
        <div className="absolute -bottom-16 -left-16 w-96 h-96 bg-emerald-100/10 rounded-full blur-3xl animate-pulse" />

        {/* Brand header */}
        <div className="flex items-center gap-3 z-10">
          <div className="w-10 h-10 rounded-xl bg-white/10 border border-white/20 font-black text-lg flex items-center justify-center backdrop-blur-sm">
            UC
          </div>
          <span className="font-heading font-extrabold tracking-tight text-white text-xl">UMKM Copilot</span>
        </div>

        {/* Central Quote/Message Card */}
        <div className="space-y-6 z-10 max-w-sm mt-12 mb-auto">
          <div className="w-12 h-12 rounded-2xl bg-white/10 border border-white/10 flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-emerald-300" />
          </div>
          <div className="space-y-3">
            <h3 className="font-heading font-extrabold text-3xl leading-tight">
              Kembangkan Usaha Anda dengan AI.
            </h3>
            <p className="text-emerald-100/80 font-body leading-relaxed text-sm">
              "Menurut data, 64 juta UMKM di Indonesia menyokong ekonomi bangsa. UMKM Copilot didesain khusus membantu Anda mendigitalisasi catatan keuangan, memprediksi laba saku, dan mengekstrak struk belanja secepat kilat!"
            </p>
          </div>
        </div>

        {/* Signature */}
        <div className="z-10 text-emerald-100/50 text-[11px] font-bold tracking-wider uppercase">
          Membantu UMKM Indonesia Tumbuh Hebat 🇮🇩
        </div>
      </div>
    </div>
  );
}
