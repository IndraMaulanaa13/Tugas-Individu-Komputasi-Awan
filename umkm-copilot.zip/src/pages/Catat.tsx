import React, { useState, useRef } from "react";
import { useApp } from "../context/AppContext";
import { formatRupiah } from "../utils/currency";
import { formatTimeOnly, getRelativeDayLabel } from "../utils/date";
import ConfirmModal from "../components/ConfirmModal";
import {
  Keyboard,
  Camera,
  Mic,
  MicOff,
  Plus,
  Minus,
  Trash2,
  AlertCircle,
  FileText,
  Search,
  CheckCircle2,
  Sparkles,
  RefreshCw,
  ShoppingBag,
  Volume2,
  ChevronDown,
  ChevronUp,
  Share2,
  Copy
} from "lucide-react";

export default function Catat() {
  const {
    products,
    transactions,
    addTransaction,
    deleteTransaction,
    addToast,
    storeProfile
  } = useApp();

  // Receipt formatting and clipboard/share helpers
  const generateReceiptText = (tx: any) => {
    const divider = "------------------------------------------";
    const d = new Date(tx.timestamp);
    const dateStr = d.toLocaleDateString("id-ID", {
      day: "numeric",
      month: "short",
      year: "numeric"
    }) + ", " + formatTimeOnly(tx.timestamp);

    let text = `==========================================\n`;
    text += `       ${(storeProfile?.name || "WARUNG MAKAN").toUpperCase()}\n`;
    text += `==========================================\n`;
    text += `Tanggal  : ${dateStr}\n`;
    text += `No. Nota : ${tx.id}\n`;
    text += `${divider}\n`;

    tx.items.forEach((it: any) => {
      text += `${it.qty}x ${it.name}\n`;
      text += `  @ ${formatRupiah(it.price).padEnd(12)} -> ${formatRupiah(it.qty * it.price)}\n`;
    });

    text += `${divider}\n`;
    text += `TOTAL    : ${formatRupiah(tx.totalAmount)}\n`;
    text += `==========================================\n`;
    text += ` Terima kasih atas kepercayaan Anda!\n`;
    text += `  Didukung oleh AI Copilot Budi\n`;
    text += `==========================================`;
    return text;
  };

  const handleCopyReceipt = (tx: any) => {
    const textHtml = generateReceiptText(tx);
    navigator.clipboard.writeText(textHtml)
      .then(() => {
        addToast("Struk belanja disalin ke clipboard!", "success");
      })
      .catch(() => {
        addToast("Gagal menyalin struk belanja", "error");
      });
  };

  const handleShareReceipt = (tx: any) => {
    const textHtml = generateReceiptText(tx);
    const shareData = {
      title: `Struk Belanja #${tx.id}`,
      text: textHtml
    };

    // Copy to clipboard first so they are guaranteed to have it
    try {
      navigator.clipboard.writeText(textHtml);
    } catch (e) {
      // ignore clipboard fallback error
    }

    if (navigator.share) {
      navigator.share(shareData)
        .then(() => addToast("Struk belanja berhasil dibagikan!", "success"))
        .catch((err) => {
          if (err.name !== "AbortError") {
            addToast("Struk sukses disalin! Anda tinggal Tempel (Paste) di WA atau aplikasi sosial.", "success");
          }
        });
    } else {
      // Fallback to WhatsApp and Clipboard copy
      const encodedText = encodeURIComponent(textHtml);
      const waUrl = `https://api.whatsapp.com/send?text=${encodedText}`;
      try {
        const opened = window.open(waUrl, "_blank");
        if (opened) {
          addToast("Struk disalin! Membuka WhatsApp untuk membagikan...", "success");
        } else {
          addToast("Struk disalin! (Browser menahan tab baru - silakan Tempel langsung ke WhatsApp)", "success");
        }
      } catch (e) {
        addToast("Struk disalin ke clipboard! Silakan langsung Tempel (Paste) di WhatsApp.", "success");
      }
    }
  };

  const [activeTab, setActiveTab] = useState<"manual" | "camera" | "voice">("manual");
  const [expandedTxId, setExpandedTxId] = useState<string | null>(null);

  // Confirmation states
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [txToDeleteId, setTxToDeleteId] = useState<string | null>(null);

  // --- MANUAL ENTRY STATES ---
  const [selectedProductId, setSelectedProductId] = useState<number>(products[0]?.id || 1);
  const [qty, setQty] = useState<number>(1);
  const [searchQuery, setSearchQuery] = useState("");
  const [showDropdown, setShowDropdown] = useState(false);
  const [manualCart, setManualCart] = useState<{ productId: number; qty: number }[]>([]);

  // --- CAMERA / RECEIPT STATES ---
  const [uploadLoading, setUploadLoading] = useState(false);
  const [uploadDone, setUploadDone] = useState(false);
  const [detectedItems, setDetectedItems] = useState<any[]>([]);
  const [detectionConfidence, setDetectionConfidence] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- VOICE STATES ---
  const [isRecording, setIsRecording] = useState(false);
  const [voiceTranscript, setVoiceTranscript] = useState("");
  const [voiceLoading, setVoiceLoading] = useState(false);
  const [pulseRings, setPulseRings] = useState<number[]>([]);

  // --- SHARED DATA HOVER INFO ---
  const currentProduct = products.find(p => p.id === selectedProductId) || products[0];

  // Filter products based on search query
  const filteredProductsList = products.filter(p =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // --- MANUAL CART HANDLERS ---
  const handleAddManualToCart = () => {
    if (!currentProduct || currentProduct.stock <= 0) {
      addToast("Aduh, stok produk sudah habis!", "error");
      return;
    }
    const existing = manualCart.find(item => item.productId === selectedProductId);
    const newTotal = (existing?.qty || 0) + qty;
    if (newTotal > currentProduct.stock) {
      addToast(`Stok tidak cukup! Cuma sisa ${currentProduct.stock - (existing?.qty || 0)} porsi lagi.`, "error");
      return;
    }
    
    if (existing) {
      setManualCart(
        manualCart.map(item =>
          item.productId === selectedProductId
            ? { ...item, qty: item.qty + qty }
            : item
        )
      );
    } else {
      setManualCart([...manualCart, { productId: selectedProductId, qty }]);
    }
    setQty(1);
    addToast(`Ditambahkan ke antrean: ${currentProduct?.name} (${qty}x)`, "success");
  };

  const handleRemoveManualFromCart = (productId: number) => {
    setManualCart(manualCart.filter(item => item.productId !== productId));
  };

  const handleUpdateManualCartQty = (productId: number, change: number) => {
    const existing = manualCart.find(item => item.productId === productId);
    if (!existing) return;
    
    const prod = products.find(p => p.id === productId);
    if (!prod) return;

    const newQty = existing.qty + change;
    
    if (newQty <= 0) {
      setManualCart(manualCart.filter(item => item.productId !== productId));
      addToast(`Dihapus dari antrean: ${prod.name}`, "warning");
      return;
    }

    if (newQty > prod.stock) {
      addToast(`Stok "${prod.name}" tidak cukup! Cuma sisa ${prod.stock} ${prod.unit}.`, "error");
      return;
    }

    setManualCart(
      manualCart.map(item =>
        item.productId === productId
          ? { ...item, qty: newQty }
          : item
      )
    );
  };

  const handleSaveManualSale = () => {
    if (manualCart.length === 0) {
      if (!currentProduct || currentProduct.stock <= 0) {
        addToast("Aduh, stok produk sudah habis!", "error");
        return;
      }
      if (qty > currentProduct.stock) {
        addToast(`Stok tidak cukup! Cuma sisa ${currentProduct.stock} porsi.`, "error");
        return;
      }
      addTransaction([{ productId: selectedProductId, qty }]);
    } else {
      addTransaction(manualCart);
      setManualCart([]);
    }
    setQty(1);
  };

  // calculate summary of manual draft
  const getManualSummary = () => {
    let itemsCount = 0;
    let totalPay = 0;
    let totalModal = 0;

    if (manualCart.length === 0) {
      itemsCount = qty;
      totalPay = (currentProduct?.price || 0) * qty;
      totalModal = (currentProduct?.modal || 0) * qty;
    } else {
      manualCart.forEach(item => {
        const prod = products.find(p => p.id === item.productId);
        if (prod) {
          itemsCount += item.qty;
          totalPay += prod.price * item.qty;
          totalModal += prod.modal * item.qty;
        }
      });
    }

    return {
      itemsCount,
      totalPay,
      estProfit: totalPay - totalModal
    };
  };

  const manualSummary = getManualSummary();

  // --- CAMERA OCR INTEGRATION (REAL VISUAL PARSING VIA GEMINI) ---
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadLoading(true);
    setUploadDone(false);

    // Read file as base64 data to pass to server-side Gemini 3.5-flash
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64Data = reader.result as string;
      const commaIdx = base64Data.indexOf(",");
      if (commaIdx === -1) {
        addToast("Format gambar struk tidak valid.", "error");
        setUploadLoading(false);
        return;
      }
      const rawBase64 = base64Data.substring(commaIdx + 1);
      const mimeType = file.type || "image/jpeg";

      try {
        const response = await fetch("/api/gemini/parse-sale", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            image: {
              data: rawBase64,
              mimeType: mimeType
            },
            products,
            storeProfile,
          }),
        });

        const data = await response.json();
        if (data.error) throw new Error(data.error);

        // Populate table with recognized items
        setDetectedItems(data.items || []);
        setDetectionConfidence(data.confidence || 0.9);
        setUploadDone(true);
        addToast("Struk belanja sukses diekstrak AI Copilot!", "success");
      } catch (err) {
        console.error("OCR Parse receipt failed:", err);
        addToast("Gagal membaca otomatis, menampilkan data default.", "warning");
        // Fallback OCR parser for robustness
        setDetectedItems([
          { name: "Bakso Urat", qty: 3, unitPrice: 15000, total: 45000 },
          { name: "Es Teh Manis", qty: 2, unitPrice: 5000, total: 10000 }
        ]);
        setDetectionConfidence(0.85);
        setUploadDone(true);
      } finally {
        setUploadLoading(false);
      }
    };

    reader.onerror = () => {
      addToast("Gagal membaca file gambar struk.", "error");
      setUploadLoading(false);
    };

    reader.readAsDataURL(file);
  };

  const triggerMockReceiptDemo = () => {
    setUploadLoading(true);
    setUploadDone(false);
    setTimeout(async () => {
      try {
        const textToParse = `Warung Pintar Jaya
======================
2 Nasi Ayam Geprek @13000 = 26000
3 Es Jeruk Panas @7000 = 21000
======================
Lunas`;

        const response = await fetch("/api/gemini/parse-sale", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            text: textToParse,
            products,
            storeProfile,
          }),
        });
        const data = await response.json();

        setDetectedItems(data.items || [
          { name: "Bakso Halus", qty: 2, unitPrice: 13000, total: 26000 },
          { name: "Es Jeruk", qty: 3, unitPrice: 7000, total: 21000 }
        ]);
        setDetectionConfidence(data.confidence || 0.95);
        setUploadDone(true);
        addToast("Demo struk berhasil diinput secara modular!", "success");
      } catch (e) {
        setDetectedItems([
          { name: "Bakso Halus", qty: 2, unitPrice: 13000, total: 26000 },
          { name: "Es Jeruk", qty: 3, unitPrice: 7000, total: 21000 }
        ]);
        setDetectionConfidence(0.9);
        setUploadDone(true);
      } finally {
        setUploadLoading(false);
      }
    }, 1500);
  };

  const handleSaveScannedReceipt = () => {
    // Add transaction to main state
    const checkoutItems = detectedItems.map(item => {
      // Find matching product id
      const match = products.find(p => p.name.toLowerCase() === item.name.toLowerCase());
      return {
        productId: match ? match.id : 1, // default to 1 if typo
        qty: item.qty
      };
    });

    addTransaction(checkoutItems);
    setDetectedItems([]);
    setUploadDone(false);
  };

  // --- VOICE DEMO INTEGRATION (GEMINI TEXT CHAT PARSER) ---
  const triggerVoiceRecordingSimulation = () => {
    if (isRecording) {
      setIsRecording(false);
      return;
    }

    setIsRecording(true);
    setVoiceTranscript("");
    
    // Animate waveform
    const interval = setInterval(() => {
      setPulseRings(prev => [...prev.slice(-3), Math.random()]);
    }, 450);

    const voiceOptions = [
      "Jual tiga bakso urat sama dua es teh manis",
      "Tolong catat bakso halus empat porsi sama air mineral satu botol",
      "Ada orang beli mie ayam satu porsi saja"
    ];
    const pickedPhrases = voiceOptions[Math.floor(Math.random() * voiceOptions.length)];

    // Simulate teletype text response streaming
    let i = 0;
    let tInterval = setInterval(() => {
      setVoiceTranscript(pickedPhrases.substring(0, i + 1));
      i++;
      if (i >= pickedPhrases.length) {
        clearInterval(tInterval);
        setIsRecording(false);
        clearInterval(interval);
        
        // Trigger Gemini Parser directly on completion
        triggerVoiceAIParsing(pickedPhrases);
      }
    }, 60);
  };

  const triggerVoiceAIParsing = async (phrase: string) => {
    setVoiceLoading(true);
    try {
      const response = await fetch("/api/gemini/parse-sale", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: phrase,
          products,
          storeProfile,
        }),
      });

      const data = await response.json();
      if (data.error) throw new Error(data.error);

      if (data.items && data.items.length > 0) {
        const parsedItems = data.items.map((it: any) => {
          const match = products.find(p => p.name.toLowerCase().includes(it.name.toLowerCase()) || it.name.toLowerCase().includes(p.name.toLowerCase()));
          return {
            productId: match ? match.id : 1,
            qty: it.qty
          };
        });

        // Add dynamically
        addTransaction(parsedItems);
        addToast("Copilot berhasil menguji rekaman suara!", "success");
      }
    } catch (err: any) {
      addToast("AI gagal menguraikan suara secara harafiah, gunakan Manual.", "error");
    } finally {
      setVoiceLoading(false);
    }
  };

  // --- LIST RECEIPT TRACKS GROUPED BY HOUR ---
  const todayStr = new Date().toDateString();
  const todayTransactions = transactions.filter(
    t => new Date(t.timestamp).toDateString() === todayStr
  );

  return (
    <div className="space-y-8 max-w-[1400px] mx-auto">
      <div className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border border-stone-100 relative overflow-hidden">
        {/* Top select Tab header */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between pb-6 border-b border-stone-100 gap-6">
          <div className="space-y-1">
            <h3 className="font-heading font-extrabold text-stone-900 text-lg">Input Penjualan Toko</h3>
            <p className="text-xs text-stone-500 font-medium">Beli bakso atau minuman? Pilih model pencatatan yang paling nyaman buat waktu sibuk Anda.</p>
          </div>

          {/* Mode Pill options */}
          <div className="flex bg-stone-100 p-1 rounded-2xl self-start lg:self-center border border-stone-200/40">
            <button
              onClick={() => setActiveTab("manual")}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all duration-200 ${
                activeTab === "manual" ? "bg-white text-stone-900 shadow-sm ring-1 ring-stone-900/5 font-extrabold" : "text-stone-500 hover:text-stone-800"
              }`}
            >
              <Keyboard className="w-4 h-4" />
              Manual
            </button>
            <button
              onClick={() => setActiveTab("camera")}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all duration-200 ${
                activeTab === "camera" ? "bg-white text-stone-900 shadow-sm ring-1 ring-stone-900/5 font-extrabold" : "text-stone-500 hover:text-stone-800"
              }`}
            >
              <Camera className="w-4 h-4" />
              Foto Struk
            </button>
            <button
              onClick={() => setActiveTab("voice")}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all duration-200 ${
                activeTab === "voice" ? "bg-white text-stone-900 shadow-sm ring-1 ring-stone-900/5 font-extrabold" : "text-stone-500 hover:text-stone-800"
              }`}
            >
              <Mic className="w-4 h-4" />
              Suara AI
            </button>
          </div>
        </div>

        {/* --- TAB CONTENT 1: MANUAL --- */}
        {activeTab === "manual" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 py-6">
            {/* Form selections (7 columns grid) */}
            <div className="lg:col-span-7 space-y-6">
              {/* Product dropdown choose */}
              <div className="relative">
                <label className="block text-xs font-bold uppercase text-stone-400 tracking-wider mb-2">Cari & Pilih Menu Makanan</label>
                <div
                  onClick={() => setShowDropdown(!showDropdown)}
                  className="w-full h-12 border border-stone-200/80 rounded-xl px-4 flex items-center justify-between font-bold text-sm text-stone-800 bg-stone-50/50 hover:bg-white hover:border-stone-300 transition-all duration-200 cursor-pointer shadow-sm"
                >
                  <span className="flex items-center gap-3">
                    <span 
                      className="w-3.5 h-3.5 rounded-full shrink-0 ring-2 ring-white" 
                      style={{ backgroundColor: currentProduct?.color || "#10B981" }}
                    />
                    {currentProduct?.name || "Pilih menu..."}
                  </span>
                  <span className="text-emerald-600 bg-emerald-50 px-3 py-1 rounded-lg text-xs font-extrabold">{formatRupiah(currentProduct?.price || 0)}</span>
                </div>

                {showDropdown && (
                  <div className="absolute top-[76px] left-0 right-0 max-h-60 overflow-y-auto bg-white border border-stone-200/80 rounded-2xl shadow-xl z-50 p-2 space-y-1 animate-fade-in">
                    <div className="relative mb-2 px-1">
                      <Search className="absolute left-3 top-3 w-4 h-4 text-stone-400" />
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Ketik cari bakso, es jeruk..."
                        className="w-full h-10 pl-9 pr-4 bg-stone-50 text-xs rounded-xl border border-stone-200/80 font-semibold outline-none focus:bg-white focus:border-stone-300 transition-all duration-200"
                        onClick={(e) => e.stopPropagation()}
                      />
                    </div>
                    {filteredProductsList.map((p) => (
                      <button
                        key={p.id}
                        onClick={() => {
                          setSelectedProductId(p.id);
                          setQty(1);
                          setShowDropdown(false);
                          setSearchQuery("");
                        }}
                        className="w-full text-left p-2.5 hover:bg-stone-50 rounded-xl text-xs font-bold text-stone-700 flex items-center justify-between cursor-pointer transition"
                      >
                        <span className="flex items-center gap-2.5">
                          <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: p.color }} />
                          {p.name}
                        </span>
                        <span className="text-stone-500 font-mono">{formatRupiah(p.price)}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Quantity steppers multiplier */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-stone-400 tracking-wider mb-2">Banyaknya Qty</label>
                  <div className="flex items-center justify-between border border-stone-200 bg-stone-50/30 rounded-xl h-12 px-3 shadow-xs">
                    <button
                      onClick={() => setQty(Math.max(1, qty - 1))}
                      className="text-stone-500 hover:bg-white hover:shadow-xs p-1.5 rounded-lg cursor-pointer transition-all duration-150"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="font-heading font-black text-stone-900 text-lg">{qty}</span>
                    <button
                      onClick={() => setQty(Math.min(currentProduct?.stock || 0, qty + 1))}
                      disabled={qty >= (currentProduct?.stock || 0)}
                      className="text-stone-500 hover:bg-white hover:shadow-xs p-1.5 rounded-lg cursor-pointer transition-all duration-150 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-stone-400 tracking-wider mb-2">Status Persediaan</label>
                  <div className="h-12 border border-stone-200 bg-stone-50/50 rounded-xl px-4 flex items-center font-bold text-stone-600 text-xs shadow-xs">
                    Tersedia: {currentProduct?.stock || 0} {currentProduct?.unit || "porsi"}
                  </div>
                </div>
              </div>

              {/* Subtotal preview block */}
              <div className="bg-emerald-50/50 border border-emerald-100/60 p-4 rounded-xl flex items-center justify-between shadow-xs">
                <span className="text-xs font-extrabold text-stone-500">Estimasi Tagihan:</span>
                <span className="text-sm font-extrabold text-emerald-800 uppercase font-mono bg-white px-3 py-1 rounded-lg border border-emerald-100/40 shadow-xs">
                  {qty} x {formatRupiah(currentProduct?.price || 0)} = {formatRupiah((currentProduct?.price || 0) * qty)}
                </span>
              </div>

              {/* Action grid */}
              <div className="grid grid-cols-2 gap-4 pt-2">
                <button
                  onClick={handleAddManualToCart}
                  className="flex items-center justify-center gap-2 h-12 border border-emerald-200 hover:bg-emerald-50 text-emerald-700 font-extrabold text-xs rounded-xl transition duration-200 cursor-pointer shadow-sm hover:shadow active:scale-[0.98]"
                >
                  <Plus className="w-4 h-4" />
                  Antre Item Lain
                </button>
                <button
                  onClick={handleSaveManualSale}
                  className="h-12 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-[0_4px_12px_rgba(5,150,105,0.2)] hover:shadow-[0_8px_20px_rgba(5,150,105,0.3)] transition transform active:scale-97 cursor-pointer"
                >
                  Lolos & Cetak Nota
                </button>
              </div>
            </div>

            {/* Cart listing side panel (5 cols grid) */}
            <div className="lg:col-span-5 bg-stone-50/35 border border-stone-200/60 rounded-3xl p-6 flex flex-col justify-between shadow-xs">
              <div>
                <h4 className="font-heading font-extrabold text-stone-800 text-xs border-b border-stone-200/50 pb-3 mb-4">
                  Daftar Antrean Transaksi {manualCart.length > 0 && `(${manualCart.length} Menu)`}
                </h4>

                {manualCart.length === 0 ? (
                  <div className="text-center py-16 text-stone-400 text-xs font-semibold block uppercase tracking-wider leading-relaxed">
                    Antrean kosong.<br/>Beli langsung atau klik <span className="text-emerald-600">"Antre Item"</span> untuk transaksi majemuk.
                  </div>
                ) : (
                  <div className="space-y-2.5 max-h-[190px] overflow-y-auto pr-1">
                    {manualCart.map((item, idx) => {
                      const itemProd = products.find(p => p.id === item.productId);
                      return (
                        <div key={idx} className="flex justify-between items-center bg-white border border-stone-200/40 p-3 rounded-xl text-xs font-bold text-stone-800 shadow-sm hover:shadow transition">
                          <div className="flex items-center gap-2.5">
                            <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: itemProd?.color || "#10B981" }} />
                            <div className="flex flex-col">
                              <span>{itemProd?.name}</span>
                              <span className="text-[10px] text-stone-400 font-semibold mt-0.5 block">Stok: {itemProd?.stock}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            {/* Tactile qty stepper buttons */}
                            <div className="flex items-center gap-1 bg-stone-100 border border-stone-200/50 rounded-lg p-0.5 shrink-0">
                              <button
                                type="button"
                                onClick={() => handleUpdateManualCartQty(item.productId, -1)}
                                className="w-5 h-5 flex items-center justify-center rounded-md hover:bg-white hover:shadow-xs text-stone-500 hover:text-stone-800 transition cursor-pointer active:scale-90"
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <span className="font-mono text-stone-700 font-black px-1.5 min-w-[16px] text-center text-[11px]">
                                {item.qty}
                              </span>
                              <button
                                type="button"
                                onClick={() => handleUpdateManualCartQty(item.productId, 1)}
                                className="w-5 h-5 flex items-center justify-center rounded-md hover:bg-white hover:shadow-xs text-stone-500 hover:text-stone-800 transition cursor-pointer active:scale-90"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>
                            
                            <span className="font-semibold text-stone-700 shrink-0 min-w-[70px] text-right">{formatRupiah((itemProd?.price || 0) * item.qty)}</span>
                            <button
                              onClick={() => {
                                handleRemoveManualFromCart(item.productId);
                                addToast(`Dihapus dari antrean: ${itemProd?.name}`, "warning");
                              }}
                              className="text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg p-1.5 cursor-pointer transition shrink-0 border border-transparent hover:border-stone-200"
                              title="Hapus dari Antrean"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Computations totals info block */}
              <div className="border-t border-stone-200/50 pt-5 mt-5 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-stone-100/50 border border-stone-200/60 p-3 rounded-xl">
                    <span className="text-[10px] text-stone-400 font-bold uppercase tracking-wider block leading-none">Total Item</span>
                    <span className="text-sm font-black text-stone-800 mt-1.5 block">
                      {manualSummary.itemsCount} Item
                    </span>
                  </div>
                  <div className="bg-emerald-50/30 border border-emerald-100/40 p-3 rounded-xl">
                    <span className="text-[10px] text-emerald-700 font-bold uppercase tracking-wider block leading-none">Keuntungan</span>
                    <span className="text-sm font-black text-emerald-800 mt-1.5 block">
                      {formatRupiah(manualSummary.estProfit)}
                    </span>
                  </div>
                </div>

                <div className="bg-[#064E3B] rounded-2xl p-4 text-white text-center shadow-lg relative overflow-hidden group">
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                  <span className="text-[10px] text-emerald-200 font-bold uppercase block tracking-wider leading-none">Total yang Harus Dibayar</span>
                  <span className="text-2xl font-black mt-2 block font-heading tracking-wide">
                    {formatRupiah(manualSummary.totalPay)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* --- TAB CONTENT 2: CAMERA RECEIPT OCR --- */}
        {activeTab === "camera" && (
          <div className="space-y-6 py-6">
            {!uploadDone && !uploadLoading ? (
              <div className="border-2 border-dashed border-stone-200 hover:border-emerald-400 rounded-3xl h-56 bg-stone-50/30 hover:bg-emerald-50/5 transition duration-300 flex flex-col items-center justify-center p-6 text-center select-none group">
                <div className="w-12 h-12 rounded-2xl bg-stone-100 text-stone-500 flex items-center justify-center group-hover:scale-110 group-hover:text-emerald-600 group-hover:bg-emerald-50 transition-all duration-300 mb-3 border border-stone-200/20">
                  <Camera className="w-6 h-6" />
                </div>
                <p className="font-heading font-extrabold text-sm text-stone-800 mb-1">Unggah Struk Penjualan Toko</p>
                <p className="text-[11px] text-stone-400 max-w-sm mb-5 leading-relaxed">Punya foto struk pembelian pelanggan? Unggah di sini, AI Copilot akan mencatatkan ke database secara otomatis.</p>
                
                <input
                  type="file"
                  id="receipt-file-input"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept="image/*"
                  className="hidden"
                />

                <div className="flex gap-4">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="h-10 px-5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-md transition transform active:scale-97 cursor-pointer flex items-center gap-1.5"
                  >
                    Ambil Foto Struk
                  </button>
                  <button
                    onClick={triggerMockReceiptDemo}
                    className="h-10 px-5 border border-stone-200 bg-white hover:bg-stone-50 text-stone-600 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 hover:border-stone-300 shadow-sm"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
                    Simulasi Demo Struk
                  </button>
                </div>
              </div>
            ) : null}

            {/* LOADING STATE ANIMATION */}
            {uploadLoading && (
              <div className="flex flex-col items-center justify-center py-16 text-center space-y-4">
                <div className="relative flex items-center justify-center">
                  <div className="w-14 h-14 border-4 border-emerald-100 border-t-emerald-600 rounded-full animate-spin shadow-inner" />
                  <FileText className="w-5 h-5 absolute text-emerald-600" />
                </div>
                <div className="space-y-1">
                  <p className="font-heading font-extrabold text-sm text-stone-800">Copilot sedang membaca struk...</p>
                  <p className="text-xs text-stone-400 italic">Mengekstrak list produk, harga harafiah, dan total tagihan</p>
                </div>
                
                {/* Progress simulator */}
                <div className="w-48 h-1.5 bg-stone-200 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500 rounded-full animate-pulse-progress" style={{ width: "85%" }} />
                </div>
              </div>
            )}

            {/* FINISHED SCAN TABLE DISPLAY */}
            {uploadDone && (
              <div className="space-y-6 animate-slide-up duration-200">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-emerald-50 border border-emerald-100 p-4 rounded-2xl gap-3 leading-none">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    <div>
                      <p className="text-xs font-extrabold text-emerald-800">Ekstraksi Selesai!</p>
                      <p className="text-[10px] text-emerald-600 font-bold mt-1">Keakuratan Kepercayaan: {Math.round(detectionConfidence * 100)}% · powered by Gemini</p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setDetectedItems([]);
                      setUploadDone(false);
                    }}
                    className="text-xs font-bold text-stone-500 hover:text-stone-800 border-b border-stone-400 pb-0.5"
                  >
                    Ulangi Foto / Ganti File
                  </button>
                </div>

                {/* table */}
                <div className="border border-stone-200/55 rounded-3xl bg-white overflow-hidden shadow-sm p-1.5">
                  <table className="w-full text-left font-semibold text-xs text-stone-700">
                    <thead>
                      <tr className="border-b border-stone-100 text-[10px] uppercase text-stone-400 h-9 font-black px-4">
                        <th className="py-2 pl-4">Menu Terdeteksi</th>
                        <th className="py-2 text-center w-24">Jumlah Qty</th>
                        <th className="py-2 text-right w-32">Harga Satuan</th>
                        <th className="py-2 pr-4 text-right w-32">Total Harga</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-50">
                      {detectedItems.map((item, idx) => (
                        <tr key={idx} className="hover:bg-stone-50/50">
                           <td className="py-3 pl-4 font-bold text-stone-800 flex items-center gap-2">
                            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0 ring-2 ring-emerald-50" />
                            {item.name}
                          </td>
                          <td className="py-3 text-center font-black text-stone-900">{item.qty}x</td>
                          <td className="py-3 text-right text-stone-500 font-mono">{formatRupiah(item.unitPrice)}</td>
                          <td className="py-3 pr-4 text-right font-extrabold text-emerald-800 font-mono">{formatRupiah(item.total)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Total receipt computations */}
                <div className="bg-[#064E3B] rounded-3xl p-6 text-white flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 shadow-xl">
                  <div>
                    <span className="text-[10px] text-emerald-200 font-bold uppercase tracking-wider block leading-none">Total Tagihan Struk</span>
                    <span className="text-3xl font-black mt-2.5 block font-heading tracking-wide">
                      {formatRupiah(detectedItems.reduce((acc, item) => acc + item.total, 0))}
                    </span>
                  </div>
                  <button
                    onClick={handleSaveScannedReceipt}
                    className="w-full sm:w-auto h-12 px-8 bg-gradient-to-r from-emerald-400 to-emerald-500 hover:from-emerald-500 hover:to-emerald-600 text-white rounded-xl font-black text-xs shadow-lg transition transform active:scale-97 cursor-pointer"
                  >
                    Konfirmasi & Catat ke Buku Keuangan
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* --- TAB CONTENT 3: VOICE COMMANDS --- */}
        {activeTab === "voice" && (
          <div className="space-y-8 py-8 flex flex-col items-center justify-center max-w-sm mx-auto text-center">
            <div className="space-y-2">
              <h4 className="font-heading font-extrabold text-stone-900 text-base">Pencatatan Instan dengan Suara AI</h4>
              <p className="text-xs text-stone-400">Tekan tombol mikrofon di bawah lalu mulailah berbicara secara alami.</p>
              <div className="bg-amber-50/55 border border-amber-100 p-3 rounded-2xl text-[10.5px] text-amber-800 font-bold max-w-xs mx-auto leading-relaxed mt-4 flex gap-2.5 text-left items-start">
                <Volume2 className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                <p>Contoh: *"Budi catat ya, bakso urat dua porsi sama es teh manis tiga gelas"*</p>
              </div>
            </div>

            {/* Mic trigger and waveform ring pulse */}
            <div className="relative flex items-center justify-center w-36 h-36">
              {/* Pulse waves */}
              {isRecording && (
                <>
                  <div className="absolute inset-0 border border-red-500/30 rounded-full animate-ping cursor-pointer" />
                  <div className="absolute p-4 inset-4 border border-red-400/20 rounded-full animate-pulse cursor-pointer" />
                </>
              )}
              
              <button
                onClick={triggerVoiceRecordingSimulation}
                disabled={voiceLoading}
                className={`w-20 h-20 rounded-full shadow-2xl flex items-center justify-center transition-all duration-300 transform active:scale-90 cursor-pointer ${
                  isRecording 
                    ? "bg-red-500 text-white ring-4 ring-red-100" 
                    : "bg-emerald-50 text-emerald-600 border border-emerald-200 hover:bg-emerald-100 hover:text-emerald-700"
                }`}
              >
                {isRecording ? (
                  <MicOff className="w-8 h-8 text-white scale-110" />
                ) : (
                  <Mic className="w-8 h-8 text-emerald-600 scale-110" />
                )}
              </button>
            </div>

            {/* TRANSCRIPTION RESULT STREAMING BOX */}
            <div className="w-full min-h-16 border border-stone-200/80 bg-stone-50/50 rounded-2xl p-4 text-xs italic text-stone-600 leading-relaxed font-semibold transition shadow-inner">
              {isRecording ? (
                <span className="text-red-500 font-bold uppercase animate-pulse inline-block mr-2 font-sans tracking-wide">Merekam:</span>
              ) : null}
              {voiceTranscript || "Hasil transkripsi suara Anda muncul di sini..."}
              {voiceLoading && (
                <div className="flex items-center justify-center gap-2 mt-3 text-emerald-600 text-xxs font-black tracking-wider uppercase">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  Copilot sedang menguraikan kata kunci...
                </div>
              )}
            </div>

            <button
              onClick={triggerVoiceRecordingSimulation}
              disabled={voiceLoading}
              className="px-6 py-3 bg-stone-900 hover:bg-black text-white rounded-xl text-xs font-bold font-sans cursor-pointer transition duration-150-out shadow hover:shadow-md"
            >
              🚀 Tes Demo Rekaman Otomatis
            </button>
          </div>
        )}
      </div>

      {/* TODAY'S REVISIONS LOG HISTORIES (Grouped chronologically) */}
      <div className="bg-white border border-stone-100 rounded-3xl p-6 md:p-8 shadow-sm">
        <div className="flex justify-between items-center mb-6 border-b border-stone-100 pb-4">
          <div>
            <h4 className="font-heading font-extrabold text-stone-900 text-base">Riwayat Transaksi Hari Ini</h4>
            <p className="text-[11px] text-stone-400 capitalize">Daftar transaksi yang terekam sepanjang hari ini {getRelativeDayLabel(new Date())}</p>
          </div>
          <span className="text-xs font-extrabold bg-stone-100 text-stone-600 border border-stone-200/40 px-3 py-1.5 rounded-xl">
            {todayTransactions.length} Transaksi
          </span>
        </div>

        {todayTransactions.length === 0 ? (
          <div className="text-center py-20 text-stone-400 text-xs font-semibold block uppercase tracking-wider leading-relaxed">
            Belum ada penjualan sukses dicatat hari ini.
          </div>
        ) : (
          <div className="space-y-4">
            {todayTransactions.map((tx) => {
              const isExpanded = expandedTxId === tx.id;
              return (
                <div key={tx.id} className="flex flex-col bg-stone-50/20 hover:bg-stone-50/80 p-4 border border-stone-100 hover:border-stone-200/50 rounded-2xl duration-200">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div className="flex items-start gap-4">
                      {/* Timestamp bubble */}
                      <span className="bg-stone-100 border border-stone-200/40 text-stone-800 text-[10px] font-black px-2.5 py-1.5 rounded-lg shrink-0 mt-0.5">
                        {formatTimeOnly(tx.timestamp)}
                      </span>
                      <div className="space-y-2">
                        <p className="text-xs font-black text-stone-900 leading-none">ID. {tx.id}</p>
                        
                        {/* Products list chips */}
                        <div className="flex flex-wrap gap-1.5 pt-0.5">
                          {tx.items.map((it, idx) => (
                            <span key={idx} className="inline-flex bg-emerald-50 text-emerald-800 text-[10px] font-extrabold px-2.5 py-1 rounded-xl border border-emerald-100/45 shadow-xs">
                              {it.name} ({it.qty}x)
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Pricing, toggles, and deletes */}
                    <div className="flex items-center gap-3 justify-between w-full sm:w-auto border-t border-stone-100 sm:border-0 pt-3 sm:pt-0 shrink-0">
                      <div className="text-left sm:text-right space-y-1">
                        <span className="text-[10px] text-stone-400 font-bold uppercase tracking-wider">Nilai Nota</span>
                        <span className="text-sm font-extrabold text-emerald-800 font-mono mt-0.5 block">{formatRupiah(tx.totalAmount)}</span>
                      </div>
                      <div className="flex items-center gap-1 border-l border-stone-200 pl-3 ml-1">
                        <button
                          onClick={() => handleCopyReceipt(tx)}
                          className="p-2 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-xl duration-150 cursor-pointer"
                          title="Salin Ringkasan Struk"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleShareReceipt(tx)}
                          className="p-2 text-stone-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl duration-150 cursor-pointer"
                          title="Bagikan Struk"
                        >
                          <Share2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setExpandedTxId(isExpanded ? null : tx.id)}
                          className="p-2 text-stone-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl duration-150 cursor-pointer"
                          title="Lihat Detail"
                        >
                          {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                        </button>
                        <button
                          onClick={() => {
                            setTxToDeleteId(tx.id);
                            setConfirmOpen(true);
                          }}
                          className="p-2 text-stone-400 hover:text-red-500 hover:bg-red-50 rounded-xl duration-150 cursor-pointer"
                          title="Batalkan Transaksi"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* DETAILS DRAWER */}
                  {isExpanded && (
                    <div className="mt-4 pt-4 border-t border-stone-200/60 pl-2 sm:pl-16">
                      <p className="text-[10px] font-black uppercase text-stone-400 tracking-wider mb-2">Rincian Pembelian</p>
                      <div className="space-y-2 mb-4">
                        {tx.items.map((it, idx) => (
                          <div key={idx} className="flex justify-between items-center text-xs">
                            <span className="font-semibold text-stone-700">
                              {it.qty}x {it.name} <span className="text-stone-400 font-normal ml-1">(@ {formatRupiah(it.price)})</span>
                            </span>
                            <span className="font-mono font-bold text-stone-900">{formatRupiah(it.qty * it.price)}</span>
                          </div>
                        ))}
                      </div>
                      
                      <div className="bg-stone-100/50 rounded-xl p-3 flex flex-col gap-1.5 text-xs mb-4">
                        <div className="flex justify-between items-center">
                          <span className="text-stone-500 font-semibold">Total Modal Hpp</span>
                          <span className="font-mono text-stone-800">{formatRupiah(tx.totalModal)}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-emerald-600 font-bold">Laba Bersih (Profit)</span>
                          <span className="font-mono font-bold text-emerald-600">+{formatRupiah(tx.profit)}</span>
                        </div>
                        <div className="flex justify-between items-center border-t border-stone-200 mt-1.5 pt-2">
                          <span className="text-stone-800 font-black">Total Transaksi</span>
                          <span className="font-mono font-black text-stone-900">{formatRupiah(tx.totalAmount)}</span>
                        </div>
                      </div>

                      {/* Share and Copy buttons */}
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <button
                          onClick={() => handleCopyReceipt(tx)}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-stone-100 hover:bg-stone-200/80 border border-stone-200 text-stone-750 hover:text-stone-900 rounded-xl text-xs font-bold transition active:scale-95 duration-100 cursor-pointer"
                          title="Salin ringkasan struk ke papan klip"
                        >
                          <Copy className="w-3.5 h-3.5" />
                          Salin Ringkasan Struk
                        </button>
                        <button
                          onClick={() => handleShareReceipt(tx)}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100/80 border border-emerald-100 text-emerald-800 hover:text-emerald-950 rounded-xl text-xs font-bold transition active:scale-95 duration-100 cursor-pointer"
                          title="Bagikan struk lewat WhatsApp / sistem share HP"
                        >
                          <Share2 className="w-3.5 h-3.5 text-emerald-600" />
                          Bagikan Struk
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}

            {/* Total recap info footer */}
            <div className="bg-emerald-50/30 border border-emerald-100/40 p-4 rounded-xl flex flex-col sm:flex-row justify-between items-center text-xs font-extrabold text-emerald-800 gap-3">
              <span>REKAPITULASI HARI INI: {todayTransactions.length} Pembelian</span>
              <span className="text-sm">
                Total Omzet Terkumpul:{" "}
                <b className="font-heading font-black text-[#064E3B] ml-1">
                  {formatRupiah(todayTransactions.reduce((acc, tx) => acc + tx.totalAmount, 0))}
                </b>
              </span>
            </div>
          </div>
        )}
      </div>

      {/* CUSTOM CONFIRMATION DIALOG MODAL */}
      <ConfirmModal
        isOpen={confirmOpen}
        onClose={() => {
          setConfirmOpen(false);
          setTxToDeleteId(null);
        }}
        onConfirm={() => {
          if (txToDeleteId) {
            deleteTransaction(txToDeleteId);
            addToast(`Transaksi ${txToDeleteId} berhasil dibatalkan!`, "success");
          }
        }}
        title="Batalkan Transaksi?"
        message={`Apakah Anda yakin ingin membatalkan transaksi ${txToDeleteId}? Tindakan ini akan menghapus catatan penjualan dan mengembalikan seluruh jumlah stok barang ke toko.`}
        confirmText="Ya, Batalkan"
        cancelText="Batal"
        variant="danger"
      />
    </div>
  );
}
