export interface StoreProfile {
  id: string;
  name: string;
  type: string;
  location: string;
  since: number;
  owner: { name: string; avatar: string };
  target: { monthly: number };
  hours: { open: string; close: string };
  aiModel?: string;
}

export interface Product {
  id: number;
  name: string;
  price: number;
  modal: number;
  stock: number;
  unit: string;
  color: string;
}

export interface TransactionItem {
  productId: number;
  name: string;
  qty: number;
  price: number;
  modal: number;
}

export interface Transaction {
  id: string;
  timestamp: string; // ISO String
  items: TransactionItem[];
  totalAmount: number;
  totalModal: number;
  profit: number;
}

export const demoStore: StoreProfile = {
  id: "store-001",
  name: "Warung Bakso Pak Budi",
  type: "Kuliner",
  location: "Surabaya",
  since: 2019,
  owner: { name: "Budi Santoso", avatar: "BS" },
  target: { monthly: 15000000 },
  hours: { open: "08:00", close: "20:00" },
  aiModel: "gemini-3.1-flash-lite"
};

export const demoProducts: Product[] = [
  { id: 1, name: "Bakso Urat",   price: 15000, modal: 8000,  stock: 50,  unit: "porsi", color: "#10B981" },
  { id: 2, name: "Bakso Halus",  price: 13000, modal: 7000,  stock: 50,  unit: "porsi", color: "#0284C7" },
  { id: 3, name: "Mie Ayam",     price: 13000, modal: 6500,  stock: 30,  unit: "porsi", color: "#7C3AED" },
  { id: 4, name: "Es Teh Manis", price: 5000,  modal: 1500,  stock: 100, unit: "gelas", color: "#F59E0B" },
  { id: 5, name: "Es Jeruk",     price: 7000,  modal: 2500,  stock: 50,  unit: "gelas", color: "#DC2626" },
  { id: 6, name: "Air Mineral",  price: 3000,  modal: 1000,  stock: 48,  unit: "botol", color: "#0891B2" },
];

export function generateSalesData(products: Product[] = demoProducts): Transaction[] {
  const transactions: Transaction[] = [];
  const now = new Date();
  let transactionCounter = 1;

  // Generate for the last 30 days
  for (let d = 29; d >= 0; d--) {
    const currentDate = new Date(now.getTime() - d * 24 * 60 * 60 * 1000);
    const dayOfWeek = currentDate.getDay(); // 0: Sun, 1: Mon, ... 3: Wed, ... 6: Sat

    // Base transaction counts per day: average around 5, fluctuate between 4 and 7 untuk skala warung (ratusan ribu)
    let dayFluctuation = 1.0;
    if (dayOfWeek === 3) {
      dayFluctuation = 0.7; // Hari Rabu cenderung sepi
    } else if (dayOfWeek === 0 || dayOfWeek === 6) {
      dayFluctuation = 1.25; // Akhir pekan lebih ramai
    }

    // Add random noise (+/- 15%)
    const noise = 0.85 + Math.random() * 0.3;
    const numTransactions = Math.round((4 + Math.floor(Math.random() * 4)) * dayFluctuation * noise);

    for (let t = 0; t < numTransactions; t++) {
      // Direct hour generation to mirror eating behavior
      // Peak times: lunch (11-13) and dinner (17-19)
      const r = Math.random();
      let hour = 8;
      if (r < 0.35) {
        // Lunch peak
        hour = 11 + Math.floor(Math.random() * 3);
      } else if (r < 0.70) {
        // Dinner peak
        hour = 17 + Math.floor(Math.random() * 3);
      } else {
        // Other operating hours
        hour = 8 + Math.floor(Math.random() * 12);
        // Trim to valid business hours 8am to 8pm
        if (hour < 8) hour = 8;
        if (hour >= 20) hour = 19;
      }

      const minute = Math.floor(Math.random() * 60);
      const second = Math.floor(Math.random() * 60);

      const txDate = new Date(currentDate);
      txDate.setHours(hour, minute, second, 0);

      // Select items for this sale
      // Most orders have 1 to 3 items
      const numItemsInSale = 1 + Math.floor(Math.random() * 3);
      const items: TransactionItem[] = [];
      const selectedProductIds = new Set<number>();

      let subtotalAmount = 0;
      let subtotalModal = 0;

      for (let i = 0; i < numItemsInSale; i++) {
        // Choose product
        let product: Product;
        const pr = Math.random();

        // Bakso Urat is 40% of sales
        if (pr < 0.40 && products.length > 0) {
          product = products[0]; // Bakso Urat is index 0
        } else {
          // Select another product randomly
          const idx = Math.floor(Math.random() * products.length);
          product = products[idx];
        }

        if (selectedProductIds.has(product.id)) {
          continue; // Avoid duplicates in same bill, just skip or let next loop handle
        }
        selectedProductIds.add(product.id);

        // Qty in transaction: usually 1 or 2, sometimes more for groups
        const qtyRate = Math.random();
        let qty = 1;
        if (qtyRate < 0.7) {
          qty = 1;
        } else if (qtyRate < 0.95) {
          qty = 2;
        } else {
          qty = 3 + Math.floor(Math.random() * 3); // 3 to 5
        }

        const itemTotal = product.price * qty;
        const itemModalTotal = product.modal * qty;

        items.push({
          productId: product.id,
          name: product.name,
          qty,
          price: product.price,
          modal: product.modal
        });

        subtotalAmount += itemTotal;
        subtotalModal += itemModalTotal;
      }

      if (items.length > 0) {
        transactions.push({
          id: `TX-${txDate.getFullYear()}${(txDate.getMonth() + 1).toString().padStart(2, "0")}${txDate.getDate().toString().padStart(2, "0")}-${transactionCounter.toString().padStart(4, "0")}`,
          timestamp: txDate.toISOString(),
          items,
          totalAmount: subtotalAmount,
          totalModal: subtotalModal,
          profit: subtotalAmount - subtotalModal
        });
        transactionCounter++;
      }
    }
  }

  // Sort chronological - oldest to newest
  return transactions.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
}
