/**
 * Currency utility to format numbers into clean Indonesian Rupiah currency string.
 */
export const formatRupiah = (num: number): string => {
  if (isNaN(num) || num === null || num === undefined) {
    return "Rp 0";
  }
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(num);
};

/**
 * Short currency utility for chart labels, e.g., 5jt, 250rb, -100rb, etc.
 */
export const formatShortRupiah = (val: number): string => {
  if (val === 0 || isNaN(val) || val === null || val === undefined) return "0";
  const absVal = Math.abs(val);
  let formatted = "";
  if (absVal >= 1000000) {
    formatted = (absVal / 1000000).toFixed(1).replace(/\.0$/, "") + "jt";
  } else if (absVal >= 1000) {
    formatted = (absVal / 1000).toFixed(0) + "rb";
  } else {
    formatted = absVal.toString();
  }
  return val < 0 ? `-${formatted}` : formatted;
};

/**
 * Clean strings of currency symbols and separators to extract integers.
 */
export const parseRupiah = (str: string): number => {
  const clean = str.replace(/[^0-9]/g, "");
  const val = parseInt(clean, 10);
  return isNaN(val) ? 0 : val;
};
