/**
 * Date formatting helper for localized Indonesian text representation.
 */

const INDONESIAN_MONTHS_FULL = [
  "Januari", "Februari", "Maret", "April", "Mei", "Juni",
  "Juli", "Agustus", "September", "Oktober", "November", "Desember"
];

const INDONESIAN_MONTHS_SHORT = [
  "Jan", "Feb", "Mar", "Apr", "Mei", "Jun",
  "Jul", "Agt", "Sep", "Okt", "Nov", "Des"
];

const INDONESIAN_DAYS = [
  "Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"
];

const INDONESIAN_DAYS_SHORT = [
  "Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"
];

export const formatFullDate = (dateInput: string | Date): string => {
  const d = typeof dateInput === "string" ? new Date(dateInput) : dateInput;
  if (isNaN(d.getTime())) return "-";
  
  const dayName = INDONESIAN_DAYS[d.getDay()];
  const dateNum = d.getDate();
  const monthName = INDONESIAN_MONTHS_FULL[d.getMonth()];
  const yearNum = d.getFullYear();

  return `${dayName}, ${dateNum} ${monthName} ${yearNum}`;
};

export const formatCompactDate = (dateInput: string | Date): string => {
  const d = typeof dateInput === "string" ? new Date(dateInput) : dateInput;
  if (isNaN(d.getTime())) return "-";
  
  const dateNum = d.getDate();
  const monthName = INDONESIAN_MONTHS_SHORT[d.getMonth()];
  const yearNum = d.getFullYear().toString().substring(2);

  return `${dateNum} ${monthName} '${yearNum}`;
};

export const getShortDayName = (dateInput: string | Date): string => {
  const d = typeof dateInput === "string" ? new Date(dateInput) : dateInput;
  if (isNaN(d.getTime())) return "-";
  return INDONESIAN_DAYS_SHORT[d.getDay()];
};

export const formatTimeOnly = (dateInput: string | Date): string => {
  const d = typeof dateInput === "string" ? new Date(dateInput) : dateInput;
  if (isNaN(d.getTime())) return "--:--";
  
  const hours = d.getHours().toString().padStart(2, "0");
  const minutes = d.getMinutes().toString().padStart(2, "0");
  return `${hours}:${minutes}`;
};

export const getRelativeDayLabel = (dateInput: string | Date): string => {
  const d = typeof dateInput === "string" ? new Date(dateInput) : dateInput;
  if (isNaN(d.getTime())) return "-";

  const today = new Date();
  const yesterday = new Date(today.getTime() - 24 * 60 * 60 * 1000);

  if (d.toDateString() === today.toDateString()) {
    return "Hari Ini";
  } else if (d.toDateString() === yesterday.toDateString()) {
    return "Kemarin";
  } else {
    return formatFullDate(d);
  }
};
