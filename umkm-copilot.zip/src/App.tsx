import React, { useState, useEffect } from "react";
import { AppProvider, useApp } from "./context/AppContext";
import PageLayout from "./components/layout/PageLayout";
import Onboarding from "./pages/Onboarding";
import Dashboard from "./pages/Dashboard";
import Catat from "./pages/Catat";
import Pengeluaran from "./pages/Pengeluaran";
import Analitik from "./pages/Analitik";
import Produk from "./pages/Produk";
import Copilot from "./pages/Copilot";
import { auth } from "./firebase";
import { signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User } from "firebase/auth";

function AppContent() {
  const { setupComplete } = useApp();
  const [activeTab, setActiveTab] = useState("dashboard");

  if (!setupComplete) {
    return <Onboarding />;
  }

  return (
    <PageLayout activeTab={activeTab} setActiveTab={setActiveTab}>
      {activeTab === "dashboard" && <Dashboard setActiveTab={setActiveTab} />}
      {activeTab === "catat" && <Catat />}
      {activeTab === "pengeluaran" && <Pengeluaran />}
      {activeTab === "analitik" && <Analitik />}
      {activeTab === "produk" && <Produk />}
      {activeTab === "copilot" && <Copilot />}
    </PageLayout>
  );
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0F1117] flex items-center justify-center">
        <p className="text-stone-400 font-mono">Memuat...</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0F1117] flex items-center justify-center text-white px-4">
        <div className="max-w-md w-full bg-[#1A1D2E] border border-stone-800 p-8 rounded-3xl text-center shadow-xl">
          <h1 className="font-heading text-3xl font-bold text-stone-100 mb-2">Copilot Bisnis</h1>
          <p className="text-stone-400 mb-8 text-sm">Masuk dengan akun Google untuk sinkronisasi cloud.</p>
          <button onClick={handleLogin} className="w-full bg-emerald-500 hover:bg-emerald-600 text-emerald-950 font-bold py-3 px-6 rounded-xl transition duration-200 shadow-lg shadow-emerald-500/20">
            Masuk dengan Google
          </button>
        </div>
      </div>
    );
  }

  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
