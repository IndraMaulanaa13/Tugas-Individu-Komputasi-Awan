export interface StoreProfile {
  id: string;
  name: string;
  type: string;
  location: string;
  since: number;
  owner: { name: string; avatar: string };
  target: { monthly: number };
  hours: { open: string; close: string; activeDays?: { [key: string]: boolean } };
  ownerId?: string;
  aiModel?: string;
}

export interface Product {
  id: number;
  name: string;
  price: number;
  modal: number;
  stock: number;
  unit: string;
  color: string;
  category?: string;
  description?: string;
  ownerId?: string;
}

export interface TransactionItem {
  productId: number;
  name: string;
  qty: number;
  price: number;
  modal: number;
}

export interface Transaction {
  id: string;
  timestamp: string; // ISO String
  items: TransactionItem[];
  totalAmount: number;
  totalModal: number;
  profit: number;
  ownerId?: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "model";
  text: string;
  timestamp: string; // ISO String
}

export interface ChatSession {
  id: string;
  title: string;
  date: string;
  messages: ChatMessage[];
  ownerId?: string;
}

export interface ToastMessage {
  id: string;
  message: string;
  type: "success" | "error" | "info" | "warning";
}

export interface Expense {
  id: string;
  timestamp: string; // ISO String
  description: string;
  amount: number;
  category: "Bahan Baku" | "Operasional" | "Lainnya";
  ownerId?: string;
}

export interface PeriodMetrics {
  totalRevenue: number;
  totalSalesCount: number;
  netProfit: number;
  marginPercent: number;
  topSellingProduct: string;
  topSellingProductCount: number;
  dailyRevenue?: Record<string, number>;
  todayRevenue?: number;
  todayNetProfit?: number;
}
